"""
face_verification.py — Real AI Face Verification Engine
Uses DeepFace (FaceNet model), MediaPipe for blink detection, and OpenCV for anti-spoofing.
"""
import cv2
import numpy as np
import json
import base64
import time
import os
from io import BytesIO

# ── DeepFace + MediaPipe imports ──────────────────────────────────
from deepface import DeepFace
import mediapipe as mp

# ── Configuration ─────────────────────────────────────────────────
FACENET_MODEL = "Facenet"
DISTANCE_METRIC = "cosine"
VERIFY_THRESHOLD = 0.40
SUSPICIOUS_THRESHOLD = 0.55
EMBEDDING_DIM = 128
MIN_FACE_SIZE = 60
MULTI_FRAME_COUNT = 10
BLINK_EAR_THRESHOLD = 0.21
ANTI_SPOOF_LAPLACIAN_THRESH = 80.0
ANTI_SPOOF_COLOR_VARIANCE_THRESH = 15.0

# MediaPipe Face Mesh
mp_face_mesh = mp.solutions.face_mesh

# Eye landmark indices for EAR calculation (MediaPipe Face Mesh)
LEFT_EYE = [362, 385, 387, 263, 373, 380]
RIGHT_EYE = [33, 160, 158, 133, 153, 144]


def _decode_base64_image(b64_string):
    """Decode a base64-encoded image string into an OpenCV BGR numpy array."""
    if "," in b64_string:
        b64_string = b64_string.split(",", 1)[1]
    img_bytes = base64.b64decode(b64_string)
    nparr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    return img


def _eye_aspect_ratio(landmarks, eye_indices, w, h):
    """Calculate Eye Aspect Ratio (EAR) for blink detection."""
    pts = [(int(landmarks[i].x * w), int(landmarks[i].y * h)) for i in eye_indices]
    vertical1 = np.linalg.norm(np.array(pts[1]) - np.array(pts[5]))
    vertical2 = np.linalg.norm(np.array(pts[2]) - np.array(pts[4]))
    horizontal = np.linalg.norm(np.array(pts[0]) - np.array(pts[3]))
    if horizontal == 0:
        return 0.0
    ear = (vertical1 + vertical2) / (2.0 * horizontal)
    return ear


def detect_blink(frames_b64):
    """
    Analyze a sequence of base64 frames for blink detection using MediaPipe Face Mesh.
    Returns dict with blink_detected (bool), blink_count, avg_ear, frame_ears.
    """
    if not frames_b64:
        return {"blink_detected": False, "blink_count": 0, "avg_ear": 0, "frame_ears": []}

    ear_values = []
    blink_count = 0
    prev_below = False

    with mp_face_mesh.FaceMesh(
        static_image_mode=True,
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5
    ) as face_mesh:
        for b64 in frames_b64:
            try:
                img = _decode_base64_image(b64)
                if img is None:
                    ear_values.append(0.3)
                    continue
                h, w = img.shape[:2]
                rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                results = face_mesh.process(rgb)

                if results.multi_face_landmarks:
                    lm = results.multi_face_landmarks[0].landmark
                    left_ear = _eye_aspect_ratio(lm, LEFT_EYE, w, h)
                    right_ear = _eye_aspect_ratio(lm, RIGHT_EYE, w, h)
                    avg = (left_ear + right_ear) / 2.0
                    ear_values.append(round(avg, 4))

                    if avg < BLINK_EAR_THRESHOLD:
                        if not prev_below:
                            blink_count += 1
                            prev_below = True
                    else:
                        prev_below = False
                else:
                    ear_values.append(0.3)
            except Exception:
                ear_values.append(0.3)

    avg_ear = round(sum(ear_values) / len(ear_values), 4) if ear_values else 0
    return {
        "blink_detected": blink_count >= 1,
        "blink_count": blink_count,
        "avg_ear": avg_ear,
        "frame_ears": ear_values
    }


def anti_spoof_check(frame_b64):
    """
    Perform anti-spoofing checks on a single frame:
    1. Laplacian variance (blur detection — screens/prints are blurrier)
    2. Color channel variance (printed photos have less color variation)
    3. Face size ratio check
    Returns dict with is_real, checks, confidence.
    """
    try:
        img = _decode_base64_image(frame_b64)
        if img is None:
            return {"is_real": False, "confidence": 0, "checks": {"error": "Could not decode image"}}

        h, w = img.shape[:2]
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # 1. Laplacian variance — real faces have sharper features
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()

        # 2. Color variance across channels
        b, g, r = cv2.split(img)
        color_var = float(np.std([b.mean(), g.mean(), r.mean()]))

        # 3. Face detection with OpenCV for size ratio
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        face_ratio = 0.0
        if len(faces) > 0:
            fx, fy, fw, fh = faces[0]
            face_ratio = (fw * fh) / (w * h)

        # Scoring
        laplacian_pass = laplacian_var > ANTI_SPOOF_LAPLACIAN_THRESH
        color_pass = color_var > ANTI_SPOOF_COLOR_VARIANCE_THRESH
        face_size_pass = face_ratio > 0.04
        has_face = len(faces) > 0

        checks_passed = sum([laplacian_pass, color_pass, face_size_pass, has_face])
        confidence = round((checks_passed / 4) * 100, 1)
        is_real = checks_passed >= 3

        return {
            "is_real": is_real,
            "confidence": confidence,
            "checks": {
                "laplacian_variance": round(laplacian_var, 2),
                "laplacian_pass": laplacian_pass,
                "color_variance": round(color_var, 2),
                "color_pass": color_pass,
                "face_ratio": round(face_ratio, 4),
                "face_size_pass": face_size_pass,
                "face_detected": has_face,
                "checks_passed": checks_passed
            }
        }
    except Exception as e:
        return {"is_real": False, "confidence": 0, "checks": {"error": str(e)}}


def generate_embedding(frame_b64):
    """
    Generate a FaceNet embedding vector from a base64-encoded image.
    Uses DeepFace.represent() with the Facenet model.
    Returns dict with embedding (list), face_detected, face_area, etc.
    """
    try:
        img = _decode_base64_image(frame_b64)
        if img is None:
            return {"success": False, "error": "Could not decode image"}

        # Save temp file for DeepFace (it works best with file paths or numpy arrays)
        representations = DeepFace.represent(
            img_path=img,
            model_name=FACENET_MODEL,
            enforce_detection=True,
            detector_backend="opencv",
            align=True
        )

        if not representations:
            return {"success": False, "error": "No face detected in image"}

        rep = representations[0]
        embedding = rep["embedding"]
        facial_area = rep.get("facial_area", {})

        return {
            "success": True,
            "embedding": embedding,
            "embedding_dim": len(embedding),
            "facial_area": facial_area,
            "model": FACENET_MODEL
        }
    except Exception as e:
        error_msg = str(e)
        if "Face could not be detected" in error_msg:
            return {"success": False, "error": "No face detected. Please ensure your face is clearly visible."}
        return {"success": False, "error": error_msg}


def generate_multi_frame_embedding(frames_b64):
    """
    Generate a robust embedding by averaging embeddings from multiple frames.
    Discards frames where face detection fails, requires at least 3 successful frames.
    """
    embeddings = []
    failures = 0
    facial_areas = []

    for frame in frames_b64[:MULTI_FRAME_COUNT]:
        result = generate_embedding(frame)
        if result["success"]:
            embeddings.append(result["embedding"])
            facial_areas.append(result.get("facial_area", {}))
        else:
            failures += 1

    if len(embeddings) < 3:
        return {
            "success": False,
            "error": f"Only {len(embeddings)} of {len(frames_b64)} frames had detectable faces. Need at least 3.",
            "successful_frames": len(embeddings),
            "failed_frames": failures
        }

    # Average the embeddings for a more robust representation
    avg_embedding = np.mean(embeddings, axis=0).tolist()

    # Calculate consistency (std deviation across frames — lower is better)
    consistency = 1.0 - min(float(np.mean(np.std(embeddings, axis=0))), 1.0)

    return {
        "success": True,
        "embedding": avg_embedding,
        "embedding_dim": len(avg_embedding),
        "successful_frames": len(embeddings),
        "failed_frames": failures,
        "total_frames": len(frames_b64),
        "consistency": round(consistency * 100, 1),
        "model": FACENET_MODEL
    }


def verify_face(probe_b64_frames, stored_embedding_json):
    """
    Full face verification pipeline:
    1. Multi-frame embedding generation from probe frames
    2. Anti-spoofing check
    3. Blink detection (liveness)
    4. Cosine distance comparison against stored embedding
    5. Confidence scoring and status determination

    Args:
        probe_b64_frames: list of base64-encoded webcam frames
        stored_embedding_json: JSON string of the stored face embedding

    Returns:
        dict with verification results
    """
    start_time = time.time()

    # Parse stored embedding
    try:
        stored_embedding = json.loads(stored_embedding_json) if isinstance(stored_embedding_json, str) else stored_embedding_json
    except (json.JSONDecodeError, TypeError):
        return {
            "success": False,
            "status": "failed",
            "confidence_score": 0,
            "error": "Invalid stored embedding format"
        }

    # Step 1: Anti-spoofing on the middle frame
    mid_idx = len(probe_b64_frames) // 2
    spoof_result = anti_spoof_check(probe_b64_frames[mid_idx])

    # Step 2: Blink detection across all frames
    blink_result = detect_blink(probe_b64_frames)

    # Step 3: Generate multi-frame embedding
    embed_result = generate_multi_frame_embedding(probe_b64_frames)
    if not embed_result["success"]:
        return {
            "success": False,
            "status": "failed",
            "confidence_score": 0,
            "error": embed_result["error"],
            "anti_spoof": spoof_result,
            "blink_detection": blink_result,
            "processing_time": round(time.time() - start_time, 2)
        }

    probe_embedding = np.array(embed_result["embedding"])
    stored_emb = np.array(stored_embedding)

    # Step 4: Cosine distance
    dot_product = np.dot(probe_embedding, stored_emb)
    norm_a = np.linalg.norm(probe_embedding)
    norm_b = np.linalg.norm(stored_emb)

    if norm_a == 0 or norm_b == 0:
        cosine_distance = 1.0
    else:
        cosine_similarity = dot_product / (norm_a * norm_b)
        cosine_distance = 1.0 - cosine_similarity

    # Step 5: Confidence scoring
    # Lower cosine distance = better match
    raw_confidence = max(0, (1.0 - cosine_distance / 0.8)) * 100
    raw_confidence = min(raw_confidence, 100)

    # Apply penalties
    penalty = 0
    if not spoof_result["is_real"]:
        penalty += 25
    if not blink_result["blink_detected"]:
        penalty += 10

    final_confidence = max(0, raw_confidence - penalty)
    final_confidence = round(final_confidence, 1)

    # Determine status
    if cosine_distance <= VERIFY_THRESHOLD and spoof_result["is_real"]:
        status = "verified"
    elif cosine_distance <= SUSPICIOUS_THRESHOLD:
        status = "suspicious"
    else:
        status = "failed"

    liveness_passed = blink_result["blink_detected"] and spoof_result["is_real"]

    processing_time = round(time.time() - start_time, 2)

    return {
        "success": True,
        "status": status,
        "confidence_score": final_confidence,
        "cosine_distance": round(cosine_distance, 4),
        "liveness_passed": liveness_passed,
        "anti_spoof": spoof_result,
        "blink_detection": blink_result,
        "embedding_quality": {
            "successful_frames": embed_result["successful_frames"],
            "failed_frames": embed_result["failed_frames"],
            "consistency": embed_result["consistency"]
        },
        "model": FACENET_MODEL,
        "distance_metric": DISTANCE_METRIC,
        "threshold": VERIFY_THRESHOLD,
        "processing_time": processing_time,
        "message": _build_message(status, final_confidence, liveness_passed, spoof_result["is_real"])
    }


def enroll_face(frames_b64):
    """
    Enroll a face by generating a robust multi-frame embedding.
    Also runs anti-spoofing and blink detection to ensure quality enrollment.

    Args:
        frames_b64: list of base64-encoded webcam frames (ideally 10)

    Returns:
        dict with embedding, quality metrics, and enrollment status
    """
    start_time = time.time()

    # Anti-spoofing check
    mid_idx = len(frames_b64) // 2
    spoof_result = anti_spoof_check(frames_b64[mid_idx])

    # Blink detection
    blink_result = detect_blink(frames_b64)

    # Generate multi-frame embedding
    embed_result = generate_multi_frame_embedding(frames_b64)

    if not embed_result["success"]:
        return {
            "success": False,
            "error": embed_result["error"],
            "anti_spoof": spoof_result,
            "blink_detection": blink_result,
            "processing_time": round(time.time() - start_time, 2)
        }

    if not spoof_result["is_real"]:
        return {
            "success": False,
            "error": "Anti-spoofing check failed. Please use a real face, not a photo or screen.",
            "anti_spoof": spoof_result,
            "blink_detection": blink_result,
            "processing_time": round(time.time() - start_time, 2)
        }

    return {
        "success": True,
        "embedding": embed_result["embedding"],
        "embedding_dim": embed_result["embedding_dim"],
        "model": FACENET_MODEL,
        "quality": {
            "successful_frames": embed_result["successful_frames"],
            "failed_frames": embed_result["failed_frames"],
            "consistency": embed_result["consistency"],
            "anti_spoof_confidence": spoof_result["confidence"],
            "blink_detected": blink_result["blink_detected"],
            "blink_count": blink_result["blink_count"]
        },
        "processing_time": round(time.time() - start_time, 2)
    }


def _build_message(status, confidence, liveness, is_real):
    """Build a human-readable verification message."""
    if status == "verified":
        msg = f"Face VERIFIED — Confidence: {confidence}%"
        if liveness:
            msg += " | Liveness: PASSED"
        return msg
    elif status == "suspicious":
        msg = f"Face SUSPICIOUS — Confidence: {confidence}%"
        if not is_real:
            msg += " | Anti-spoof: FAILED"
        if not liveness:
            msg += " | Liveness: NOT CONFIRMED"
        return msg
    else:
        msg = f"Face FAILED — Confidence: {confidence}%"
        if not is_real:
            msg += " | Possible spoof detected"
        return msg
