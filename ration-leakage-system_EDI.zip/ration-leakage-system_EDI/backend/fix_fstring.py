"""Fix the f-string syntax error in database.py"""
filepath = 'database.py'
with open(filepath, encoding='utf-8') as f:
    lines = f.readlines()

fixed = []
for i, line in enumerate(lines):
    # Find the broken qr f-string line and replace it with two clean lines
    if "qr = f'" in line and "issued_to" in line and "valid" in line:
        fixed.append('    issued_to_val = data.get("issued_to", "")\n')
        fixed.append('    qr = \'{"id":"\' + uid + \'","shop":"\' + issued_to_val + \'","valid":true}\'\n')
        print(f"Fixed line {i+1}: {line.strip()[:60]}")
    else:
        fixed.append(line)

with open(filepath, 'w', encoding='utf-8') as f:
    f.writelines(fixed)
print("Done. Lines written:", len(fixed))
