"""
detection_engine.py — AI Fraud Detection Algorithms for Ration Guard
"""
import database as db

def detect_duplicate_aadhaar():
    bens = db.get_all_beneficiaries()
    freq = {}
    for b in bens:
        key = b['aadhaar_number'].replace(' ','').replace('-','')
        freq[key] = freq.get(key, 0) + 1
    duplicates = [b for b in bens if freq[b['aadhaar_number'].replace(' ','').replace('-','')] > 1]
    return {"algorithm": "Duplicate Aadhaar Detection", "duplicate_count": len(duplicates), "duplicates": duplicates}

def detect_stock_mismatch():
    shops = db.get_all_shops()
    allocs = db.get_all_allocations()
    distros = db.get_all_distributions()
    alloc_map = {}
    for a in allocs:
        sid = a['shop_id']
        alloc_map[sid] = alloc_map.get(sid, 0) + float(a.get('rice_allocated',0) or 0) + float(a.get('wheat_allocated',0) or 0) + float(a.get('sugar_allocated',0) or 0)
    dist_map = {}
    for d in distros:
        sid = d['shop_id']
        dist_map[sid] = dist_map.get(sid, 0) + float(d.get('rice_given',0) or 0) + float(d.get('wheat_given',0) or 0) + float(d.get('sugar_given',0) or 0)
    suspicious = []
    for shop in shops:
        sid = shop['shop_id']
        alloc = alloc_map.get(sid, 0)
        dist = dist_map.get(sid, 0)
        mismatch = alloc - dist
        pct = round(mismatch/alloc*100, 1) if alloc > 0 else 0
        if pct > 10:
            suspicious.append({"shop_id": sid, "shop_name": shop['shop_name'], "location": shop.get('location',''), "allocated_kg": alloc, "distributed_kg": dist, "mismatch_kg": round(mismatch, 2), "mismatch_pct": pct})
    return {"algorithm": "Stock Mismatch Detection", "suspicious_count": len(suspicious), "suspicious_shops": suspicious}

def detect_abnormal_patterns():
    shops = db.get_all_shops()
    distros = db.get_all_distributions()
    tx_count = {}
    for d in distros:
        sid = d['shop_id']
        tx_count[sid] = tx_count.get(sid, 0) + 1
    counts = list(tx_count.values()) if tx_count else [0]
    avg_tx = sum(counts) / len(counts) if counts else 0
    flagged = []
    for shop in shops:
        sid = shop['shop_id']
        txs = tx_count.get(sid, 0)
        reason = None
        if txs == 0:
            reason = "Ghost Shop — zero distribution transactions recorded"
        elif avg_tx > 0 and txs > avg_tx * 2:
            reason = f"Inflated Records — {txs} transactions (avg {round(avg_tx,1)})"
        if reason:
            flagged.append({"shop_id": sid, "shop_name": shop['shop_name'], "location": shop.get('location',''), "tx_count": txs, "average_tx": round(avg_tx,1), "reason": reason})
    return {"algorithm": "Abnormal Pattern Detection", "flagged_count": len(flagged), "flagged_shops": flagged}

def detect_multi_registration():
    """Detect same phone/email across multiple shops."""
    shops = db.get_all_shops()
    phone_map = {}
    for s in shops:
        ph = s.get('dealer_phone','') or ''
        if ph:
            phone_map.setdefault(ph, []).append(s)
    flagged = []
    for ph, sh_list in phone_map.items():
        if len(sh_list) > 1:
            flagged.append({"phone": ph, "shops": [{"id": s['shop_id'], "name": s['shop_name']} for s in sh_list], "reason": f"Phone {ph} linked to {len(sh_list)} shops"})
    return {"algorithm": "Multi-Registration Detection", "flagged_count": len(flagged), "flagged": flagged}

def run_all_detection():
    dup = detect_duplicate_aadhaar()
    mismatch = detect_stock_mismatch()
    pattern = detect_abnormal_patterns()
    multi = detect_multi_registration()
    suspicious_ids = set()
    for s in mismatch['suspicious_shops']: suspicious_ids.add(s['shop_id'])
    for s in pattern['flagged_shops']: suspicious_ids.add(s['shop_id'])
    allocs = db.get_all_allocations()
    distros = db.get_all_distributions()
    total_alloc = sum(float(a.get('rice_allocated',0) or 0)+float(a.get('wheat_allocated',0) or 0)+float(a.get('sugar_allocated',0) or 0) for a in allocs)
    total_dist = sum(float(d.get('rice_given',0) or 0)+float(d.get('wheat_given',0) or 0)+float(d.get('sugar_given',0) or 0) for d in distros)
    leak_pct = round((total_alloc-total_dist)/total_alloc*100, 1) if total_alloc > 0 else 0
    return {
        "suspicious_shops": len(suspicious_ids),
        "duplicate_count": dup['duplicate_count'],
        "leakage_percent": leak_pct,
        "duplicate_aadhaar": dup,
        "stock_mismatch": mismatch,
        "abnormal_patterns": pattern,
        "multi_registration": multi
    }
