"""
database.py — MySQL Database Operations for Ration Guard Fraud Portal
"""
import pymysql
from datetime import date, datetime

DB_CONFIG = {
    'host':        'localhost',
    'user':        'root',
    'password':    'Patejaswini@101',
    'database':    'ration_system',
    'charset':     'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_connection():
    return pymysql.connect(**DB_CONFIG)

def _serial(obj):
    """Make MySQL rows JSON-serialisable."""
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    return str(obj)

def query(sql, args=(), many=True):
    conn = get_connection()
    try:
        with conn.cursor() as c:
            c.execute(sql, args)
            return c.fetchall() if many else c.fetchone()
    finally:
        conn.close()

def execute(sql, args=()):
    conn = get_connection()
    try:
        with conn.cursor() as c:
            c.execute(sql, args)
            conn.commit()
            return c.lastrowid
    finally:
        conn.close()

# ── VALID VILLAGES ────────────────────────────────────────────────
VALID_VILLAGES = [
    'Rampur','Shivpur','Azamnagar','Lucknow','Kasimpur',
    'Varanasi','Nagpur','Kanpur','Agra','Jhansi'
]

def get_valid_villages():
    conn = get_connection()
    try:
        with conn.cursor() as c:
            c.execute("SELECT DISTINCT village FROM beneficiaries WHERE village IS NOT NULL AND village!='' ORDER BY village")
            db_v = [r['village'] for r in c.fetchall()]
        return list(dict.fromkeys(VALID_VILLAGES + db_v))
    finally:
        conn.close()

# ── BENEFICIARIES ─────────────────────────────────────────────────
def get_all_beneficiaries():
    return query("SELECT * FROM beneficiaries ORDER BY beneficiary_id")

def aadhaar_exists(digits):
    r = query("SELECT COUNT(*) AS c FROM beneficiaries WHERE REPLACE(REPLACE(aadhaar_number,' ',''),'-','')=%s", (digits,), many=False)
    return r['c'] > 0

def family_id_exists(fid):
    r = query("SELECT COUNT(*) AS c FROM beneficiaries WHERE family_id=%s", (fid,), many=False)
    return r['c'] > 0

def add_beneficiary(data):
    raw = data.get('aadhaar_number','').replace(' ','').replace('-','')
    fmt = f"{raw[:4]} {raw[4:8]} {raw[8:12]}" if len(raw)==12 else raw
    lid = execute("""
        INSERT INTO beneficiaries (name,aadhaar_number,family_id,village,income_category,phone)
        VALUES (%s,%s,%s,%s,%s,%s)
    """, (data.get('name'), fmt, data.get('family_id',''), data.get('village',''),
          data.get('income_category','BPL'), data.get('phone','')))
    return {"id": lid, "status": "added"}

def get_duplicate_beneficiaries():
    conn = get_connection()
    try:
        with conn.cursor() as c:
            c.execute("""SELECT REPLACE(REPLACE(aadhaar_number,' ',''),'-','') AS norm, COUNT(*) AS cnt
                         FROM beneficiaries GROUP BY norm HAVING cnt>1""")
            dups = {r['norm'] for r in c.fetchall()}
            if not dups: return []
            c.execute("SELECT * FROM beneficiaries ORDER BY aadhaar_number")
            all_r = c.fetchall()
        def n(a): return a.replace(' ','').replace('-','')
        return [r for r in all_r if n(r['aadhaar_number']) in dups]
    finally:
        conn.close()

# ── SHOPS ─────────────────────────────────────────────────────────
def get_all_shops():
    return query("SELECT * FROM ration_shops ORDER BY shop_id")

def get_shop_by_id(shop_id):
    return query("SELECT * FROM ration_shops WHERE shop_id=%s", (shop_id,), many=False)

def add_shop(data):
    lid = execute("""
        INSERT INTO ration_shops (shop_name,location,state,district,dealer_name,dealer_phone,dealer_email,license_number)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
    """, (data.get('shop_name'), data.get('location'), data.get('state','Uttar Pradesh'),
          data.get('district',''), data.get('dealer_name',''), data.get('dealer_phone',''),
          data.get('dealer_email',''), data.get('license_number','')))
    return {"id": lid, "status": "added"}

def update_shop_status(shop_id, status):
    execute("UPDATE ration_shops SET status=%s WHERE shop_id=%s", (status, shop_id))
    return {"status": "updated"}

def update_shop_risk_score(shop_id, score):
    execute("UPDATE ration_shops SET fraud_risk_score=%s WHERE shop_id=%s", (score, shop_id))

# ── ALLOCATIONS ───────────────────────────────────────────────────
def get_all_allocations():
    return query("""SELECT sa.*, rs.shop_name FROM stock_allocations sa
                    JOIN ration_shops rs ON sa.shop_id=rs.shop_id ORDER BY sa.allocation_id""")

def add_allocation(data):
    lid = execute("""
        INSERT INTO stock_allocations (shop_id,month,rice_allocated,wheat_allocated,sugar_allocated)
        VALUES (%s,%s,%s,%s,%s)
    """, (int(data.get('shop_id',0)), data.get('month'),
          float(data.get('rice_allocated',0)), float(data.get('wheat_allocated',0)),
          float(data.get('sugar_allocated',0))))
    return {"id": lid, "status": "allocated"}

# ── DISTRIBUTIONS ─────────────────────────────────────────────────
def get_all_distributions():
    return query("""SELECT dl.*, rs.shop_name FROM distribution_logs dl
                    JOIN ration_shops rs ON dl.shop_id=rs.shop_id ORDER BY dl.distribution_id""")

def add_distribution(data):
    conn = get_connection()
    try:
        with conn.cursor() as c:
            c.execute("SELECT ration_card_id FROM ration_cards LIMIT 1")
            row = c.fetchone()
            if row:
                card_id = row['ration_card_id']
            else:
                c.execute("INSERT INTO ration_cards (family_id,card_type,issue_date,status) VALUES ('FAM-001','BPL',%s,'Active')", (date.today(),))
                card_id = c.lastrowid
            c.execute("""
                INSERT INTO distribution_logs (ration_card_id,shop_id,date,rice_given,wheat_given,sugar_given)
                VALUES (%s,%s,%s,%s,%s,%s)
            """, (card_id, int(data.get('shop_id',0)), date.today(),
                  float(data.get('rice_given',0)), float(data.get('wheat_given',0)),
                  float(data.get('sugar_given',0))))
            conn.commit()
            return {"id": c.lastrowid, "status": "recorded"}
    finally:
        conn.close()

# ── FRAUD CASES ───────────────────────────────────────────────────
def get_all_cases():
    return query("""
        SELECT fc.*, u1.full_name AS officer_name, u2.full_name AS created_by_name,
               rs.shop_name
        FROM fraud_cases fc
        LEFT JOIN users u1 ON fc.assigned_officer=u1.user_id
        LEFT JOIN users u2 ON fc.created_by=u2.user_id
        LEFT JOIN ration_shops rs ON fc.shop_id=rs.shop_id
        ORDER BY fc.created_at DESC
    """)

def get_case_by_id(case_id):
    return query("""
        SELECT fc.*, u1.full_name AS officer_name, rs.shop_name
        FROM fraud_cases fc
        LEFT JOIN users u1 ON fc.assigned_officer=u1.user_id
        LEFT JOIN ration_shops rs ON fc.shop_id=rs.shop_id
        WHERE fc.case_id=%s
    """, (case_id,), many=False)

def create_case(data, created_by):
    import random
    case_num = f"CASE-{datetime.now().year}-{random.randint(100,999)}"
    lid = execute("""
        INSERT INTO fraud_cases (case_number,title,description,shop_id,case_type,status,priority,risk_score,assigned_officer,created_by,deadline)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (case_num, data.get('title'), data.get('description'), data.get('shop_id'),
          data.get('case_type','other'), data.get('status','open'), data.get('priority','medium'),
          data.get('risk_score',0), data.get('assigned_officer'), created_by, data.get('deadline')))
    return {"id": lid, "case_number": case_num, "status": "created"}

def update_case_status(case_id, status):
    execute("UPDATE fraud_cases SET status=%s, updated_at=NOW() WHERE case_id=%s", (status, case_id))
    return {"status": "updated"}

def get_case_notes(case_id):
    return query("""SELECT cn.*, u.full_name AS author_name FROM case_notes cn
                    LEFT JOIN users u ON cn.author_id=u.user_id
                    WHERE cn.case_id=%s ORDER BY cn.created_at""", (case_id,))

def add_case_note(case_id, author_id, text, internal=True):
    lid = execute("INSERT INTO case_notes (case_id,author_id,note_text,is_internal) VALUES (%s,%s,%s,%s)",
                  (case_id, author_id, text, internal))
    return {"id": lid, "status": "added"}

# ── FRAUD ALERTS ──────────────────────────────────────────────────
def get_all_alerts():
    return query("""
        SELECT fa.*, rs.shop_name FROM fraud_alerts fa
        LEFT JOIN ration_shops rs ON fa.shop_id=rs.shop_id
        ORDER BY fa.created_at DESC
    """)

def create_alert(data):
    lid = execute("""
        INSERT INTO fraud_alerts (shop_id,beneficiary_id,alert_type,severity,description,risk_score)
        VALUES (%s,%s,%s,%s,%s,%s)
    """, (data.get('shop_id'), data.get('beneficiary_id'), data.get('alert_type'),
          data.get('severity','medium'), data.get('description'), data.get('risk_score',0)))
    return {"id": lid, "status": "created"}

def acknowledge_alert(alert_id, user_id):
    execute("UPDATE fraud_alerts SET status='acknowledged', acknowledged_by=%s WHERE alert_id=%s",
            (user_id, alert_id))
    return {"status": "acknowledged"}

# ── PUBLIC COMPLAINTS ─────────────────────────────────────────────
def get_all_complaints():
    return query("""
        SELECT pc.*, rs.shop_name AS linked_shop, u.full_name AS assigned_name
        FROM public_complaints pc
        LEFT JOIN ration_shops rs ON pc.shop_id=rs.shop_id
        LEFT JOIN users u ON pc.assigned_to=u.user_id
        ORDER BY pc.created_at DESC
    """)

def create_complaint(data):
    import random
    comp_num = f"COMP-{datetime.now().year}-{random.randint(100,999)}"
    lid = execute("""
        INSERT INTO public_complaints (complaint_number,complainant_name,complainant_phone,complainant_email,
        shop_id,shop_name_text,complaint_type,description)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
    """, (comp_num, data.get('complainant_name'), data.get('complainant_phone'),
          data.get('complainant_email'), data.get('shop_id'), data.get('shop_name_text'),
          data.get('complaint_type','other'), data.get('description')))
    return {"id": lid, "complaint_number": comp_num, "status": "submitted"}

def update_complaint(complaint_id, updates):
    sets = ', '.join(f"{k}=%s" for k in updates)
    execute(f"UPDATE public_complaints SET {sets}, updated_at=NOW() WHERE complaint_id=%s",
            tuple(updates.values()) + (complaint_id,))
    return {"status": "updated"}

# ── CERTIFICATES ──────────────────────────────────────────────────
def get_all_certificates():
    return query("""SELECT c.*, rs.shop_name FROM certificates c
                    LEFT JOIN ration_shops rs ON c.shop_id=rs.shop_id
                    ORDER BY c.created_at DESC""")

def get_cert_by_unique_id(uid):
    return query("SELECT c.*, rs.shop_name, rs.location, rs.dealer_name FROM certificates c LEFT JOIN ration_shops rs ON c.shop_id=rs.shop_id WHERE c.cert_unique_id=%s", (uid,), many=False)

def create_certificate(data, issued_by):
    import uuid
    uid = f"CERT-{datetime.now().year}-{str(uuid.uuid4())[:8].upper()}"
    issued_to_val = data.get("issued_to", "")
    qr = '{"id":"' + uid + '","shop":"' + issued_to_val + '","valid":true}'
    lid = execute("""
        INSERT INTO certificates (cert_unique_id,shop_id,issued_to,issued_by,cert_type,issue_date,expiry_date,qr_code_data)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
    """, (uid, data.get('shop_id'), data.get('issued_to'), issued_by,
          data.get('cert_type','Shop License'), data.get('issue_date'), data.get('expiry_date'), qr))
    execute("UPDATE ration_shops SET certificate_id=%s, certificate_status='valid', certificate_expiry=%s WHERE shop_id=%s",
            (uid, data.get('expiry_date'), data.get('shop_id')))
    return {"id": lid, "cert_unique_id": uid, "status": "issued"}

def revoke_certificate(cert_id, revoked_by, reason):
    execute("UPDATE certificates SET status='revoked', revoked_by=%s, revoke_reason=%s, revoked_at=NOW() WHERE cert_id=%s",
            (revoked_by, reason, cert_id))
    cert = query("SELECT shop_id FROM certificates WHERE cert_id=%s", (cert_id,), many=False)
    if cert:
        execute("UPDATE ration_shops SET certificate_status='revoked' WHERE shop_id=%s", (cert['shop_id'],))
    return {"status": "revoked"}

# ── NOTIFICATIONS ─────────────────────────────────────────────────
def get_user_notifications(user_id):
    return query("SELECT * FROM notifications WHERE user_id=%s ORDER BY created_at DESC LIMIT 50", (user_id,))

def create_notification(user_id, title, message, notif_type='system', related_id=None, related_type=None):
    lid = execute("""
        INSERT INTO notifications (user_id,title,message,notif_type,related_id,related_type)
        VALUES (%s,%s,%s,%s,%s,%s)
    """, (user_id, title, message, notif_type, related_id, related_type))
    return lid

def mark_notifications_read(user_id):
    execute("UPDATE notifications SET is_read=TRUE WHERE user_id=%s", (user_id,))
    return {"status": "ok"}

def get_unread_count(user_id):
    r = query("SELECT COUNT(*) AS c FROM notifications WHERE user_id=%s AND is_read=FALSE", (user_id,), many=False)
    return r['c'] if r else 0

# ── USERS ─────────────────────────────────────────────────────────
def get_all_users():
    return query("SELECT user_id,username,full_name,email,phone,role,status,last_login,created_at FROM users ORDER BY user_id")

def get_user_by_username(username):
    return query("SELECT * FROM users WHERE username=%s", (username,), many=False)

def user_exists(username):
    r = query("SELECT COUNT(*) AS c FROM users WHERE username=%s", (username,), many=False)
    return r['c'] > 0

def create_user(data, password_hash):
    lid = execute("""
        INSERT INTO users (username,password_hash,full_name,email,phone,role)
        VALUES (%s,%s,%s,%s,%s,%s)
    """, (data.get('username'), password_hash, data.get('full_name'),
          data.get('email',''), data.get('phone',''), data.get('role','public_user')))
    return {"id": lid, "status": "created"}

def update_user_status(user_id, status):
    execute("UPDATE users SET status=%s WHERE user_id=%s", (status, user_id))
    return {"status": "updated"}

def update_last_login(user_id):
    execute("UPDATE users SET last_login=NOW() WHERE user_id=%s", (user_id,))

# ── ADMIN ACTIONS ─────────────────────────────────────────────────
def log_admin_action(admin_id, target_type, target_id, action_type, reason=''):
    lid = execute("""
        INSERT INTO admin_actions (admin_id,target_type,target_id,action_type,reason)
        VALUES (%s,%s,%s,%s,%s)
    """, (admin_id, target_type, target_id, action_type, reason))
    return lid

def get_admin_actions():
    return query("""SELECT aa.*, u.full_name AS admin_name FROM admin_actions aa
                    JOIN users u ON aa.admin_id=u.user_id ORDER BY aa.created_at DESC LIMIT 100""")

# ── AUDIT LOGS ────────────────────────────────────────────────────
def log_audit(user_id, action, entity_type=None, entity_id=None, description='', ip=''):
    execute("""
        INSERT INTO audit_logs (user_id,action,entity_type,entity_id,description,ip_address)
        VALUES (%s,%s,%s,%s,%s,%s)
    """, (user_id, action, entity_type, entity_id, description, ip))

def get_audit_logs():
    return query("""SELECT al.*, u.full_name AS user_name FROM audit_logs al
                    LEFT JOIN users u ON al.user_id=u.user_id ORDER BY al.created_at DESC LIMIT 200""")

# ── DASHBOARD STATS ───────────────────────────────────────────────
def get_dashboard_stats():
    conn = get_connection()
    try:
        with conn.cursor() as c:
            c.execute("SELECT COUNT(*) AS t FROM beneficiaries"); ben = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM ration_shops"); shops = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM ration_shops WHERE status='active'"); active_s = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM ration_shops WHERE status='blocked'"); blocked_s = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM ration_shops WHERE status='suspended'"); susp_s = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM fraud_cases"); cases = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM fraud_cases WHERE status='open' OR status='under_review'"); open_c = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM fraud_alerts WHERE status='new'"); new_alerts = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM public_complaints"); complaints = c.fetchone()['t']
            c.execute("SELECT COALESCE(SUM(rice_allocated+wheat_allocated+sugar_allocated),0) AS t FROM stock_allocations"); alloc = float(c.fetchone()['t'])
            c.execute("SELECT COALESCE(SUM(rice_given+wheat_given+sugar_given),0) AS t FROM distribution_logs"); dist = float(c.fetchone()['t'])
            c.execute("SELECT COUNT(*) AS t FROM certificates WHERE status='valid'"); valid_certs = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM certificates WHERE status IN ('revoked','blocked')"); rev_certs = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM face_verification_logs WHERE status='verified'"); fv = c.fetchone()['t']
            c.execute("SELECT COUNT(*) AS t FROM face_verification_logs WHERE status='failed'"); ff = c.fetchone()['t']

        leak = alloc - dist
        leak_pct = round(leak/alloc*100, 1) if alloc > 0 else 0
        return {
            "beneficiaries": ben, "shops": shops, "active_shops": active_s,
            "blocked_shops": blocked_s, "suspended_shops": susp_s,
            "total_cases": cases, "open_cases": open_c,
            "new_alerts": new_alerts, "total_complaints": complaints,
            "allocated_kg": alloc, "distributed_kg": dist,
            "leakage_kg": round(leak, 2), "leakage_percent": leak_pct,
            "valid_certs": valid_certs, "revoked_certs": rev_certs,
            "face_verified": fv, "face_failed": ff
        }
    finally:
        conn.close()

def get_monthly_stats():
    return query("""
        SELECT DATE_FORMAT(date,'%Y-%m') AS month,
               SUM(rice_given+wheat_given+sugar_given) AS total_distributed,
               COUNT(*) AS transactions
        FROM distribution_logs
        GROUP BY month ORDER BY month
    """)

def get_state_fraud_data():
    return query("""
        SELECT state, COUNT(*) AS shops,
               AVG(fraud_risk_score) AS avg_risk,
               SUM(CASE WHEN status IN ('blocked','suspended') THEN 1 ELSE 0 END) AS flagged
        FROM ration_shops GROUP BY state ORDER BY avg_risk DESC
    """)
