"""
risk_scoring.py — Fraud Risk Scoring Engine
"""
import database as db

WEIGHTS = {
    'stock_mismatch': 40,
    'ghost_shop': 35,
    'duplicate_aadhaar': 15,
    'abnormal_freq': 10
}

def score_shop(shop, alloc, dist, avg_tx, tx):
    score = 0
    reasons = []
    if alloc > 0:
        pct = (alloc - dist) / alloc * 100
        if pct > 50:
            score += WEIGHTS['stock_mismatch']
            reasons.append(f"Stock mismatch {round(pct,1)}%")
        elif pct > 20:
            score += int(WEIGHTS['stock_mismatch'] * 0.6)
            reasons.append(f"Moderate stock gap {round(pct,1)}%")
    if tx == 0:
        score += WEIGHTS['ghost_shop']
        reasons.append("Ghost shop: no distributions")
    elif avg_tx > 0 and tx > avg_tx * 2:
        score += WEIGHTS['abnormal_freq']
        reasons.append(f"Abnormal tx frequency: {tx} vs avg {round(avg_tx,1)}")
    return min(score, 100), reasons

def calculate_all_risk_scores():
    shops = db.get_all_shops()
    allocs = db.get_all_allocations()
    distros = db.get_all_distributions()
    alloc_map, dist_map, tx_map = {}, {}, {}
    for a in allocs:
        sid = a['shop_id']
        alloc_map[sid] = alloc_map.get(sid, 0) + float(a.get('rice_allocated',0) or 0) + float(a.get('wheat_allocated',0) or 0) + float(a.get('sugar_allocated',0) or 0)
    for d in distros:
        sid = d['shop_id']
        dist_map[sid] = dist_map.get(sid, 0) + float(d.get('rice_given',0) or 0) + float(d.get('wheat_given',0) or 0) + float(d.get('sugar_given',0) or 0)
        tx_map[sid] = tx_map.get(sid, 0) + 1
    counts = list(tx_map.values()) or [0]
    avg_tx = sum(counts) / len(counts) if counts else 0
    results = []
    for shop in shops:
        sid = shop['shop_id']
        sc, reasons = score_shop(shop, alloc_map.get(sid,0), dist_map.get(sid,0), avg_tx, tx_map.get(sid,0))
        db.update_shop_risk_score(sid, sc)
        label = 'Critical' if sc >= 80 else 'High' if sc >= 60 else 'Medium' if sc >= 30 else 'Low'
        results.append({"shop_id": sid, "shop_name": shop['shop_name'], "risk_score": sc, "risk_label": label, "reasons": reasons})
    return {"risk_scores": results, "avg_risk": round(sum(r['risk_score'] for r in results)/len(results), 1) if results else 0}
