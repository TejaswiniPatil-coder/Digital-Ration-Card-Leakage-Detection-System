"""
app.py — Flask Backend for Ration Guard AI Fraud Monitoring Portal
Run: python app.py  |  Access: http://localhost:5000
"""
from flask import Flask, jsonify, request, send_from_directory, session
from flask_cors import CORS
import os, hashlib, secrets, json
from datetime import datetime
import database as db
import detection_engine as de
import risk_scoring as rs

app = Flask(__name__, static_folder='../frontend', static_url_path='')
app.secret_key = secrets.token_hex(32)
CORS(app, supports_credentials=True)

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), '..', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def hash_pw(pw): return hashlib.sha256(pw.encode()).hexdigest()
def authed(): return session.get('logged_in') is True
def role(): return session.get('role','')
def uid(): return session.get('user_id')
def admin_only(): return role() in ('super_admin','investigation_officer')

def serial(obj):
    from datetime import date
    if isinstance(obj, (date, datetime)): return obj.isoformat()
    return str(obj)

def jsonify_rows(rows):
    import json
    return app.response_class(json.dumps(rows, default=serial), mimetype='application/json')

# ── FRONTEND ──────────────────────────────────────────────────────
@app.route('/')
def index():
    return send_from_directory('../frontend', 'index.html')

# ══════════════════════════════════════════════════════════════════
# AUTH
# ══════════════════════════════════════════════════════════════════
@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        username = (data.get('username') or '').strip()
        password = (data.get('password') or '').strip()
        if not username or not password:
            return jsonify({'error': 'Username and password required.'}), 400
        user = db.get_user_by_username(username)
        if user and user['password_hash'] == hash_pw(password):
            if user['status'] == 'blocked':
                return jsonify({'error': 'Your account is blocked. Contact admin.'}), 403
            if user['status'] == 'suspended':
                return jsonify({'error': 'Your account is suspended pending investigation.'}), 403
            session['logged_in'] = True
            session['user_id']   = user['user_id']
            session['username']  = username
            session['role']      = user['role']
            session['full_name'] = user['full_name']
            db.update_last_login(user['user_id'])
            db.log_audit(user['user_id'], 'LOGIN', 'user', user['user_id'], f"{user['full_name']} logged in", request.remote_addr)
            return jsonify({'success': True, 'username': username, 'role': user['role'], 'full_name': user['full_name'], 'email': user.get('email',''), 'user_id': user['user_id']})
        return jsonify({'error': 'Invalid credentials.'}), 401
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    db.log_audit(uid(), 'LOGOUT', 'user', uid(), 'User logged out', request.remote_addr)
    session.clear()
    return jsonify({'success': True})

@app.route('/api/auth/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        username  = (data.get('username') or '').strip()
        password  = (data.get('password') or '').strip()
        full_name = (data.get('full_name') or '').strip()
        if not username or not password or not full_name:
            return jsonify({'error': 'Username, password and full name required.'}), 400
        if len(password) < 6:
            return jsonify({'error': 'Password must be at least 6 characters.'}), 400
        if db.user_exists(username):
            return jsonify({'error': 'Username already taken.'}), 409
        db.create_user(data, hash_pw(password))
        return jsonify({'success': True, 'message': 'Account created! You can now login.'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/session', methods=['GET'])
def check_session():
    if authed():
        notif_count = db.get_unread_count(uid())
        return jsonify({'logged_in': True, 'username': session.get('username'), 'role': role(), 'full_name': session.get('full_name'), 'user_id': uid(), 'unread_notifications': notif_count})
    return jsonify({'logged_in': False}), 401

# ══════════════════════════════════════════════════════════════════
# BENEFICIARIES
# ══════════════════════════════════════════════════════════════════
@app.route('/api/beneficiaries', methods=['GET'])
def get_beneficiaries():
    try: return jsonify_rows(db.get_all_beneficiaries())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/beneficiaries', methods=['POST'])
def add_beneficiary():
    try:
        data = request.get_json()
        aadhaar = (data.get('aadhaar_number') or '').strip()
        family_id = (data.get('family_id') or '').strip()
        village = (data.get('village') or '').strip()
        digits = aadhaar.replace(' ','').replace('-','')
        if len(digits) != 12 or not digits.isdigit():
            return jsonify({'error': 'Aadhaar must be exactly 12 digits.'}), 400
        if db.aadhaar_exists(digits):
            return jsonify({'error': 'This Aadhaar is already registered. Duplicate not allowed.', 'duplicate': True, 'field': 'aadhaar'}), 409
        if family_id and db.family_id_exists(family_id):
            return jsonify({'error': f'Family ID "{family_id}" already registered.', 'duplicate': True, 'field': 'family_id'}), 409
        if village:
            valid = db.get_valid_villages()
            if village.lower() not in [v.lower() for v in valid]:
                return jsonify({'error': f'Village "{village}" not in service area.', 'invalid_village': True, 'valid_villages': valid}), 400
        result = db.add_beneficiary(data)
        db.log_audit(uid(), 'ADD_BENEFICIARY', 'beneficiary', result['id'], f"Added {data.get('name')}", request.remote_addr)
        return jsonify(result), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/beneficiaries/check-aadhaar', methods=['GET'])
def check_aadhaar():
    try:
        aadhaar = request.args.get('number','').strip()
        digits = aadhaar.replace(' ','').replace('-','')
        if len(digits) != 12: return jsonify({'valid': False, 'exists': False, 'message': 'Must be 12 digits'})
        if not digits.isdigit(): return jsonify({'valid': False, 'exists': False, 'message': 'Digits only'})
        exists = db.aadhaar_exists(digits)
        return jsonify({'valid': True, 'exists': exists, 'message': 'Aadhaar already registered.' if exists else 'Aadhaar available.'})
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/beneficiaries/check-family-id', methods=['GET'])
def check_family_id():
    try:
        fid = request.args.get('id','').strip()
        if not fid: return jsonify({'valid': False, 'exists': False})
        exists = db.family_id_exists(fid)
        return jsonify({'valid': True, 'exists': exists, 'message': f'Family ID "{fid}" already registered.' if exists else 'Family ID available.'})
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/beneficiaries/villages', methods=['GET'])
def get_villages():
    try: return jsonify(db.get_valid_villages())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/beneficiaries/duplicates', methods=['GET'])
def get_duplicates():
    try: return jsonify_rows(db.get_duplicate_beneficiaries())
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# SHOPS
# ══════════════════════════════════════════════════════════════════
@app.route('/api/shops', methods=['GET'])
def get_shops():
    try: return jsonify_rows(db.get_all_shops())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/shops/<int:shop_id>', methods=['GET'])
def get_shop(shop_id):
    try:
        shop = db.get_shop_by_id(shop_id)
        if not shop: return jsonify({'error': 'Shop not found'}), 404
        return jsonify_rows(shop)
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/shops', methods=['POST'])
def add_shop():
    try:
        data = request.get_json()
        if not data.get('shop_name') or not data.get('location'):
            return jsonify({'error': 'Shop name and location required.'}), 400
        result = db.add_shop(data)
        db.log_audit(uid(), 'ADD_SHOP', 'shop', result['id'], f"Added {data.get('shop_name')}", request.remote_addr)
        return jsonify(result), 201
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/shops/<int:shop_id>/status', methods=['PUT'])
def update_shop_status(shop_id):
    try:
        data = request.get_json()
        new_status = data.get('status')
        if new_status not in ('active','under_review','suspended','blocked'):
            return jsonify({'error': 'Invalid status'}), 400
        db.update_shop_status(shop_id, new_status)
        action_map = {'suspended': 'suspend', 'blocked': 'block', 'active': 'unblock'}
        action = action_map.get(new_status, 'assign')
        db.log_admin_action(uid(), 'shop', shop_id, action, data.get('reason',''))
        db.log_audit(uid(), f'SHOP_{new_status.upper()}', 'shop', shop_id, data.get('reason',''), request.remote_addr)
        return jsonify({'success': True, 'status': new_status})
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# ALLOCATIONS & DISTRIBUTIONS
# ══════════════════════════════════════════════════════════════════
@app.route('/api/allocations', methods=['GET'])
def get_allocations():
    try: return jsonify_rows(db.get_all_allocations())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/allocations', methods=['POST'])
def add_allocation():
    try:
        data = request.get_json()
        result = db.add_allocation(data)
        return jsonify(result), 201
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/distributions', methods=['GET'])
def get_distributions():
    try: return jsonify_rows(db.get_all_distributions())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/distributions', methods=['POST'])
def add_distribution():
    try:
        data = request.get_json()
        result = db.add_distribution(data)
        return jsonify(result), 201
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# FRAUD CASES
# ══════════════════════════════════════════════════════════════════
@app.route('/api/cases', methods=['GET'])
def get_cases():
    try: return jsonify_rows(db.get_all_cases())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/cases/<int:case_id>', methods=['GET'])
def get_case(case_id):
    try:
        case = db.get_case_by_id(case_id)
        if not case: return jsonify({'error': 'Case not found'}), 404
        notes = db.get_case_notes(case_id)
        return jsonify_rows({'case': case, 'notes': notes})
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/cases', methods=['POST'])
def create_case():
    try:
        data = request.get_json()
        result = db.create_case(data, uid())
        db.log_audit(uid(), 'CREATE_CASE', 'fraud_case', result['id'], f"Created {result['case_number']}", request.remote_addr)
        return jsonify(result), 201
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/cases/<int:case_id>/status', methods=['PUT'])
def update_case_status(case_id):
    try:
        data = request.get_json()
        result = db.update_case_status(case_id, data.get('status'))
        db.log_audit(uid(), 'UPDATE_CASE', 'fraud_case', case_id, f"Status → {data.get('status')}", request.remote_addr)
        return jsonify(result)
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/cases/<int:case_id>/notes', methods=['GET'])
def get_notes(case_id):
    try: return jsonify_rows(db.get_case_notes(case_id))
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/cases/<int:case_id>/notes', methods=['POST'])
def add_note(case_id):
    try:
        data = request.get_json()
        result = db.add_case_note(case_id, uid(), data.get('note_text',''), data.get('is_internal', True))
        return jsonify(result), 201
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# FRAUD ALERTS
# ══════════════════════════════════════════════════════════════════
@app.route('/api/alerts', methods=['GET'])
def get_alerts():
    try: return jsonify_rows(db.get_all_alerts())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/alerts', methods=['POST'])
def create_alert():
    try:
        data = request.get_json()
        result = db.create_alert(data)
        return jsonify(result), 201
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/alerts/<int:alert_id>/acknowledge', methods=['PUT'])
def acknowledge_alert(alert_id):
    try:
        result = db.acknowledge_alert(alert_id, uid())
        return jsonify(result)
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# COMPLAINTS
# ══════════════════════════════════════════════════════════════════
@app.route('/api/complaints', methods=['GET'])
def get_complaints():
    try: return jsonify_rows(db.get_all_complaints())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/complaints', methods=['POST'])
def create_complaint():
    try:
        data = request.get_json()
        if not data.get('complainant_name') or not data.get('description'):
            return jsonify({'error': 'Name and description required.'}), 400
        result = db.create_complaint(data)
        return jsonify(result), 201
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/complaints/<int:complaint_id>', methods=['PUT'])
def update_complaint(complaint_id):
    try:
        data = request.get_json()
        allowed = ['status','assigned_to','case_id','admin_notes']
        updates = {k: v for k, v in data.items() if k in allowed and v is not None}
        result = db.update_complaint(complaint_id, updates)
        return jsonify(result)
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# CERTIFICATES
# ══════════════════════════════════════════════════════════════════
@app.route('/api/certificates', methods=['GET'])
def get_certificates():
    try: return jsonify_rows(db.get_all_certificates())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/certificates/verify/<cert_uid>', methods=['GET'])
def verify_certificate(cert_uid):
    try:
        cert = db.get_cert_by_unique_id(cert_uid)
        if not cert: return jsonify({'valid': False, 'message': 'Certificate not found.'}), 404
        from datetime import date
        expired = False
        if cert.get('expiry_date') and cert['expiry_date'] < date.today():
            expired = True
        valid = cert['status'] == 'valid' and not expired
        return jsonify_rows({'valid': valid, 'status': cert['status'], 'expired': expired, 'certificate': cert})
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/certificates', methods=['POST'])
def create_certificate():
    try:
        data = request.get_json()
        result = db.create_certificate(data, uid())
        db.log_audit(uid(), 'ISSUE_CERT', 'certificate', result['id'], f"Issued {result['cert_unique_id']}", request.remote_addr)
        return jsonify(result), 201
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/certificates/<int:cert_id>/revoke', methods=['PUT'])
def revoke_cert(cert_id):
    try:
        data = request.get_json()
        result = db.revoke_certificate(cert_id, uid(), data.get('reason',''))
        db.log_admin_action(uid(), 'certificate', cert_id, 'revoke_cert', data.get('reason',''))
        db.log_audit(uid(), 'REVOKE_CERT', 'certificate', cert_id, data.get('reason',''), request.remote_addr)
        return jsonify(result)
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# NOTIFICATIONS
# ══════════════════════════════════════════════════════════════════
@app.route('/api/notifications', methods=['GET'])
def get_notifications():
    try:
        if not authed(): return jsonify({'error': 'Not authenticated'}), 401
        return jsonify_rows(db.get_user_notifications(uid()))
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/notifications/read', methods=['PUT'])
def mark_read():
    try:
        db.mark_notifications_read(uid())
        return jsonify({'success': True})
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# USERS (Admin)
# ══════════════════════════════════════════════════════════════════
@app.route('/api/users', methods=['GET'])
def get_users():
    try: return jsonify_rows(db.get_all_users())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/users/<int:user_id>/status', methods=['PUT'])
def update_user_status(user_id):
    try:
        data = request.get_json()
        new_status = data.get('status')
        if new_status not in ('active','suspended','blocked'):
            return jsonify({'error': 'Invalid status'}), 400
        db.update_user_status(user_id, new_status)
        action = 'suspend' if new_status == 'suspended' else 'block' if new_status == 'blocked' else 'unblock'
        db.log_admin_action(uid(), 'user', user_id, action, data.get('reason',''))
        return jsonify({'success': True})
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# INTELLIGENCE / DETECTION
# ══════════════════════════════════════════════════════════════════
@app.route('/api/detect/leakage', methods=['GET'])
def detect_leakage():
    try: return jsonify_rows(de.run_all_detection())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/risk/scores', methods=['GET'])
def risk_scores():
    try: return jsonify_rows(rs.calculate_all_risk_scores())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/detect/face-verify', methods=['POST'])
def face_verify():
    """Simulate AI face verification (returns simulated confidence score)."""
    try:
        import random
        data = request.get_json() or {}
        score = round(random.uniform(40, 99), 1)
        if data.get('simulate_fail'): score = round(random.uniform(10, 40), 1)
        status = 'verified' if score >= 80 else 'suspicious' if score >= 55 else 'failed'
        liveness = score >= 70
        return jsonify({'confidence_score': score, 'status': status, 'liveness_passed': liveness,
                        'message': f"Face verification {status.upper()} — Confidence: {score}%"})
    except Exception as e: return jsonify({'error': str(e)}), 500

# ══════════════════════════════════════════════════════════════════
# DASHBOARD & ANALYTICS
# ══════════════════════════════════════════════════════════════════
@app.route('/api/dashboard/stats', methods=['GET'])
def dashboard_stats():
    try:
        stats = db.get_dashboard_stats()
        risk_data = rs.calculate_all_risk_scores()
        scores = risk_data.get('risk_scores', [])
        stats['high_risk_shops']     = len([s for s in scores if s['risk_score'] >= 61])
        stats['med_risk_shops']      = len([s for s in scores if 31 <= s['risk_score'] < 61])
        stats['low_risk_shops']      = len([s for s in scores if s['risk_score'] < 31])
        stats['avg_risk_score']      = risk_data.get('avg_risk', 0)
        return jsonify_rows(stats)
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/analytics/monthly', methods=['GET'])
def monthly_analytics():
    try: return jsonify_rows(db.get_monthly_stats())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/analytics/state', methods=['GET'])
def state_analytics():
    try: return jsonify_rows(db.get_state_fraud_data())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/admin/actions', methods=['GET'])
def get_admin_actions():
    try: return jsonify_rows(db.get_admin_actions())
    except Exception as e: return jsonify({'error': str(e)}), 500

@app.route('/api/audit/logs', methods=['GET'])
def get_audit_logs():
    try: return jsonify_rows(db.get_audit_logs())
    except Exception as e: return jsonify({'error': str(e)}), 500

# ── RUN ───────────────────────────────────────────────────────────
if __name__ == '__main__':
    print("=" * 60)
    print("  RATION GUARD — AI Fraud Monitoring Portal v3.0")
    print("  Server : http://localhost:5000")
    print("  Logins : admin/admin123 | officer1/officer123")
    print("           shopowner1/shop123 | publicuser1/user123")
    print("=" * 60)
    app.run(debug=True, port=5000)
