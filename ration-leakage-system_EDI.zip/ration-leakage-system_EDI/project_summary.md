# 🛡️ Ration Guard — Complete Project Summary

> **Ration Guard v3.0** — AI-Powered Fraud Monitoring & Certification Portal for India's Public Distribution System (PDS)

---

## 📁 What Was Built

### Project Structure
```
ration-leakage-system_EDI/
├── backend/
│   ├── app.py            ← Flask REST API (30+ endpoints)
│   ├── database.py       ← All MySQL DB functions
│   ├── detection_engine.py  ← Rule-based fraud detection
│   └── risk_scoring.py   ← Risk score calculator
├── frontend/
│   ├── index.html        ← Single-page app shell
│   ├── css/styles.css    ← Full dark theme CSS
│   └── js/
│       ├── core.js           ← Auth, sidebar, API calls
│       ├── pages_dashboard.js ← Dashboard + Shops + Beneficiaries
│       ├── pages_cases.js    ← Fraud Cases, Alerts, Complaints
│       ├── pages_certs.js    ← Certificates + Analytics
│       ├── pages_stock.js    ← ✅ NEW: Stock Allocation & Distribution
│       └── router.js         ← Page routing
├── database/
│   ├── schema.sql        ← Full database schema (16 tables)
│   └── sample_data.sql   ← SQL seed script
├── seed_data.py          ← Python seeder (100+ records)
└── HOW_TO_RUN.txt        ← Setup instructions
```

---

## 🗄️ Database — 16 Tables

| Table | Records | Purpose |
|-------|---------|---------|
| `users` | 10 | Admin, Officers, Shop Owners, Public |
| `ration_shops` | 15 | FPS shops with status & risk scores |
| `beneficiaries` | 56 | Registered beneficiaries (3 duplicate Aadhaar) |
| `ration_cards` | 40 | Family ration cards |
| `stock_allocations` | 60 | Monthly stock allocated per shop |
| `distribution_logs` | 75+ | Actual distributions recorded |
| `fraud_cases` | 20 | Active fraud investigations |
| `fraud_alerts` | 30 | System-generated warnings |
| `public_complaints` | 20 | Citizen-filed complaints |
| `certificates` | 15 | Shop digital licenses |
| `face_verification_logs` | 25 | Biometric auth logs |
| `notifications` | 7 | User alerts |
| `audit_logs` | — | All user actions tracked |
| `case_notes` | — | Investigation notes |
| `admin_actions` | — | Admin action history |
| `evidence_files` | — | Uploaded case evidence |

---

## 🚀 All Features Implemented

### 1. 🔐 Authentication System
- Login / Register with SHA-256 password hashing
- Role-based access: `super_admin`, `investigation_officer`, `shop_owner`, `public_user`
- Session management via Flask sessions
- Each role sees a different sidebar menu

**Logins:**
| Username | Password | Role |
|---|---|---|
| `admin` | `admin123` | Super Admin |
| `officer1` | `officer123` | Investigation Officer |
| `shop1` | `shop123` | Shop Owner |
| `pub1` | `user123` | Public User |

---

### 2. 📊 Dashboard
Live metrics shown on login:
- **Total Shops**: 15 (11 active · 1 blocked · 2 suspended · 1 under review)
- **Beneficiaries**: 56 registered in system
- **New Alerts**: 10 requiring immediate action
- **Open Cases**: 8 of 20 total
- **Leakage**: 37.3% — ~251,000 kg diverted
- **Complaints**: 20 public reports filed
- **Valid Certs**: 12 (2 revoked/blocked)
- **Face Failed**: 6 failed verifications

**Charts:**
- 🍩 **Risk Distribution Donut** — Low / Medium / High risk shop counts
- 📊 **Stock Overview Bar Chart** — Allocated vs Distributed per shop

---

### 3. 🏪 Shop Management
- View all 15 shops with risk scores, status badges, license numbers
- Filter by: Active / Suspended / Blocked / Under Review
- Search by shop name or location
- **Add New Shop** form (modal)
- **Change status**: Suspend / Block / Unblock any shop
- Risk score displayed with color-coded progress bar

---

### 4. 👥 Beneficiary Management
- View all 56 beneficiaries with Aadhaar, family ID, village, category
- **Register New Beneficiary** with:
  - ✅ Real-time Aadhaar duplicate check (12-digit validation)
  - ✅ Real-time Family ID duplicate check
  - ✅ Village/city dropdown (only valid service areas allowed)
- Show verification status (pending / verified / suspicious / failed)
- Face score shown per beneficiary

---

### 5. 📦 Stock Management *(NEW)*
**Allocations tab:**
- View all 60+ allocation records (shop + month + quantities)
- **Add New Allocation** form: Select shop, month, rice/wheat/sugar amounts
- Summary cards: total allocations, total rice/wheat/sugar in Tons
- Bar chart: top 8 shops by total allocated quantity
- Search/filter allocations

**Distribution tab:**
- View all 75+ distribution logs
- **Record Distribution**: Select shop, date, quantities given
- Leakage analysis panel with per-shop leakage % bars
- Summary: Total distributed, Leakage %, leaked kg

---

### 6. 🗂️ Fraud Cases (20 active cases)
- Full case table: Case #, Title, Shop, Type, Priority, Status, Risk Score, Officer, Deadline
- Filter by: Open / Under Review / Verified Fraud / Closed
- **Create New Case** (modal form)
- **View Case Details**: Full description + case notes
- Status update: Open → Under Review → Verified Fraud → Closed
- Risk score shown with animated progress bar
- Priority badges: Low / Medium / High / Critical

---

### 7. 🚨 Fraud Alerts (30 alerts)
- System-auto-generated alerts per shop/beneficiary
- Severity levels: Low / Medium / High / Critical
- Status: New / Acknowledged / Resolved
- **Acknowledge** button for officers
- Linked to shop and beneficiary records

---

### 8. 📝 Complaints (20 public complaints)
- View all citizen complaints with types and statuses
- Types: Overcharging, Fake Ration, Short Supply, Bribery, Ghost Beneficiary, Document Fraud
- Status flow: Submitted → Under Review → Assigned → Resolved / Rejected
- **File New Complaint** (available to all users)
- Linked to specific shops

---

### 9. 📜 Certificate Management (15 certificates)
- View all shop digital licenses
- Status: Valid / Expired / Revoked / Blocked
- **Issue New Certificate** (admin only)
- **Revoke Certificate** with reason
- **QR Code generation** for each certificate
- Certificate verification endpoint: `/api/certificates/verify/<CERT-ID>`

---

### 10. 👁️ Face Verification (AI Simulation)
- Simulated AI face verification with confidence score (30–99%)
- Status: Verified (≥80%) / Suspicious (55–79%) / Failed (<55%)
- Liveness detection flag
- 25 historical verification logs stored
- Repeated failures trigger fraud alerts

---

### 11. 📈 Analytics
- Monthly distribution trends
- State-wise fraud heatmap data
- Risk distribution charts
- Top suspicious shops ranking
- Leakage trend analysis

---

### 12. 👤 User Management (Admin)
- View all 10 users with roles and status
- Suspend / Block / Unblock users
- Audit log of all actions

---

## 🤖 How AI Analyzes Fraud

> **Important:** This system uses **Rule-Based AI** (also called Expert Systems / Deterministic AI), **NOT** traditional machine learning models like neural networks or classifiers. Here's a full explanation:

### What the System Does

#### 1. 📐 Rule-Based Fraud Detection (`detection_engine.py`)
The system runs automated rules that mimic what a fraud investigator would check:

```python
Rule 1: STOCK MISMATCH DETECTION
  If (allocated_kg - distributed_kg) / allocated_kg > 30%
  → Flag shop as HIGH LEAKAGE
  → Auto-generate Fraud Alert

Rule 2: DUPLICATE AADHAAR DETECTION
  If COUNT(aadhaar_number) > 1 for same normalized digits
  → Flag all records as DUPLICATE
  → Create fraud case automatically

Rule 3: GHOST BENEFICIARY DETECTION
  If a beneficiary has received rations but
  face_verification_status = 'failed' 3+ times
  → Suspend beneficiary
  → Alert officer

Rule 4: ABNORMAL TRANSACTION PATTERN
  If distribution_amount > allocated_amount for a month
  → Flag as IMPOSSIBLE TRANSACTION
  → Critical alert generated

Rule 5: LICENSE/CERTIFICATE ANOMALY
  If shop operating with expired/revoked certificate
  → Flag shop as non-compliant
  → Notify admin
```

#### 2. 🎯 Risk Scoring (`risk_scoring.py`)
Each shop gets a **Risk Score (0–100)** calculated as:

```
Risk Score = Weighted Sum of:
  ├── Leakage % from stock           → weight: 40%
  ├── Number of open complaints      → weight: 20%
  ├── Face verification failure rate → weight: 20%
  ├── Number of fraud alerts         → weight: 15%
  └── Duplicate beneficiaries linked → weight:  5%

Score 0–30   → LOW RISK (green)
Score 31–60  → MEDIUM RISK (yellow/orange)
Score 61–80  → HIGH RISK (red)
Score 81–100 → CRITICAL (dark red)
```

#### 3. 🔍 Real-Time Validation (Frontend + Backend)
- **Aadhaar duplicate detection**: Triggered as user types (debounced 600ms)
- **Family ID uniqueness**: Checked on field blur
- **Village validation**: Only known service areas accepted
- All validations run against the live MySQL database

---

### Is Machine Learning Used?

**No traditional ML (no neural networks, no training data, no model files).**

What the system uses instead:

| Technique | Used? | Where |
|---|---|---|
| Rule-based expert system | ✅ Yes | detection_engine.py |
| Statistical scoring | ✅ Yes | risk_scoring.py |
| Pattern matching (SQL) | ✅ Yes | Duplicate detection |
| Threshold-based alerts | ✅ Yes | Leakage detection |
| Simulated AI (face verify) | ✅ Yes | Random score simulation |
| Neural networks / ML models | ❌ No | Not implemented |
| Training datasets | ❌ No | Not needed |

### Why No ML?
For a **government PDS system**, rule-based AI is preferred because:
1. **Explainability** — Every decision can be explained ("This shop is flagged because leakage > 30%")
2. **Auditability** — All rules are documented and traceable
3. **No training data needed** — ML needs thousands of labeled fraud cases; rules work immediately
4. **Regulatory compliance** — Government systems require explainable decisions

### If You Wanted to Add Real ML (Future Scope):
- Train a **Random Forest / XGBoost** classifier on historical fraud cases
- Use **K-Means clustering** to group suspicious shops
- Implement **Isolation Forest** for anomaly detection in stock data
- Add **facial recognition** using OpenCV + DeepFace library

---

## 🔌 API Endpoints (30+)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/register` | Register |
| GET | `/api/auth/session` | Check session |
| GET | `/api/dashboard/stats` | All metrics |
| GET | `/api/beneficiaries` | List beneficiaries |
| POST | `/api/beneficiaries` | Add beneficiary |
| GET | `/api/beneficiaries/check-aadhaar` | Aadhaar check |
| GET | `/api/beneficiaries/check-family-id` | Family ID check |
| GET | `/api/beneficiaries/villages` | Valid villages |
| GET | `/api/beneficiaries/duplicates` | Dup Aadhaar list |
| GET | `/api/shops` | List shops |
| POST | `/api/shops` | Add shop |
| PUT | `/api/shops/:id/status` | Update status |
| GET | `/api/allocations` | List allocations |
| POST | `/api/allocations` | Add allocation |
| GET | `/api/distributions` | List distributions |
| POST | `/api/distributions` | Record distribution |
| GET | `/api/cases` | List cases |
| POST | `/api/cases` | Create case |
| PUT | `/api/cases/:id/status` | Update case |
| GET | `/api/alerts` | List alerts |
| POST | `/api/alerts` | Create alert |
| PUT | `/api/alerts/:id/acknowledge` | Acknowledge |
| GET | `/api/complaints` | List complaints |
| POST | `/api/complaints` | File complaint |
| GET | `/api/certificates` | List certs |
| POST | `/api/certificates` | Issue cert |
| PUT | `/api/certificates/:id/revoke` | Revoke cert |
| GET | `/api/certificates/verify/:uid` | Verify cert |
| POST | `/api/detect/face-verify` | Face verification |
| GET | `/api/detect/leakage` | Run detection |
| GET | `/api/risk/scores` | All risk scores |
| GET | `/api/analytics/monthly` | Monthly stats |
| GET | `/api/users` | List users |
| GET | `/api/notifications` | Get notifications |

---

## ▶️ How to Run

### Prerequisites
```bash
pip install flask flask-cors pymysql pandas
MySQL running with database: ration_system
```

### Steps
```bash
# 1. Run schema
mysql -u root -p < database/schema.sql

# 2. Seed data
python seed_data.py

# 3. Start server
cd backend
python app.py

# 4. Open browser
http://localhost:5000
# Login: admin / admin123
```

---

## 📌 Viva One-Liner
> *"Ration Guard is a full-stack AI-powered fraud monitoring portal for India's PDS system. It uses rule-based fraud detection with weighted risk scoring across 16 database tables. The system detects stock leakage, duplicate Aadhaar beneficiaries, ghost shops, and suspicious transactions in real-time — with role-based access for admins, officers, shop owners, and the public."*
