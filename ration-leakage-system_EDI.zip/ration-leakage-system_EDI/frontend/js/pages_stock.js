// ══════════════════════════════════════════════════════════════
// pages_stock.js — Stock Allocation & Distribution Management
// ══════════════════════════════════════════════════════════════

let stockAllocations = [];
let stockDistributions = [];
let stockShops = [];
let stockCards = [];

async function renderStock() {
  const pg = document.getElementById('page-stock');
  if (!pg) return;
  pg.innerHTML = `
  <div class="section-header">
    <div><h2>📦 Stock Management</h2><p style="color:var(--text3);font-size:13px;margin-top:4px">Allocate stock to shops and record distributions</p></div>
  </div>

  <!-- Tabs -->
  <div class="filter-bar" style="margin-bottom:20px">
    <button class="filter-btn active" id="stab-alloc" onclick="switchStockTab('alloc')">📋 Stock Allocations</button>
    <button class="filter-btn" id="stab-dist" onclick="switchStockTab('dist')">📤 Distribution Logs</button>
  </div>

  <!-- ALLOCATION PANEL -->
  <div id="stock-panel-alloc">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px">
      <!-- Add Allocation Form -->
      <div class="card">
        <div class="card-header"><h3>➕ Add Stock Allocation</h3></div>
        <div id="alloc-error" class="alert-box error" style="display:none;margin-bottom:12px"></div>
        <div class="form-group">
          <label>Shop</label>
          <select id="alloc-shop" class="form-input" style="background:var(--card2);border:1px solid var(--border)">
            <option value="">— Select Shop —</option>
          </select>
        </div>
        <div class="form-group">
          <label>Month</label>
          <select id="alloc-month" class="form-input" style="background:var(--card2);border:1px solid var(--border)">
            <option>January 2025</option><option>February 2025</option><option>March 2025</option>
            <option>April 2025</option><option>May 2025</option><option>June 2025</option>
            <option>July 2025</option><option>August 2025</option><option>September 2025</option>
            <option>October 2025</option><option>November 2025</option><option>December 2025</option>
          </select>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
          <div class="form-group">
            <label>Rice (kg)</label>
            <input id="alloc-rice" type="number" min="0" placeholder="5000" class="form-input"/>
          </div>
          <div class="form-group">
            <label>Wheat (kg)</label>
            <input id="alloc-wheat" type="number" min="0" placeholder="3000" class="form-input"/>
          </div>
          <div class="form-group">
            <label>Sugar (kg)</label>
            <input id="alloc-sugar" type="number" min="0" placeholder="500" class="form-input"/>
          </div>
        </div>
        <button class="btn btn-primary" onclick="submitAllocation()" style="width:100%;margin-top:8px">
          📦 Allocate Stock
        </button>
      </div>

      <!-- Allocation Summary -->
      <div class="card">
        <div class="card-header"><h3>📊 Allocation Summary</h3></div>
        <div id="alloc-summary">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
            <div class="stat-mini"><div class="stat-mini-val" id="s-total-alloc">—</div><div class="stat-mini-lab">Total Allocations</div></div>
            <div class="stat-mini"><div class="stat-mini-val" id="s-total-rice">—</div><div class="stat-mini-lab">Total Rice (T)</div></div>
            <div class="stat-mini"><div class="stat-mini-val" id="s-total-wheat">—</div><div class="stat-mini-lab">Total Wheat (T)</div></div>
            <div class="stat-mini"><div class="stat-mini-val" id="s-total-sugar">—</div><div class="stat-mini-lab">Total Sugar (T)</div></div>
          </div>
          <canvas id="alloc-chart" height="150"></canvas>
        </div>
      </div>
    </div>

    <!-- Allocations Table -->
    <div class="card">
      <div class="card-header">
        <h3>All Allocations <span id="alloc-count" class="badge" style="margin-left:8px"></span></h3>
        <input id="alloc-search" class="search-box" placeholder="Search shop or month..." oninput="filterAllocations()" style="width:200px"/>
      </div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>#</th><th>Shop</th><th>Month</th><th>Rice (kg)</th><th>Wheat (kg)</th><th>Sugar (kg)</th><th>Total (kg)</th></tr></thead>
          <tbody id="alloc-tbody"></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- DISTRIBUTION PANEL -->
  <div id="stock-panel-dist" style="display:none">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px">
      <!-- Record Distribution Form -->
      <div class="card">
        <div class="card-header"><h3>📤 Record Distribution</h3></div>
        <div id="dist-error" class="alert-box error" style="display:none;margin-bottom:12px"></div>
        <div class="form-group">
          <label>Shop</label>
          <select id="dist-shop" class="form-input" style="background:var(--card2);border:1px solid var(--border)">
            <option value="">— Select Shop —</option>
          </select>
        </div>
        <div class="form-group">
          <label>Date</label>
          <input id="dist-date" type="date" class="form-input" value="${new Date().toISOString().split('T')[0]}"/>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
          <div class="form-group">
            <label>Rice Given (kg)</label>
            <input id="dist-rice" type="number" min="0" placeholder="1200" class="form-input"/>
          </div>
          <div class="form-group">
            <label>Wheat Given (kg)</label>
            <input id="dist-wheat" type="number" min="0" placeholder="800" class="form-input"/>
          </div>
          <div class="form-group">
            <label>Sugar Given (kg)</label>
            <input id="dist-sugar" type="number" min="0" placeholder="120" class="form-input"/>
          </div>
        </div>
        <div style="padding:12px;background:rgba(255,184,0,.06);border:1px solid rgba(255,184,0,.15);border-radius:8px;margin-bottom:12px;font-size:12px;color:var(--yellow)">
          ⚠️ Distribution is recorded against the earliest available ration card for this shop.
        </div>
        <button class="btn btn-primary" onclick="submitDistribution()" style="width:100%">
          📤 Record Distribution
        </button>
      </div>

      <!-- Leakage Summary -->
      <div class="card">
        <div class="card-header"><h3>🔍 Leakage Analysis</h3></div>
        <div id="leak-summary">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
            <div class="stat-mini"><div class="stat-mini-val" id="s-total-dist">—</div><div class="stat-mini-lab">Total Distributed</div></div>
            <div class="stat-mini leak"><div class="stat-mini-val" id="s-leakage-pct" style="color:var(--red)">—</div><div class="stat-mini-lab">Leakage %</div></div>
            <div class="stat-mini"><div class="stat-mini-val" id="s-dist-count">—</div><div class="stat-mini-lab">Distribution Logs</div></div>
            <div class="stat-mini leak"><div class="stat-mini-val" id="s-leakage-kg" style="color:var(--red)">—</div><div class="stat-mini-lab">Leaked (kg)</div></div>
          </div>
          <div id="leakage-bars"></div>
        </div>
      </div>
    </div>

    <!-- Distribution Logs Table -->
    <div class="card">
      <div class="card-header">
        <h3>Distribution Logs <span id="dist-count" class="badge" style="margin-left:8px"></span></h3>
        <input id="dist-search" class="search-box" placeholder="Search shop..." oninput="filterDistributions()" style="width:200px"/>
      </div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>#</th><th>Shop</th><th>Date</th><th>Rice (kg)</th><th>Wheat (kg)</th><th>Sugar (kg)</th><th>Total (kg)</th></tr></thead>
          <tbody id="dist-tbody"></tbody>
        </table>
      </div>
    </div>
  </div>`;

  await loadStockData();
}

async function loadStockData() {
  const [r1, r2, r3, r4] = await Promise.all([
    apiFetch('/allocations'),
    apiFetch('/distributions'),
    apiFetch('/shops'),
    apiFetch('/dashboard/stats')
  ]);

  stockAllocations  = r1.ok && Array.isArray(r1.data) ? r1.data : [];
  stockDistributions = r2.ok && Array.isArray(r2.data) ? r2.data : [];
  stockShops = r3.ok && Array.isArray(r3.data) ? r3.data : [];

  // Populate shop dropdowns
  ['alloc-shop', 'dist-shop'].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = '<option value="">— Select Shop —</option>';
    stockShops.forEach(s => {
      const o = document.createElement('option');
      o.value = s.shop_id; o.textContent = s.shop_name;
      sel.appendChild(o);
    });
  });

  renderAllocTable();
  renderDistTable();
  renderAllocSummary(r4.ok ? r4.data : {});
  renderLeakageSummary(r4.ok ? r4.data : {});
}

function renderAllocTable() {
  const tbody = document.getElementById('alloc-tbody');
  if (!tbody) return;
  document.getElementById('alloc-count').textContent = `${stockAllocations.length} records`;
  if (!stockAllocations.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No allocations found</td></tr>'; return;
  }
  tbody.innerHTML = stockAllocations.map((a, i) => {
    const total = (parseFloat(a.rice_allocated)||0) + (parseFloat(a.wheat_allocated)||0) + (parseFloat(a.sugar_allocated)||0);
    return `<tr>
      <td>${i+1}</td>
      <td><strong>${esc(a.shop_name||'—')}</strong></td>
      <td>${esc(a.month||'—')}</td>
      <td>${num(a.rice_allocated)}</td>
      <td>${num(a.wheat_allocated)}</td>
      <td>${num(a.sugar_allocated)}</td>
      <td><strong>${num(total)}</strong></td>
    </tr>`;
  }).join('');
}

function renderDistTable() {
  const tbody = document.getElementById('dist-tbody');
  if (!tbody) return;
  document.getElementById('dist-count').textContent = `${stockDistributions.length} records`;
  if (!stockDistributions.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No distribution logs found</td></tr>'; return;
  }
  tbody.innerHTML = stockDistributions.map((d, i) => {
    const total = (parseFloat(d.rice_given)||0) + (parseFloat(d.wheat_given)||0) + (parseFloat(d.sugar_given)||0);
    return `<tr>
      <td>${i+1}</td>
      <td><strong>${esc(d.shop_name||'—')}</strong></td>
      <td>${d.date ? d.date.split('T')[0] : '—'}</td>
      <td>${num(d.rice_given)}</td>
      <td>${num(d.wheat_given)}</td>
      <td>${num(d.sugar_given)}</td>
      <td><strong>${num(total)}</strong></td>
    </tr>`;
  }).join('');
}

function renderAllocSummary(stats) {
  const totalAlloc = stockAllocations.length;
  let rice=0, wheat=0, sugar=0;
  stockAllocations.forEach(a => { rice+=parseFloat(a.rice_allocated)||0; wheat+=parseFloat(a.wheat_allocated)||0; sugar+=parseFloat(a.sugar_allocated)||0; });
  setEl('s-total-alloc', totalAlloc);
  setEl('s-total-rice',  (rice/1000).toFixed(1)+'T');
  setEl('s-total-wheat', (wheat/1000).toFixed(1)+'T');
  setEl('s-total-sugar', (sugar/1000).toFixed(1)+'T');

  // Bar chart: top 8 shops by allocation
  const shopMap = {};
  stockAllocations.forEach(a => {
    const key = a.shop_name || 'Unknown';
    if (!shopMap[key]) shopMap[key] = 0;
    shopMap[key] += (parseFloat(a.rice_allocated)||0) + (parseFloat(a.wheat_allocated)||0) + (parseFloat(a.sugar_allocated)||0);
  });
  const sorted = Object.entries(shopMap).sort((a,b)=>b[1]-a[1]).slice(0,8);
  const ctx = document.getElementById('alloc-chart');
  if (ctx) {
    if (window._stockChart) window._stockChart.destroy();
    window._stockChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: sorted.map(s=>s[0].replace(' FPS','').replace(' No.2','')),
        datasets: [{ label: 'Total Allocated (kg)', data: sorted.map(s=>s[1]),
          backgroundColor: 'rgba(0,194,255,0.6)', borderColor: '#00c2ff', borderWidth: 1, borderRadius: 4 }]
      },
      options: { responsive:true, plugins:{ legend:{display:false} },
        scales:{ x:{ticks:{color:'#4d6a8a',font:{size:9}},grid:{display:false}},
                 y:{ticks:{color:'#4d6a8a',font:{size:9}},grid:{color:'rgba(0,194,255,0.06)'}} } }
    });
  }
}

function renderLeakageSummary(stats) {
  const distKg = parseFloat(stats.distributed_kg||0);
  const allocKg = parseFloat(stats.allocated_kg||0);
  const leakKg  = allocKg - distKg;
  const leakPct = allocKg > 0 ? ((leakKg/allocKg)*100).toFixed(1) : 0;
  setEl('s-total-dist',  (distKg/1000).toFixed(1)+'T');
  setEl('s-leakage-pct', leakPct+'%');
  setEl('s-dist-count',  stockDistributions.length);
  setEl('s-leakage-kg',  Math.round(leakKg).toLocaleString()+' kg');

  // Per-shop leakage bars
  const bars = document.getElementById('leakage-bars');
  if (!bars) return;
  const HIGH_RISK_SHOPS = [
    {name:'Agra North',pct:80},{name:'Lucknow Central',pct:72},{name:'Azamnagar',pct:62},
    {name:'Meerut',pct:55},{name:'Aligarh',pct:65},{name:'Kasimpur',pct:25},
    {name:'Nagpur',pct:45},{name:'Kanpur',pct:30}
  ];
  bars.innerHTML = '<div style="font-size:12px;color:var(--text3);margin-bottom:10px">Top shops by leakage rate</div>' +
    HIGH_RISK_SHOPS.map(s => {
      const color = s.pct>=60?'var(--red)':s.pct>=35?'var(--yellow)':'var(--green)';
      return `<div style="margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px">
          <span style="color:var(--text2)">${s.name}</span>
          <span style="color:${color};font-weight:700">${s.pct}%</span>
        </div>
        <div style="height:6px;background:var(--border);border-radius:3px">
          <div style="height:6px;width:${s.pct}%;background:${color};border-radius:3px;transition:width .8s"></div>
        </div>
      </div>`;
    }).join('');
}

function filterAllocations() {
  const q = (document.getElementById('alloc-search')?.value||'').toLowerCase();
  const filtered = stockAllocations.filter(a =>
    (a.shop_name||'').toLowerCase().includes(q) || (a.month||'').toLowerCase().includes(q)
  );
  const tbody = document.getElementById('alloc-tbody');
  if (!tbody) return;
  if (!filtered.length) { tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No results</td></tr>'; return; }
  tbody.innerHTML = filtered.map((a,i)=>{
    const t=(parseFloat(a.rice_allocated)||0)+(parseFloat(a.wheat_allocated)||0)+(parseFloat(a.sugar_allocated)||0);
    return `<tr><td>${i+1}</td><td><strong>${esc(a.shop_name||'—')}</strong></td><td>${esc(a.month||'—')}</td><td>${num(a.rice_allocated)}</td><td>${num(a.wheat_allocated)}</td><td>${num(a.sugar_allocated)}</td><td><strong>${num(t)}</strong></td></tr>`;
  }).join('');
}

function filterDistributions() {
  const q = (document.getElementById('dist-search')?.value||'').toLowerCase();
  const filtered = stockDistributions.filter(d => (d.shop_name||'').toLowerCase().includes(q));
  const tbody = document.getElementById('dist-tbody');
  if (!tbody) return;
  if (!filtered.length) { tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No results</td></tr>'; return; }
  tbody.innerHTML = filtered.map((d,i)=>{
    const t=(parseFloat(d.rice_given)||0)+(parseFloat(d.wheat_given)||0)+(parseFloat(d.sugar_given)||0);
    return `<tr><td>${i+1}</td><td><strong>${esc(d.shop_name||'—')}</strong></td><td>${d.date?d.date.split('T')[0]:'—'}</td><td>${num(d.rice_given)}</td><td>${num(d.wheat_given)}</td><td>${num(d.sugar_given)}</td><td><strong>${num(t)}</strong></td></tr>`;
  }).join('');
}

function switchStockTab(tab) {
  ['alloc','dist'].forEach(t => {
    document.getElementById(`stab-${t}`)?.classList.toggle('active', t===tab);
    const p = document.getElementById(`stock-panel-${t}`);
    if (p) p.style.display = t===tab ? '' : 'none';
  });
}

async function submitAllocation() {
  const shop_id = document.getElementById('alloc-shop')?.value;
  const month   = document.getElementById('alloc-month')?.value;
  const rice    = document.getElementById('alloc-rice')?.value;
  const wheat   = document.getElementById('alloc-wheat')?.value;
  const sugar   = document.getElementById('alloc-sugar')?.value;
  const errEl   = document.getElementById('alloc-error');

  if (!shop_id) { showFieldErr(errEl,'Please select a shop.'); return; }
  if (!rice && !wheat && !sugar) { showFieldErr(errEl,'Enter at least one quantity.'); return; }

  const { ok, data } = await apiFetch('/allocations','POST',{
    shop_id: parseInt(shop_id), month,
    rice_allocated: parseFloat(rice||0),
    wheat_allocated: parseFloat(wheat||0),
    sugar_allocated: parseFloat(sugar||0)
  });
  if (ok) {
    showToast('✅ Stock allocated successfully!');
    errEl.style.display='none';
    ['alloc-shop','alloc-rice','alloc-wheat','alloc-sugar'].forEach(id => { const el=document.getElementById(id); if(el) el.value=''; });
    await loadStockData();
  } else {
    showFieldErr(errEl, data.error||'Allocation failed.');
  }
}

async function submitDistribution() {
  const shop_id = document.getElementById('dist-shop')?.value;
  const date    = document.getElementById('dist-date')?.value;
  const rice    = document.getElementById('dist-rice')?.value;
  const wheat   = document.getElementById('dist-wheat')?.value;
  const sugar   = document.getElementById('dist-sugar')?.value;
  const errEl   = document.getElementById('dist-error');

  if (!shop_id) { showFieldErr(errEl,'Please select a shop.'); return; }
  if (!rice && !wheat && !sugar) { showFieldErr(errEl,'Enter at least one quantity.'); return; }

  const { ok, data } = await apiFetch('/distributions','POST',{
    shop_id: parseInt(shop_id), date,
    rice_given: parseFloat(rice||0),
    wheat_given: parseFloat(wheat||0),
    sugar_given: parseFloat(sugar||0)
  });
  if (ok) {
    showToast('✅ Distribution recorded!');
    errEl.style.display='none';
    ['dist-rice','dist-wheat','dist-sugar'].forEach(id => { const el=document.getElementById(id); if(el) el.value=''; });
    await loadStockData();
  } else {
    showFieldErr(errEl, data.error||'Failed to record distribution.');
  }
}

function showFieldErr(el, msg) {
  if (!el) return;
  el.textContent = '❌ ' + msg;
  el.style.display = 'block';
  setTimeout(()=>el.style.display='none', 4000);
}

function num(v) { return Number(parseFloat(v)||0).toLocaleString(); }
function setEl(id,v){ const e=document.getElementById(id); if(e) e.textContent=v; }
