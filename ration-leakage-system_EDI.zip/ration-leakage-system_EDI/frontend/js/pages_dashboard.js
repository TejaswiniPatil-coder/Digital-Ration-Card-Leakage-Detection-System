// ── DASHBOARD ─────────────────────────────────────────────────────
async function renderDashboard() {
  const pg = document.getElementById('page-dashboard');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading dashboard...</div>';
  const [statsR, alertsR] = await Promise.all([apiFetch('/dashboard/stats'), apiFetch('/alerts')]);
  const s = statsR.ok ? statsR.data : {};
  const alerts = alertsR.ok ? (alertsR.data||[]).filter(a=>a.status==='new').slice(0,5) : [];
  pg.innerHTML = `
  <div class="stat-grid">
    <div class="stat-card blue"><div class="s-icon">🏪</div><div class="s-label">Total Shops</div><div class="s-val">${s.shops||0}</div><div class="s-sub">${s.active_shops||0} active · ${s.blocked_shops||0} blocked</div></div>
    <div class="stat-card green"><div class="s-icon">👥</div><div class="s-label">Beneficiaries</div><div class="s-val">${s.beneficiaries||0}</div><div class="s-sub">Registered in system</div></div>
    <div class="stat-card red"><div class="s-icon">🚨</div><div class="s-label">New Alerts</div><div class="s-val">${s.new_alerts||0}</div><div class="s-sub">Require immediate action</div></div>
    <div class="stat-card yellow"><div class="s-icon">🗂️</div><div class="s-label">Open Cases</div><div class="s-val">${s.open_cases||0}</div><div class="s-sub">of ${s.total_cases||0} total</div></div>
    <div class="stat-card orange"><div class="s-icon">⚠️</div><div class="s-label">Leakage</div><div class="s-val">${s.leakage_percent||0}%</div><div class="s-sub">${(s.leakage_kg||0).toFixed(0)} kg diverted</div></div>
    <div class="stat-card purple"><div class="s-icon">📝</div><div class="s-label">Complaints</div><div class="s-val">${s.total_complaints||0}</div><div class="s-sub">Public reports filed</div></div>
    <div class="stat-card green"><div class="s-icon">📜</div><div class="s-label">Valid Certs</div><div class="s-val">${s.valid_certs||0}</div><div class="s-sub">${s.revoked_certs||0} revoked/blocked</div></div>
    <div class="stat-card red"><div class="s-icon">🔬</div><div class="s-label">Face Failed</div><div class="s-val">${s.face_failed||0}</div><div class="s-sub">${s.face_verified||0} verified successfully</div></div>
  </div>
  <div class="grid-2" style="gap:20px;margin-bottom:20px">
    <div class="chart-wrap"><div class="card-title">📊 Risk Distribution</div><canvas id="chart-risk"></canvas></div>
    <div class="chart-wrap"><div class="card-title">📦 Stock Overview</div><canvas id="chart-stock"></canvas></div>
  </div>
  <div class="grid-2" style="gap:20px">
    <div>
      <div class="card-title" style="color:#fff;margin-bottom:12px">🚨 Recent Alerts</div>
      ${alerts.length ? alerts.map(a=>`
        <div class="alert-item ${a.severity||'medium'}">
          <div class="a-icon">${a.severity==='critical'?'🔴':a.severity==='high'?'🟠':'🟡'}</div>
          <div style="flex:1">
            <div class="a-title">${esc(a.alert_type)}</div>
            <div class="a-desc">${esc(a.description||'').slice(0,80)}...</div>
            <div class="a-time">${statusBadge(a.severity)} · ${timeAgo(a.created_at)}</div>
          </div>
          <button class="btn btn-sm btn-secondary" onclick="showPage('alerts')">View</button>
        </div>`).join('') : '<div class="empty-state"><div class="e-icon">✅</div><p>No new alerts</p></div>'}
    </div>
    <div>
      <div class="card-title" style="color:#fff;margin-bottom:12px">🏪 Shop Risk Overview</div>
      <div class="table-wrap">
        <table><thead><tr><th>Shop</th><th>Status</th><th>Risk</th></tr></thead>
        <tbody id="dash-shops-body"><tr><td colspan="3" class="text-muted" style="text-align:center">Loading...</td></tr></tbody>
        </table>
      </div>
    </div>
  </div>`;
  renderDashboardCharts(s);
  loadDashboardShops();
}

async function loadDashboardShops() {
  const r = await apiFetch('/shops');
  if (!r.ok) return;
  const shops = (r.data||[]).slice(0,6);
  document.getElementById('dash-shops-body').innerHTML = shops.map(s=>`
    <tr>
      <td><strong style="color:#fff">${esc(s.shop_name)}</strong><br><small class="text-muted">${esc(s.location)}</small></td>
      <td>${statusBadge(s.status)}</td>
      <td>${riskBadge(s.fraud_risk_score||0)}</td>
    </tr>`).join('');
}

function renderDashboardCharts(s) {
  const riskCtx = document.getElementById('chart-risk');
  if (riskCtx) new Chart(riskCtx, { type:'doughnut', data:{ labels:['Low Risk','Medium Risk','High Risk'],
    datasets:[{data:[s.low_risk_shops||3, s.med_risk_shops||2, s.high_risk_shops||5],
    backgroundColor:['#10b981','#f59e0b','#ef4444'], borderWidth:0}]},
    options:{ plugins:{legend:{labels:{color:'#94a3b8',font:{family:'Inter'}}}}, cutout:'65%' }});
  const stockCtx = document.getElementById('chart-stock');
  if (stockCtx) new Chart(stockCtx, { type:'bar', data:{
    labels:['Jan','Feb','Mar'], datasets:[
      {label:'Allocated',data:[s.allocated_kg?s.allocated_kg/3:4500, s.allocated_kg?s.allocated_kg/3:4500, s.allocated_kg?s.allocated_kg/3:4600], backgroundColor:'rgba(59,130,246,.6)'},
      {label:'Distributed',data:[s.distributed_kg?s.distributed_kg/3:3800, s.distributed_kg?s.distributed_kg/3:3900, s.distributed_kg?s.distributed_kg/3:3700], backgroundColor:'rgba(16,185,129,.6)'}
    ]}, options:{plugins:{legend:{labels:{color:'#94a3b8'}}}, scales:{x:{ticks:{color:'#64748b'},grid:{color:'rgba(255,255,255,.04)'}}, y:{ticks:{color:'#64748b'},grid:{color:'rgba(255,255,255,.04)'}}}}});
}

// ── SHOPS ─────────────────────────────────────────────────────────
async function renderShops() {
  const pg = document.getElementById('page-shops');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading shops...</div>';
  const r = await apiFetch('/shops');
  if (!r.ok) { pg.innerHTML = `<div class="alert-box error">Failed to load: ${r.data.error}</div>`; return; }
  const shops = r.data || [];
  const isAdmin = ['super_admin','investigation_officer'].includes(currentUser.role);
  pg.innerHTML = `
  <div class="section-header">
    <div><h2>🏪 Shop Management</h2><p>${shops.length} registered shops</p></div>
    ${isAdmin ? `<button class="btn btn-primary btn-sm" onclick="showAddShopModal()">➕ Add Shop</button>` : ''}
  </div>
  <div class="filter-bar">
    <div class="filter-chip active" onclick="filterShops('all',this)">All (${shops.length})</div>
    <div class="filter-chip" onclick="filterShops('active',this)">Active (${shops.filter(s=>s.status==='active').length})</div>
    <div class="filter-chip" onclick="filterShops('suspended',this)">Suspended (${shops.filter(s=>s.status==='suspended').length})</div>
    <div class="filter-chip" onclick="filterShops('blocked',this)">Blocked (${shops.filter(s=>s.status==='blocked').length})</div>
    <div class="filter-chip" onclick="filterShops('under_review',this)">Under Review (${shops.filter(s=>s.status==='under_review').length})</div>
  </div>
  <div class="table-wrap">
    <div class="table-head">
      <h3>All Shops</h3>
      <div class="search-box">🔍 <input type="text" placeholder="Search shops..." id="shop-search" oninput="searchShops(this.value)"/></div>
    </div>
    <div style="overflow-x:auto">
    <table id="shops-table">
      <thead><tr><th>#</th><th>Shop Name</th><th>Location</th><th>Dealer</th><th>License</th><th>Status</th><th>Risk Score</th><th>Certificate</th>${isAdmin?'<th>Actions</th>':''}</tr></thead>
      <tbody id="shops-tbody">${renderShopsRows(shops, isAdmin)}</tbody>
    </table></div>
  </div>`;
  window._shopsData = shops;
}

function renderShopsRows(shops, isAdmin) {
  if (!shops.length) return '<tr><td colspan="9"><div class="empty-state"><div class="e-icon">🏪</div><p>No shops found</p></div></td></tr>';
  return shops.map((s,i)=>`
    <tr data-status="${s.status}">
      <td style="color:var(--text3)">${i+1}</td>
      <td><strong style="color:#fff">${esc(s.shop_name)}</strong><br><small class="text-muted">${esc(s.district||'')} · ${esc(s.state||'')}</small></td>
      <td>${esc(s.location||'—')}</td>
      <td>${esc(s.dealer_name||'—')}<br><small class="text-muted">${esc(s.dealer_phone||'')}</small></td>
      <td><code style="font-size:11px;color:var(--accent2)">${esc(s.license_number||'—')}</code></td>
      <td>${statusBadge(s.status)}</td>
      <td>${riskBadge(s.fraud_risk_score||0)}</td>
      <td>${statusBadge(s.certificate_status||'—')}<br><small class="text-muted">${fmtDate(s.certificate_expiry)}</small></td>
      ${isAdmin?`<td><div class="d-flex gap-8">
        <button class="btn btn-sm btn-secondary" onclick="viewShopDetail(${s.shop_id})">👁</button>
        ${s.status!=='blocked'?`<button class="btn btn-sm btn-danger" onclick="updateShopStatus(${s.shop_id},'blocked')">🚫</button>`:''}
        ${s.status==='blocked'?`<button class="btn btn-sm btn-success" onclick="updateShopStatus(${s.shop_id},'active')">✅</button>`:''}
        ${s.status==='active'?`<button class="btn btn-sm btn-warning" onclick="updateShopStatus(${s.shop_id},'suspended')">⏸</button>`:''}
      </div></td>`:''}
    </tr>`).join('');
}

function filterShops(status, el) {
  document.querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
  const shops = window._shopsData || [];
  const filtered = status==='all' ? shops : shops.filter(s=>s.status===status);
  document.getElementById('shops-tbody').innerHTML = renderShopsRows(filtered, ['super_admin','investigation_officer'].includes(currentUser.role));
}

function searchShops(q) {
  const shops = (window._shopsData||[]).filter(s =>
    s.shop_name.toLowerCase().includes(q.toLowerCase()) ||
    (s.location||'').toLowerCase().includes(q.toLowerCase()) ||
    (s.dealer_name||'').toLowerCase().includes(q.toLowerCase())
  );
  document.getElementById('shops-tbody').innerHTML = renderShopsRows(shops, ['super_admin','investigation_officer'].includes(currentUser.role));
}

async function updateShopStatus(shopId, status) {
  const reason = prompt(`Reason for marking as ${status}:`);
  if (reason === null) return;
  const r = await apiFetch(`/shops/${shopId}/status`, { method:'PUT', body: JSON.stringify({status, reason}) });
  if (r.ok) { showToast(`Shop ${status} successfully`, 'success'); renderShops(); }
  else showToast(r.data.error||'Failed', 'error');
}

function viewShopDetail(shopId) {
  const shop = (window._shopsData||[]).find(s=>s.shop_id===shopId);
  if (!shop) return;
  openModal(`🏪 ${shop.shop_name}`, `
    <div class="grid-2"><div class="form-group"><label>Shop Name</label><input value="${esc(shop.shop_name)}" readonly/></div>
    <div class="form-group"><label>License</label><input value="${esc(shop.license_number||'—')}" readonly/></div>
    <div class="form-group"><label>Location</label><input value="${esc(shop.location||'—')}" readonly/></div>
    <div class="form-group"><label>District</label><input value="${esc(shop.district||'—')}" readonly/></div>
    <div class="form-group"><label>Dealer</label><input value="${esc(shop.dealer_name||'—')}" readonly/></div>
    <div class="form-group"><label>Phone</label><input value="${esc(shop.dealer_phone||'—')}" readonly/></div>
    <div class="form-group"><label>Status</label><input value="${shop.status}" readonly/></div>
    <div class="form-group"><label>Risk Score</label><input value="${shop.fraud_risk_score||0}/100" readonly/></div>
    <div class="form-group"><label>Certificate</label><input value="${esc(shop.certificate_id||'—')}" readonly/></div>
    <div class="form-group"><label>Cert Status</label><input value="${shop.certificate_status||'—'}" readonly/></div>
    </div>`, `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Close</button>`);
}

function showAddShopModal() {
  openModal('➕ Add New Shop', `
    <div class="grid-2">
      <div class="form-group"><label>Shop Name *</label><input id="ns-name" placeholder="Shop name"/></div>
      <div class="form-group"><label>Location *</label><input id="ns-loc" placeholder="Village/Area"/></div>
      <div class="form-group"><label>State</label><input id="ns-state" value="Uttar Pradesh"/></div>
      <div class="form-group"><label>District</label><input id="ns-dist" placeholder="District"/></div>
      <div class="form-group"><label>Dealer Name</label><input id="ns-dealer" placeholder="Dealer name"/></div>
      <div class="form-group"><label>Dealer Phone</label><input id="ns-phone" placeholder="Mobile"/></div>
      <div class="form-group"><label>Dealer Email</label><input id="ns-email" placeholder="Email"/></div>
      <div class="form-group"><label>License Number</label><input id="ns-lic" placeholder="UP-XXX-000"/></div>
    </div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Cancel</button>
     <button class="btn btn-primary btn-sm" onclick="submitAddShop()">Add Shop</button>`);
}

async function submitAddShop() {
  const data = { shop_name: document.getElementById('ns-name').value.trim(), location: document.getElementById('ns-loc').value.trim(),
    state: document.getElementById('ns-state').value.trim(), district: document.getElementById('ns-dist').value.trim(),
    dealer_name: document.getElementById('ns-dealer').value.trim(), dealer_phone: document.getElementById('ns-phone').value.trim(),
    dealer_email: document.getElementById('ns-email').value.trim(), license_number: document.getElementById('ns-lic').value.trim() };
  if (!data.shop_name || !data.location) { showToast('Shop name and location required', 'error'); return; }
  const r = await apiFetch('/shops', { method:'POST', body: JSON.stringify(data) });
  if (r.ok) { closeModal(); showToast('Shop added successfully!', 'success'); renderShops(); }
  else showToast(r.data.error||'Failed', 'error');
}

// ── BENEFICIARIES ─────────────────────────────────────────────────
async function renderBeneficiaries() {
  const pg = document.getElementById('page-beneficiaries');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading...</div>';
  const r = await apiFetch('/beneficiaries');
  if (!r.ok) { pg.innerHTML = `<div class="alert-box error">${r.data.error}</div>`; return; }
  const bens = r.data || [];
  const isAdmin = ['super_admin','investigation_officer'].includes(currentUser.role);
  pg.innerHTML = `
  <div class="section-header">
    <div><h2>👥 Beneficiaries</h2><p>${bens.length} registered</p></div>
    <button class="btn btn-primary btn-sm" onclick="showAddBenModal()">➕ Register Beneficiary</button>
  </div>
  <div class="table-wrap">
    <div class="table-head"><h3>Beneficiary Registry</h3>
      <div class="search-box">🔍 <input type="text" placeholder="Search..." oninput="searchBens(this.value)"/></div>
    </div>
    <div style="overflow-x:auto"><table>
      <thead><tr><th>#</th><th>Name</th><th>Aadhaar</th><th>Family ID</th><th>Village</th><th>Category</th><th>Face Status</th><th>Face Score</th></tr></thead>
      <tbody id="bens-tbody">${renderBensRows(bens)}</tbody>
    </table></div>
  </div>`;
  window._bensData = bens;
}

function renderBensRows(bens) {
  if (!bens.length) return '<tr><td colspan="8"><div class="empty-state"><div class="e-icon">👥</div><p>No beneficiaries found</p></div></td></tr>';
  return bens.map((b,i)=>`
    <tr>
      <td style="color:var(--text3)">${i+1}</td>
      <td><strong style="color:#fff">${esc(b.name)}</strong></td>
      <td><code style="color:var(--accent2)">${esc(b.aadhaar_number)}</code></td>
      <td><code style="font-size:11px">${esc(b.family_id||'—')}</code></td>
      <td>${esc(b.village||'—')}</td>
      <td>${statusBadge(b.income_category||'BPL')}</td>
      <td>${statusBadge(b.verification_status||'pending')}</td>
      <td>${b.face_score ? `<span style="color:${b.face_score>=80?'var(--green)':b.face_score>=55?'var(--yellow)':'var(--red)'};font-weight:700">${b.face_score}%</span>` : '—'}</td>
    </tr>`).join('');
}

function searchBens(q) {
  const bens = (window._bensData||[]).filter(b =>
    b.name.toLowerCase().includes(q.toLowerCase()) || (b.aadhaar_number||'').includes(q) || (b.family_id||'').toLowerCase().includes(q.toLowerCase())
  );
  document.getElementById('bens-tbody').innerHTML = renderBensRows(bens);
}

function showAddBenModal() {
  openModal('👤 Register Beneficiary', `
    <div id="ben-error" class="alert-box error" style="display:none"></div>
    <div id="ben-success" class="alert-box success" style="display:none"></div>
    <div class="grid-2">
      <div class="form-group" style="grid-column:1/-1"><label>Full Name *</label><input id="bn-name" placeholder="Full name"/></div>
      <div class="form-group">
        <label>Aadhaar Number *</label>
        <input id="bn-aadhaar" placeholder="XXXX XXXX XXXX" maxlength="14" oninput="checkAadhaarLive(this)"/>
        <div id="bn-aadhaar-msg" class="field-msg"></div>
      </div>
      <div class="form-group">
        <label>Family ID</label>
        <input id="bn-fid" placeholder="FAM-XXX" oninput="checkFidLive(this)"/>
        <div id="bn-fid-msg" class="field-msg"></div>
      </div>
      <div class="form-group"><label>Village/City *</label><input id="bn-village" placeholder="Village name"/></div>
      <div class="form-group"><label>Income Category</label>
        <select id="bn-cat"><option value="BPL">BPL — Below Poverty Line</option><option value="APL">APL — Above Poverty Line</option><option value="AAY">AAY — Antyodaya Anna Yojana</option></select>
      </div>
      <div class="form-group"><label>Phone</label><input id="bn-phone" placeholder="Mobile number"/></div>
    </div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Cancel</button>
     <button class="btn btn-primary btn-sm" onclick="submitAddBen()">Register</button>`);
}

let _aadhaarTimer, _fidTimer;
function checkAadhaarLive(input) {
  clearTimeout(_aadhaarTimer);
  const msg = document.getElementById('bn-aadhaar-msg');
  const digits = input.value.replace(/\s/g,'').replace(/-/g,'');
  if (digits.length < 12) { msg.innerHTML = ''; return; }
  msg.innerHTML = '<span class="loader" style="width:12px;height:12px"></span> Checking...';
  _aadhaarTimer = setTimeout(async () => {
    const r = await apiFetch(`/beneficiaries/check-aadhaar?number=${encodeURIComponent(digits)}`);
    if (r.ok) {
      msg.innerHTML = r.data.exists
        ? `<span class="field-msg err">⚠ ${r.data.message}</span>`
        : `<span class="field-msg ok">✓ ${r.data.message}</span>`;
    }
  }, 500);
}
function checkFidLive(input) {
  clearTimeout(_fidTimer);
  if (!input.value.trim()) return;
  const msg = document.getElementById('bn-fid-msg');
  msg.innerHTML = '<span class="loader" style="width:12px;height:12px"></span>';
  _fidTimer = setTimeout(async () => {
    const r = await apiFetch(`/beneficiaries/check-family-id?id=${encodeURIComponent(input.value.trim())}`);
    if (r.ok) {
      msg.innerHTML = r.data.exists
        ? `<span class="field-msg err">⚠ ${r.data.message}</span>`
        : `<span class="field-msg ok">✓ Available</span>`;
    }
  }, 500);
}

async function submitAddBen() {
  const data = {
    name: document.getElementById('bn-name').value.trim(),
    aadhaar_number: document.getElementById('bn-aadhaar').value.trim(),
    family_id: document.getElementById('bn-fid').value.trim(),
    village: document.getElementById('bn-village').value.trim(),
    income_category: document.getElementById('bn-cat').value,
    phone: document.getElementById('bn-phone').value.trim()
  };
  if (!data.name || !data.aadhaar_number) {
    document.getElementById('ben-error').textContent = 'Name and Aadhaar are required.';
    document.getElementById('ben-error').style.display = 'flex'; return;
  }
  const r = await apiFetch('/beneficiaries', { method:'POST', body: JSON.stringify(data) });
  if (r.ok) { document.getElementById('ben-success').textContent = '✓ Beneficiary registered!'; document.getElementById('ben-success').style.display = 'flex'; setTimeout(()=>{ closeModal(); renderBeneficiaries(); }, 1200); }
  else {
    document.getElementById('ben-error').textContent = r.data.error || 'Registration failed.';
    document.getElementById('ben-error').style.display = 'flex';
  }
}
