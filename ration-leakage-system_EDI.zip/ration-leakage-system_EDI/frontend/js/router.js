// ── MAIN ROUTER & TOAST ───────────────────────────────────────────
function renderPage(pageId) {
  const map = {
    dashboard: renderDashboard,
    shops: renderShops,
    beneficiaries: renderBeneficiaries,
    cases: renderCases,
    alerts: renderAlerts,
    complaints: renderComplaints,
    certificates: renderCertificates,
    analytics: renderAnalytics,
    'face-verify': renderFaceVerify,
    detection: renderDetection,
    users: renderUsers,
    audit: renderAudit,
    profile: renderProfile,
    stock: renderStock,
  };
  if (map[pageId]) map[pageId]();
}

function renderProfile() {
  const pg = document.getElementById('page-profile');
  const u = currentUser || {};
  pg.innerHTML = `
  <div class="section-header"><div><h2>👤 My Profile</h2></div></div>
  <div class="card" style="max-width:500px">
    <div style="text-align:center;margin-bottom:20px">
      <div style="width:80px;height:80px;border-radius:20px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;font-size:32px;font-weight:700;color:#fff;margin:0 auto 12px">${(u.full_name||'A')[0].toUpperCase()}</div>
      <div style="font-size:20px;font-weight:700;color:#fff">${esc(u.full_name||'—')}</div>
      <div style="margin-top:6px">${statusBadge(u.role||'public_user')}</div>
    </div>
    <div class="grid-2">
      <div class="form-group"><label>Username</label><input value="${esc(u.username||'')}" readonly/></div>
      <div class="form-group"><label>Role</label><input value="${esc((u.role||'').replace(/_/g,' '))}" readonly/></div>
      <div class="form-group"><label>Email</label><input value="${esc(u.email||'—')}" readonly/></div>
      <div class="form-group"><label>User ID</label><input value="${u.user_id||'—'}" readonly/></div>
    </div>
    <button class="btn btn-danger btn-sm w-full" style="margin-top:12px" onclick="doLogout()">🚪 Logout</button>
  </div>`;
}

function showToast(message, type='success') {
  const existing = document.getElementById('toast-msg');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.id = 'toast-msg';
  toast.style.cssText = `position:fixed;bottom:24px;right:24px;z-index:9999;background:${type==='success'?'var(--green)':type==='error'?'var(--red)':'var(--yellow)'};color:#fff;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:600;font-family:Inter,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.4);max-width:320px;animation:slideIn .3s ease`;
  toast.textContent = (type==='success'?'✓ ':type==='error'?'✗ ':'⚠ ') + message;
  if (!document.getElementById('toast-style')) {
    const s = document.createElement('style');
    s.id = 'toast-style';
    s.textContent = '@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}';
    document.head.appendChild(s);
  }
  document.body.appendChild(toast);
  setTimeout(()=>toast.remove(), 3500);
}
