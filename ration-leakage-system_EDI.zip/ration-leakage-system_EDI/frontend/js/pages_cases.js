// ── FRAUD CASES ───────────────────────────────────────────────────
async function renderCases() {
  const pg = document.getElementById('page-cases');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading cases...</div>';
  const r = await apiFetch('/cases');
  if (!r.ok) { pg.innerHTML = `<div class="alert-box error">${r.data.error}</div>`; return; }
  const cases = r.data || [];
  const isAdmin = ['super_admin','investigation_officer'].includes(currentUser.role);
  pg.innerHTML = `
  <div class="section-header">
    <div><h2>🗂️ Fraud Cases</h2><p>${cases.length} total · ${cases.filter(c=>['open','under_review'].includes(c.status)).length} active</p></div>
    ${isAdmin ? `<button class="btn btn-primary btn-sm" onclick="showCreateCaseModal()">➕ New Case</button>` : ''}
  </div>
  <div class="filter-bar">
    <div class="filter-chip active" onclick="filterCases('all',this)">All</div>
    <div class="filter-chip" onclick="filterCases('open',this)">Open</div>
    <div class="filter-chip" onclick="filterCases('under_review',this)">Under Review</div>
    <div class="filter-chip" onclick="filterCases('verified_fraud',this)">Verified Fraud</div>
    <div class="filter-chip" onclick="filterCases('closed',this)">Closed</div>
  </div>
  <div class="table-wrap">
    <div class="table-head"><h3>Investigation Cases</h3></div>
    <div style="overflow-x:auto"><table>
      <thead><tr><th>Case #</th><th>Title</th><th>Shop</th><th>Type</th><th>Priority</th><th>Status</th><th>Risk</th><th>Officer</th><th>Deadline</th><th>Actions</th></tr></thead>
      <tbody id="cases-tbody">${renderCasesRows(cases)}</tbody>
    </table></div>
  </div>`;
  window._casesData = cases;
}

function renderCasesRows(cases) {
  if (!cases.length) return '<tr><td colspan="10"><div class="empty-state"><div class="e-icon">🗂️</div><p>No cases found</p></div></td></tr>';
  return cases.map(c=>`
    <tr>
      <td><code style="color:var(--accent2);font-size:11px">${esc(c.case_number)}</code></td>
      <td style="max-width:200px"><strong style="color:#fff">${esc(c.title)}</strong></td>
      <td>${esc(c.shop_name||'—')}</td>
      <td><span class="badge badge-blue">${esc((c.case_type||'').replace(/_/g,' '))}</span></td>
      <td>${statusBadge(c.priority)}</td>
      <td>${statusBadge(c.status)}</td>
      <td>${riskBadge(c.risk_score||0)}</td>
      <td>${esc(c.officer_name||'Unassigned')}</td>
      <td style="color:${c.deadline&&new Date(c.deadline)<new Date()?'var(--red)':'var(--text2)'}">${fmtDate(c.deadline)}</td>
      <td><div class="d-flex gap-8">
        <button class="btn btn-sm btn-accent" onclick="viewCaseDetail(${c.case_id})">📋 View</button>
        ${['super_admin','investigation_officer'].includes(currentUser.role)?`<button class="btn btn-sm btn-secondary" onclick="changeCaseStatus(${c.case_id})">✏</button>`:''}
      </div></td>
    </tr>`).join('');
}

function filterCases(status, el) {
  document.querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
  const cases = window._casesData || [];
  const filtered = status==='all' ? cases : cases.filter(c=>c.status===status);
  document.getElementById('cases-tbody').innerHTML = renderCasesRows(filtered);
}

async function viewCaseDetail(caseId) {
  const r = await apiFetch(`/cases/${caseId}`);
  if (!r.ok) return;
  const { case: c, notes } = r.data;
  openModal(`🗂️ ${c.case_number}`, `
    <div style="display:grid;gap:12px">
      <div class="card" style="padding:14px">
        <div class="card-title">Case Details</div>
        <div class="grid-2">
          <div><span class="text-muted" style="font-size:12px">Title</span><p style="color:#fff;font-size:14px;font-weight:600">${esc(c.title)}</p></div>
          <div><span class="text-muted" style="font-size:12px">Status</span><p>${statusBadge(c.status)}</p></div>
          <div><span class="text-muted" style="font-size:12px">Priority</span><p>${statusBadge(c.priority)}</p></div>
          <div><span class="text-muted" style="font-size:12px">Risk Score</span><p>${riskBadge(c.risk_score||0)}</p></div>
          <div><span class="text-muted" style="font-size:12px">Shop</span><p style="color:var(--text)">${esc(c.shop_name||'—')}</p></div>
          <div><span class="text-muted" style="font-size:12px">Officer</span><p style="color:var(--text)">${esc(c.officer_name||'Unassigned')}</p></div>
          <div><span class="text-muted" style="font-size:12px">Deadline</span><p style="color:var(--text)">${fmtDate(c.deadline)}</p></div>
          <div><span class="text-muted" style="font-size:12px">Created</span><p style="color:var(--text)">${fmtDate(c.created_at)}</p></div>
        </div>
        <div style="margin-top:12px"><span class="text-muted" style="font-size:12px">Description</span><p style="color:var(--text);font-size:13px;margin-top:4px;line-height:1.6">${esc(c.description||'No description')}</p></div>
      </div>
      <div class="card" style="padding:14px">
        <div class="card-title">📝 Investigation Notes (${notes.length})</div>
        <div style="max-height:200px;overflow-y:auto">
          ${notes.length ? notes.map(n=>`<div class="tl-item" style="margin-bottom:12px;padding:10px;background:var(--bg);border-radius:8px;border:1px solid var(--border)">
            <strong style="color:var(--accent2);font-size:12px">${esc(n.author_name||'System')}</strong>
            <p style="color:var(--text);font-size:13px;margin:6px 0">${esc(n.note_text)}</p>
            <span class="text-muted" style="font-size:11px">${timeAgo(n.created_at)}</span>
          </div>`).join('') : '<p class="text-muted" style="font-size:13px">No notes yet.</p>'}
        </div>
        ${['super_admin','investigation_officer'].includes(currentUser.role)?`
        <div style="margin-top:12px;display:flex;gap:8px">
          <input id="new-note-${caseId}" placeholder="Add investigation note..." style="flex:1;background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:8px 12px;color:var(--text);font-size:13px;outline:none;font-family:Inter,sans-serif"/>
          <button class="btn btn-sm btn-accent" onclick="submitCaseNote(${caseId})">Add</button>
        </div>`:''}
      </div>
    </div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Close</button>`);
}

async function submitCaseNote(caseId) {
  const inp = document.getElementById(`new-note-${caseId}`);
  const text = inp.value.trim();
  if (!text) return;
  const r = await apiFetch(`/cases/${caseId}/notes`, { method:'POST', body: JSON.stringify({note_text: text, is_internal: true}) });
  if (r.ok) { inp.value = ''; showToast('Note added', 'success'); viewCaseDetail(caseId); }
}

async function changeCaseStatus(caseId) {
  const statuses = ['open','under_review','verified_fraud','rejected','suspended','blocked','closed'];
  const sel = statuses.map(s=>`<option value="${s}">${s.replace(/_/g,' ')}</option>`).join('');
  openModal('✏️ Update Case Status', `<div class="form-group"><label>New Status</label><select id="new-case-status">${sel}</select></div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Cancel</button>
     <button class="btn btn-primary btn-sm" onclick="submitCaseStatus(${caseId})">Update</button>`);
}
async function submitCaseStatus(caseId) {
  const status = document.getElementById('new-case-status').value;
  const r = await apiFetch(`/cases/${caseId}/status`, { method:'PUT', body: JSON.stringify({status}) });
  if (r.ok) { closeModal(); showToast('Case status updated', 'success'); renderCases(); }
}

function showCreateCaseModal() {
  openModal('➕ Create Fraud Case', `
    <div class="grid-2">
      <div class="form-group" style="grid-column:1/-1"><label>Case Title *</label><input id="nc-title" placeholder="Brief case title"/></div>
      <div class="form-group"><label>Case Type</label>
        <select id="nc-type">
          <option value="duplicate_aadhaar">Duplicate Aadhaar</option>
          <option value="stock_mismatch">Stock Mismatch</option>
          <option value="fake_documents">Fake Documents</option>
          <option value="ghost_shop">Ghost Shop</option>
          <option value="abnormal_transaction">Abnormal Transaction</option>
          <option value="complaint_based">Complaint Based</option>
          <option value="other">Other</option>
        </select>
      </div>
      <div class="form-group"><label>Priority</label>
        <select id="nc-priority"><option value="low">Low</option><option value="medium" selected>Medium</option><option value="high">High</option><option value="critical">Critical</option></select>
      </div>
      <div class="form-group"><label>Risk Score (0-100)</label><input id="nc-risk" type="number" min="0" max="100" value="50"/></div>
      <div class="form-group"><label>Deadline</label><input id="nc-deadline" type="date"/></div>
      <div class="form-group" style="grid-column:1/-1"><label>Description</label><textarea id="nc-desc" rows="3" style="width:100%;background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:10px;color:var(--text);font-family:Inter,sans-serif;font-size:13px;outline:none;resize:vertical" placeholder="Describe the fraud..."></textarea></div>
    </div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Cancel</button>
     <button class="btn btn-primary btn-sm" onclick="submitCreateCase()">Create Case</button>`);
}
async function submitCreateCase() {
  const data = {
    title: document.getElementById('nc-title').value.trim(),
    case_type: document.getElementById('nc-type').value,
    priority: document.getElementById('nc-priority').value,
    risk_score: parseInt(document.getElementById('nc-risk').value)||50,
    deadline: document.getElementById('nc-deadline').value,
    description: document.getElementById('nc-desc').value.trim()
  };
  if (!data.title) { showToast('Title is required','error'); return; }
  const r = await apiFetch('/cases', { method:'POST', body: JSON.stringify(data) });
  if (r.ok) { closeModal(); showToast(`Case ${r.data.case_number} created!`,'success'); renderCases(); }
  else showToast(r.data.error||'Failed','error');
}

// ── ALERTS ────────────────────────────────────────────────────────
async function renderAlerts() {
  const pg = document.getElementById('page-alerts');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading alerts...</div>';
  const r = await apiFetch('/alerts');
  if (!r.ok) { pg.innerHTML = `<div class="alert-box error">${r.data.error}</div>`; return; }
  const alerts = r.data || [];
  pg.innerHTML = `
  <div class="section-header">
    <div><h2>🚨 Fraud Alerts</h2><p>${alerts.filter(a=>a.status==='new').length} new · ${alerts.length} total</p></div>
  </div>
  <div class="filter-bar">
    <div class="filter-chip active" onclick="filterAlerts('all',this)">All</div>
    <div class="filter-chip" onclick="filterAlerts('new',this)">New</div>
    <div class="filter-chip" onclick="filterAlerts('acknowledged',this)">Acknowledged</div>
    <div class="filter-chip" onclick="filterAlerts('resolved',this)">Resolved</div>
  </div>
  <div id="alerts-list">${renderAlertCards(alerts)}</div>`;
  window._alertsData = alerts;
}

function renderAlertCards(alerts) {
  if (!alerts.length) return '<div class="empty-state"><div class="e-icon">✅</div><p>No alerts found</p></div>';
  return alerts.map(a=>`
    <div class="alert-item ${a.severity||'medium'}" style="margin-bottom:10px">
      <div class="a-icon">${{critical:'🔴',high:'🟠',medium:'🟡',low:'🟢'}[a.severity]||'🔵'}</div>
      <div style="flex:1">
        <div class="d-flex align-center gap-8">
          <div class="a-title">${esc(a.alert_type)}</div>
          ${statusBadge(a.severity)} ${statusBadge(a.status)}
        </div>
        <div class="a-desc" style="margin-top:4px">${esc(a.description||'')}</div>
        <div class="a-time" style="margin-top:6px">
          🏪 ${esc(a.shop_name||'N/A')} · Risk Score: <strong style="color:var(--red)">${a.risk_score||0}</strong> · ${timeAgo(a.created_at)}
        </div>
      </div>
      <div class="d-flex" style="flex-direction:column;gap:6px">
        ${a.status==='new'?`<button class="btn btn-sm btn-warning" onclick="ackAlert(${a.alert_id})">✓ Acknowledge</button>`:''}
        <button class="btn btn-sm btn-accent" onclick="convertToCase(${a.alert_id})">🗂 Create Case</button>
      </div>
    </div>`).join('');
}

function filterAlerts(status, el) {
  document.querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
  const alerts = window._alertsData || [];
  const filtered = status==='all' ? alerts : alerts.filter(a=>a.status===status);
  document.getElementById('alerts-list').innerHTML = renderAlertCards(filtered);
}

async function ackAlert(alertId) {
  const r = await apiFetch(`/alerts/${alertId}/acknowledge`, {method:'PUT'});
  if (r.ok) { showToast('Alert acknowledged','success'); renderAlerts(); }
}
function convertToCase(alertId) { showCreateCaseModal(); }

// ── COMPLAINTS ────────────────────────────────────────────────────
async function renderComplaints() {
  const pg = document.getElementById('page-complaints');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading...</div>';
  const r = await apiFetch('/complaints');
  if (!r.ok) { pg.innerHTML = `<div class="alert-box error">${r.data.error}</div>`; return; }
  const comps = r.data || [];
  const isAdmin = ['super_admin','investigation_officer'].includes(currentUser.role);
  pg.innerHTML = `
  <div class="section-header">
    <div><h2>📝 Public Complaints</h2><p>${comps.length} total</p></div>
    <button class="btn btn-primary btn-sm" onclick="showFileComplaintModal()">📝 File Complaint</button>
  </div>
  <div class="table-wrap">
    <div class="table-head"><h3>Complaint Registry</h3></div>
    <div style="overflow-x:auto"><table>
      <thead><tr><th>Complaint #</th><th>Complainant</th><th>Shop</th><th>Type</th><th>Status</th><th>Filed On</th>${isAdmin?'<th>Actions</th>':''}</tr></thead>
      <tbody>${comps.map(c=>`
        <tr>
          <td><code style="color:var(--accent2);font-size:11px">${esc(c.complaint_number)}</code></td>
          <td><strong style="color:#fff">${esc(c.complainant_name)}</strong><br><small class="text-muted">${esc(c.complainant_phone||'—')}</small></td>
          <td>${esc(c.shop_name_text||c.linked_shop||'—')}</td>
          <td><span class="badge badge-blue">${esc((c.complaint_type||'').replace(/_/g,' '))}</span></td>
          <td>${statusBadge(c.status)}</td>
          <td>${fmtDate(c.created_at)}</td>
          ${isAdmin?`<td><div class="d-flex gap-8">
            <button class="btn btn-sm btn-accent" onclick="viewComplaint(${c.complaint_id})">👁 View</button>
            <button class="btn btn-sm btn-success" onclick="resolveComplaint(${c.complaint_id})">✓</button>
          </div></td>`:''}
        </tr>`).join('')}
      </tbody>
    </table></div>
  </div>`;
  window._compsData = comps;
}

function showFileComplaintModal() {
  openModal('📝 File a Complaint', `
    <div id="comp-result" class="alert-box success" style="display:none"></div>
    <div class="grid-2">
      <div class="form-group"><label>Your Name *</label><input id="cp-name" placeholder="Full name"/></div>
      <div class="form-group"><label>Phone</label><input id="cp-phone" placeholder="Mobile number"/></div>
      <div class="form-group"><label>Email</label><input id="cp-email" placeholder="Email address"/></div>
      <div class="form-group"><label>Shop Name</label><input id="cp-shop" placeholder="Shop involved"/></div>
      <div class="form-group"><label>Complaint Type</label>
        <select id="cp-type">
          <option value="overcharging">Overcharging</option>
          <option value="fake_ration">Fake Ration</option>
          <option value="short_supply">Short Supply</option>
          <option value="bribery">Bribery</option>
          <option value="ghost_beneficiary">Ghost Beneficiary</option>
          <option value="document_fraud">Document Fraud</option>
          <option value="other">Other</option>
        </select>
      </div>
    </div>
    <div class="form-group"><label>Description *</label>
      <textarea id="cp-desc" rows="4" style="width:100%;background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:10px;color:var(--text);font-family:Inter,sans-serif;font-size:13px;outline:none;resize:vertical" placeholder="Describe the issue in detail..."></textarea>
    </div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Cancel</button>
     <button class="btn btn-primary btn-sm" onclick="submitComplaint()">Submit Complaint</button>`);
}

async function submitComplaint() {
  const data = {
    complainant_name: document.getElementById('cp-name').value.trim(),
    complainant_phone: document.getElementById('cp-phone').value.trim(),
    complainant_email: document.getElementById('cp-email').value.trim(),
    shop_name_text: document.getElementById('cp-shop').value.trim(),
    complaint_type: document.getElementById('cp-type').value,
    description: document.getElementById('cp-desc').value.trim()
  };
  if (!data.complainant_name || !data.description) { showToast('Name and description required','error'); return; }
  const r = await apiFetch('/complaints', { method:'POST', body: JSON.stringify(data) });
  if (r.ok) {
    const el = document.getElementById('comp-result');
    el.textContent = `✓ Complaint ${r.data.complaint_number} filed successfully! Track your complaint status.`;
    el.style.display = 'flex';
    setTimeout(()=>{ closeModal(); renderComplaints(); }, 2000);
  } else showToast(r.data.error||'Failed','error');
}

async function viewComplaint(id) {
  const c = (window._compsData||[]).find(x=>x.complaint_id===id);
  if (!c) return;
  openModal(`📝 ${c.complaint_number}`, `
    <div style="display:grid;gap:12px">
      <div class="card" style="padding:14px">
        <div class="grid-2">
          <div><span class="text-muted" style="font-size:12px">Complainant</span><p style="color:#fff;font-weight:600">${esc(c.complainant_name)}</p></div>
          <div><span class="text-muted" style="font-size:12px">Phone</span><p style="color:var(--text)">${esc(c.complainant_phone||'—')}</p></div>
          <div><span class="text-muted" style="font-size:12px">Shop</span><p style="color:var(--text)">${esc(c.shop_name_text||'—')}</p></div>
          <div><span class="text-muted" style="font-size:12px">Type</span><p>${statusBadge(c.complaint_type)}</p></div>
          <div><span class="text-muted" style="font-size:12px">Status</span><p>${statusBadge(c.status)}</p></div>
          <div><span class="text-muted" style="font-size:12px">Filed</span><p style="color:var(--text)">${fmtDate(c.created_at)}</p></div>
        </div>
        <div style="margin-top:12px"><span class="text-muted" style="font-size:12px">Description</span><p style="color:var(--text);font-size:13px;margin-top:4px;line-height:1.6">${esc(c.description)}</p></div>
      </div>
      <div class="form-group"><label>Update Status</label>
        <select id="comp-status-${id}">
          <option value="submitted" ${c.status==='submitted'?'selected':''}>Submitted</option>
          <option value="under_review" ${c.status==='under_review'?'selected':''}>Under Review</option>
          <option value="assigned" ${c.status==='assigned'?'selected':''}>Assigned</option>
          <option value="resolved" ${c.status==='resolved'?'selected':''}>Resolved</option>
          <option value="rejected" ${c.status==='rejected'?'selected':''}>Rejected</option>
        </select>
      </div>
    </div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Close</button>
     <button class="btn btn-primary btn-sm" onclick="updateComplaintStatus(${id})">Update</button>`);
}

async function updateComplaintStatus(id) {
  const status = document.getElementById(`comp-status-${id}`).value;
  const r = await apiFetch(`/complaints/${id}`, { method:'PUT', body: JSON.stringify({status}) });
  if (r.ok) { closeModal(); showToast('Complaint updated','success'); renderComplaints(); }
}
async function resolveComplaint(id) {
  const r = await apiFetch(`/complaints/${id}`, { method:'PUT', body: JSON.stringify({status:'resolved'}) });
  if (r.ok) { showToast('Complaint resolved','success'); renderComplaints(); }
}
