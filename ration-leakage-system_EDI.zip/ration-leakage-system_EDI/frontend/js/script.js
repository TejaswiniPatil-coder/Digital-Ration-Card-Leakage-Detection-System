/**
 * script.js — Ration Guard v2.0
 * Complete rewrite with: Auth, Real-time Aadhaar validation, Premium UI
 */

const API = '/api';

// ══════════════════════════════════════════════════════════════
// API FETCH HELPER
// ══════════════════════════════════════════════════════════════
async function apiFetch(endpoint, method = 'GET', body = null) {
  try {
    const opts = { method, headers: { 'Content-Type': 'application/json' }, credentials: 'include' };
    if (body) opts.body = JSON.stringify(body);
    const res  = await fetch(API + endpoint, opts);
    const data = await res.json();
    return { ok: res.ok, status: res.status, data };
  } catch (err) {
    console.error('Network error:', err);
    return { ok: false, status: 0, data: { error: 'Connection error. Is Flask running on port 5000?' } };
  }
}

// ══════════════════════════════════════════════════════════════
// TOAST SYSTEM
// ══════════════════════════════════════════════════════════════
function showToast(message, type = 'success', duration = 3500) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || '💬'}</span><span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('toast-exit');
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// ══════════════════════════════════════════════════════════════
// CLOCK
// ══════════════════════════════════════════════════════════════
function startClock() {
  const el = document.getElementById('topbar-time');
  if (!el) return;
  const tick = () => {
    el.textContent = new Date().toLocaleString('en-IN', {
      weekday: 'short', day: '2-digit', month: 'short',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
    });
  };
  tick();
  setInterval(tick, 1000);
}

// ══════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════
function setEl(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function formatKg(kg) {
  if (!kg || kg === 0) return '0 kg';
  if (kg >= 1000) return (kg / 1000).toFixed(1) + ' T';
  return Number(kg).toLocaleString() + ' kg';
}

function showFieldError(groupId, show = true) {
  const el = document.getElementById(groupId);
  if (!el) return;
  el.classList.toggle('error', show);
  el.classList.toggle('success', !show && el.querySelector('input')?.value);
}

function showError(id, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  if (msg) { el.textContent = msg; el.style.display = 'block'; }
  else el.style.display = 'none';
}

// ══════════════════════════════════════════════════════════════
// SIDEBAR TOGGLE
// ══════════════════════════════════════════════════════════════
function toggleSidebar() {
  document.getElementById('sidebar')?.classList.toggle('open');
}

// ══════════════════════════════════════════════════════════════
// PASSWORD VISIBILITY TOGGLE
// ══════════════════════════════════════════════════════════════
function bindTogglePass() {
  document.querySelectorAll('.toggle-pass').forEach(btn => {
    btn.addEventListener('click', () => {
      const inp = document.getElementById(btn.dataset.target);
      if (!inp) return;
      if (inp.type === 'password') { inp.type = 'text'; btn.textContent = '🙈'; }
      else { inp.type = 'password'; btn.textContent = '👁'; }
    });
  });
}

// ══════════════════════════════════════════════════════════════
// AUTH PANEL SWITCHING
// ══════════════════════════════════════════════════════════════
function showLogin() {
  document.getElementById('login-panel').classList.add('active');
  document.getElementById('register-panel').classList.remove('active');
}

function showRegister() {
  document.getElementById('register-panel').classList.add('active');
  document.getElementById('login-panel').classList.remove('active');
}

// ══════════════════════════════════════════════════════════════
// LOGIN
// ══════════════════════════════════════════════════════════════
async function handleLogin() {
  const btn      = document.getElementById('login-btn');
  const username = document.getElementById('login-user')?.value?.trim();
  const password = document.getElementById('login-pass')?.value?.trim();

  showError('login-error', '');
  showFieldError('login-user-group', false);
  showFieldError('login-pass-group', false);

  if (!username) { showFieldError('login-user-group'); showError('login-error', 'Username is required.'); return; }
  if (!password) { showFieldError('login-pass-group'); showError('login-error', 'Password is required.'); return; }

  // Show loader
  btn.querySelector('.btn-auth-text').style.display = 'none';
  btn.querySelector('.btn-auth-loader').style.display = 'inline';
  btn.disabled = true;

  const { ok, data } = await apiFetch('/auth/login', 'POST', { username, password });

  btn.querySelector('.btn-auth-text').style.display = 'inline';
  btn.querySelector('.btn-auth-loader').style.display = 'none';
  btn.disabled = false;

  if (ok && data.success) {
    // Update topbar & sidebar user info
    const initials = (data.full_name || data.username).charAt(0).toUpperCase();
    setEl('sidebar-name', data.full_name || data.username);
    setEl('sidebar-role', data.role === 'admin' ? 'Administrator' : 'Officer');
    setEl('sidebar-avatar', initials);
    setEl('topbar-avatar', initials);
    setEl('topbar-name', data.username);

    document.getElementById('auth-overlay').style.display = 'none';
    document.getElementById('app').style.display = 'flex';
    showPage('dashboard');
    showToast(`Welcome back, ${data.full_name || data.username}! 👋`);
    startClock();
  } else {
    showError('login-error', data.error || 'Login failed.');
    showFieldError('login-user-group');
    showFieldError('login-pass-group');
  }
}

// ══════════════════════════════════════════════════════════════
// REGISTER
// ══════════════════════════════════════════════════════════════
async function handleRegister() {
  const btn      = document.getElementById('reg-btn');
  const full_name = document.getElementById('reg-name')?.value?.trim();
  const email    = document.getElementById('reg-email')?.value?.trim();
  const username = document.getElementById('reg-user')?.value?.trim();
  const password = document.getElementById('reg-pass')?.value?.trim();
  const password2 = document.getElementById('reg-pass2')?.value?.trim();

  showError('reg-error', '');
  ['reg-name-group','reg-email-group','reg-user-group','reg-pass-group','reg-pass2-group'].forEach(id => showFieldError(id, false));

  if (!full_name)    { showFieldError('reg-name-group'); showError('reg-error', 'Full name is required.'); return; }
  if (!username)     { showFieldError('reg-user-group'); showError('reg-error', 'Username is required.'); return; }
  if (!password)     { showFieldError('reg-pass-group'); showError('reg-error', 'Password is required.'); return; }
  if (password.length < 6) { showFieldError('reg-pass-group'); showError('reg-error', 'Password must be at least 6 characters.'); return; }
  if (password !== password2) { showFieldError('reg-pass2-group'); showError('reg-error', 'Passwords do not match.'); return; }

  btn.querySelector('.btn-auth-text').style.display = 'none';
  btn.querySelector('.btn-auth-loader').style.display = 'inline';
  btn.disabled = true;

  const { ok, data } = await apiFetch('/auth/register', 'POST', { username, password, full_name, email });

  btn.querySelector('.btn-auth-text').style.display = 'inline';
  btn.querySelector('.btn-auth-loader').style.display = 'none';
  btn.disabled = false;

  if (ok && data.success) {
    showToast('Account created! You can now login.', 'success');
    showLogin();
    // Pre-fill username
    const lu = document.getElementById('login-user');
    if (lu) lu.value = username;
  } else {
    showError('reg-error', data.error || 'Registration failed.');
  }
}

// ══════════════════════════════════════════════════════════════
// LOGOUT
// ══════════════════════════════════════════════════════════════
async function handleLogout() {
  await apiFetch('/auth/logout', 'POST');
  document.getElementById('app').style.display         = 'none';
  document.getElementById('auth-overlay').style.display = 'flex';
  showLogin();
  // Clear form fields
  ['login-user','login-pass'].forEach(id => { const e = document.getElementById(id); if (e) e.value = ''; });
  showToast('Logged out successfully.', 'info');
}

// ══════════════════════════════════════════════════════════════
// PAGE NAVIGATION
// ══════════════════════════════════════════════════════════════
const PAGE_TITLES = {
  dashboard:     'Dashboard',
  beneficiaries: 'Beneficiaries',
  shops:         'Ration Shops',
  allocations:   'Stock Allocation',
  distributions: 'Distribution Log',
  detection:     'Leakage Detection',
  reports:       'Reports'
};

const PAGE_LOADERS = {
  dashboard:     loadDashboard,
  beneficiaries: loadBeneficiaries,
  shops:         loadShops,
  allocations:   loadAllocations,
  distributions: loadDistributions,
  detection:     loadDetection,
  reports:       loadReports
};

function showPage(pageId) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => p.style.display = 'none');

  const page = document.getElementById(pageId);
  if (page) page.style.display = 'block';

  // Update nav
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  const link = document.querySelector(`[data-page="${pageId}"]`);
  if (link) link.classList.add('active');

  // Update topbar title
  setEl('topbar-title', PAGE_TITLES[pageId] || pageId);

  // Close sidebar on mobile
  if (window.innerWidth <= 900) {
    document.getElementById('sidebar')?.classList.remove('open');
  }

  // Load page data
  if (PAGE_LOADERS[pageId]) PAGE_LOADERS[pageId]();
}

// ══════════════════════════════════════════════════════════════
// DASHBOARD
// ══════════════════════════════════════════════════════════════
async function loadDashboard() {
  const { ok, data } = await apiFetch('/dashboard/stats');
  if (!ok || !data) return;

  setEl('stat-beneficiaries', (data.beneficiaries ?? 0).toLocaleString());
  setEl('stat-shops',         data.shops ?? 0);
  setEl('stat-allocated',     formatKg(data.allocated_kg ?? 0));
  setEl('stat-leakage',       (data.leakage_percent ?? 0) + '%');

  renderDashboardCharts(data);
  loadSuspiciousTable();
}

async function loadSuspiciousTable() {
  const { ok, data } = await apiFetch('/risk/scores');
  const tbody = document.getElementById('suspicious-tbody');
  if (!tbody || !ok || !data?.risk_scores) return;

  const high = data.risk_scores.filter(s => s.risk_score >= 61).slice(0, 5);

  if (!high.length) {
    tbody.innerHTML = '<tr><td colspan="4" class="table-empty">✅ No high-risk shops detected</td></tr>';
    return;
  }

  tbody.innerHTML = '';
  high.forEach(s => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${s.shop_name}</strong></td>
      <td>${s.location || '—'}</td>
      <td>
        <div class="risk-bar-wrap">
          <div class="risk-bar-track"><div class="risk-bar-fill" style="background:var(--danger);width:${s.risk_score}%"></div></div>
          <span class="risk-bar-text" style="color:var(--danger)">${s.risk_score}/100</span>
        </div>
      </td>
      <td><span class="badge badge-danger">● HIGH RISK</span></td>`;
    tbody.appendChild(tr);
  });
}

function renderDashboardCharts(data) {
  const chartDefaults = {
    responsive: true,
    plugins: { legend: { labels: { color: '#a0bdd8', font: { family: 'Inter' } } } }
  };

  // Bar chart
  const c1 = document.getElementById('chart-bar');
  if (c1) {
    if (window._cb) window._cb.destroy();
    window._cb = new Chart(c1, {
      type: 'bar',
      data: {
        labels: ['Allocated', 'Distributed', 'Leakage'],
        datasets: [{
          label: 'Quantity (kg)',
          data: [data.allocated_kg || 0, data.distributed_kg || 0, data.leakage_kg || 0],
          backgroundColor: [
            'rgba(0,194,255,0.7)', 'rgba(0,229,138,0.7)', 'rgba(255,59,92,0.7)'
          ],
          borderColor: ['#00c2ff', '#00e58a', '#ff3b5c'],
          borderWidth: 1,
          borderRadius: 6
        }]
      },
      options: {
        ...chartDefaults,
        plugins: { ...chartDefaults.plugins, legend: { display: false } },
        scales: {
          y: { ticks: { color: '#4d6a8a' }, grid: { color: 'rgba(0,194,255,0.06)' } },
          x: { ticks: { color: '#4d6a8a' }, grid: { display: false } }
        }
      }
    });
  }

  // Donut chart
  const c2 = document.getElementById('chart-donut');
  if (c2) {
    if (window._cd) window._cd.destroy();
    window._cd = new Chart(c2, {
      type: 'doughnut',
      data: {
        labels: ['High Risk','Medium Risk','Low Risk'],
        datasets: [{
          data: [data.high_risk_shops || 0, data.med_risk_shops || 0, data.low_risk_shops || 0],
          backgroundColor: ['rgba(255,59,92,0.8)', 'rgba(255,184,0,0.8)', 'rgba(0,229,138,0.8)'],
          borderWidth: 0,
          hoverOffset: 8
        }]
      },
      options: {
        ...chartDefaults,
        cutout: '68%',
        plugins: { legend: { position: 'bottom', labels: { color: '#a0bdd8', padding: 16, font: { family: 'Inter' } } } }
      }
    });
  }
}

// ══════════════════════════════════════════════════════════════
// BENEFICIARIES
// ══════════════════════════════════════════════════════════════
let allBeneficiaries = [];

async function loadBeneficiaries() {
  const searchBox = document.getElementById('ben-search');
  if (searchBox) searchBox.value = '';
  const alertDiv = document.getElementById('dup-alert');
  if (alertDiv) alertDiv.style.display = 'none';

  const { ok, data } = await apiFetch('/beneficiaries');
  if (!ok || !data) return;
  allBeneficiaries = Array.isArray(data) ? data : [];
  renderBeneficiaries(allBeneficiaries);
}

function renderBeneficiaries(list) {
  const tbody = document.getElementById('ben-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  setEl('ben-count', `${list.length} record${list.length !== 1 ? 's' : ''}`);

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No beneficiaries found</td></tr>';
    return;
  }

  const catColors = { BPL: '#ffb800', AAY: '#ff3b5c', APL: '#00e58a' };

  list.forEach((b, i) => {
    const cc  = catColors[b.income_category] || '#00c2ff';
    const tr  = document.createElement('tr');
    tr.dataset.idx = i;
    tr.innerHTML = `
      <td><span style="color:var(--accent);font-weight:700;font-size:12px">BEN-${String(b.beneficiary_id).padStart(3,'0')}</span></td>
      <td><strong>${escHtml(b.name)}</strong></td>
      <td style="font-family:monospace;letter-spacing:1px;font-size:12px">${escHtml(b.aadhaar_number)}</td>
      <td>${escHtml(b.family_id || '—')}</td>
      <td>${escHtml(b.village   || '—')}</td>
      <td><span class="badge" style="background:${cc}18;color:${cc};border:1px solid ${cc}40">● ${b.income_category}</span></td>
      <td><span class="badge badge-success">● Active</span></td>`;
    tbody.appendChild(tr);
  });
}

async function detectDuplicates() {
  const searchBox = document.getElementById('ben-search');
  if (searchBox) searchBox.value = '';

  const { ok, data } = await apiFetch('/beneficiaries');
  if (!ok) return;
  allBeneficiaries = Array.isArray(data) ? data : [];
  renderBeneficiaries(allBeneficiaries);

  // Build normalised Aadhaar freq map
  const freq = {};
  allBeneficiaries.forEach(b => {
    const norm = normaliseAadhaar(b.aadhaar_number);
    freq[norm] = (freq[norm] || 0) + 1;
  });

  let dups = 0;
  document.querySelectorAll('#ben-tbody tr').forEach((row, i) => {
    const ben = allBeneficiaries[i];
    if (ben && freq[normaliseAadhaar(ben.aadhaar_number)] > 1) {
      row.style.background  = 'rgba(255,59,92,0.10)';
      row.style.borderLeft  = '3px solid var(--danger)';
      dups++;
    }
  });

  const alertDiv = document.getElementById('dup-alert');
  const dupCount = document.getElementById('dup-count');
  if (dups > 0) {
    if (alertDiv) alertDiv.style.display = 'flex';
    if (dupCount) dupCount.textContent   = dups;
    showToast(`🚨 ${dups} duplicate Aadhaar entries found!`, 'error', 4500);
  } else {
    if (alertDiv) alertDiv.style.display = 'none';
    showToast('✅ No duplicate Aadhaar entries found!', 'success');
  }
}

function resetHighlights() {
  const searchBox = document.getElementById('ben-search');
  if (searchBox) searchBox.value = '';
  const alertDiv = document.getElementById('dup-alert');
  if (alertDiv) alertDiv.style.display = 'none';
  renderBeneficiaries(allBeneficiaries);
}

function filterBeneficiaries(q) {
  if (!q.trim()) { renderBeneficiaries(allBeneficiaries); return; }
  const lq = q.toLowerCase();
  renderBeneficiaries(allBeneficiaries.filter(b =>
    b.name.toLowerCase().includes(lq) ||
    b.aadhaar_number.toLowerCase().includes(lq) ||
    (b.village || '').toLowerCase().includes(lq)
  ));
}

// ── ADD BENEFICIARY MODAL ─────────────────────────────────────
async function openAddBeneficiary() {
  // Reset form
  ['new-ben-name','new-ben-aadhaar','new-ben-family'].forEach(id => {
    const e = document.getElementById(id);
    if (e) e.value = '';
  });
  // Reset village dropdown
  const villageSelect = document.getElementById('new-ben-village');
  if (villageSelect) villageSelect.value = '';

  // Reset status hints
  ['aadhaar-status','family-status','village-status'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.textContent = ''; el.className = 'field-hint'; }
  });
  ['mf-aadhaar','mf-family','mf-village'].forEach(id => {
    document.getElementById(id)?.classList.remove('error','success');
  });

  showError('ben-modal-error', '');

  // Populate village dropdown from API
  await populateVillageDropdown();

  document.getElementById('modal-add-ben').style.display = 'flex';
}

function closeAddBeneficiary() {
  document.getElementById('modal-add-ben').style.display = 'none';
}

// ── VILLAGE DROPDOWN ──────────────────────────────────────────
async function populateVillageDropdown() {
  const sel = document.getElementById('new-ben-village');
  if (!sel) return;
  const { ok, data } = await apiFetch('/beneficiaries/villages');
  if (!ok || !Array.isArray(data)) return;
  sel.innerHTML = '<option value="">— Select Village/City —</option>';
  data.forEach(v => {
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = v;
    sel.appendChild(opt);
  });
}

// ── AADHAAR FORMATTING & REAL-TIME CHECK ──────────────────────
function normaliseAadhaar(a) {
  return (a || '').replace(/\D/g, '');
}

function formatAadhaarInput(input) {
  // Remove all non-digits
  let digits = input.value.replace(/\D/g, '').slice(0, 12);
  // Insert spaces after 4th and 8th digit
  let formatted = '';
  for (let i = 0; i < digits.length; i++) {
    if (i === 4 || i === 8) formatted += ' ';
    formatted += digits[i];
  }
  input.value = formatted;

  // Live validation feedback
  const statusEl = document.getElementById('aadhaar-status');
  const fg       = document.getElementById('mf-aadhaar');
  if (!statusEl || !fg) return;

  if (digits.length < 12) {
    statusEl.textContent = `${digits.length}/12 digits entered`;
    statusEl.className   = 'field-hint hint-loading';
    fg.classList.remove('error','success');
  }
}

let _aadhaarCheckTimer = null;

async function checkAadhaarDuplicate() {
  const input  = document.getElementById('new-ben-aadhaar');
  if (!input) return;
  const digits = normaliseAadhaar(input.value);
  const statusEl = document.getElementById('aadhaar-status');
  const fg       = document.getElementById('mf-aadhaar');
  if (!statusEl || !fg) return;

  if (digits.length !== 12) {
    if (digits.length > 0) {
      statusEl.textContent = '❌ Aadhaar must be exactly 12 digits';
      statusEl.className   = 'field-hint hint-error';
      fg.classList.add('error'); fg.classList.remove('success');
    }
    return;
  }

  statusEl.textContent = '⟳ Checking for duplicates...';
  statusEl.className   = 'field-hint hint-loading';

  clearTimeout(_aadhaarCheckTimer);
  _aadhaarCheckTimer = setTimeout(async () => {
    const { ok, data } = await apiFetch(`/beneficiaries/check-aadhaar?number=${digits}`);
    if (!ok) { statusEl.textContent = ''; return; }

    if (!data.valid) {
      statusEl.textContent = '❌ ' + (data.message || 'Invalid Aadhaar');
      statusEl.className   = 'field-hint hint-error';
      fg.classList.add('error'); fg.classList.remove('success');
    } else if (data.exists) {
      statusEl.textContent = '🚨 This Aadhaar number is already registered!';
      statusEl.className   = 'field-hint hint-error';
      fg.classList.add('error'); fg.classList.remove('success');
    } else {
      statusEl.textContent = '✅ Aadhaar is available';
      statusEl.className   = 'field-hint hint-success';
      fg.classList.add('success'); fg.classList.remove('error');
    }
  }, 600);
}

// ── FAMILY ID REAL-TIME CHECK ─────────────────────────────────
let _familyCheckTimer = null;

async function checkFamilyIdDuplicate() {
  const input   = document.getElementById('new-ben-family');
  if (!input) return;
  const fid     = input.value.trim();
  const statusEl = document.getElementById('family-status');
  const fg       = document.getElementById('mf-family');
  if (!statusEl || !fg) return;

  if (!fid) {
    statusEl.textContent = '';
    fg.classList.remove('error','success');
    return;
  }

  statusEl.textContent = '⟳ Checking Family ID...';
  statusEl.className   = 'field-hint hint-loading';

  clearTimeout(_familyCheckTimer);
  _familyCheckTimer = setTimeout(async () => {
    const { ok, data } = await apiFetch(`/beneficiaries/check-family-id?id=${encodeURIComponent(fid)}`);
    if (!ok) { statusEl.textContent = ''; return; }
    if (data.exists) {
      statusEl.textContent = `🚨 ${data.message}`;
      statusEl.className   = 'field-hint hint-error';
      fg.classList.add('error'); fg.classList.remove('success');
    } else {
      statusEl.textContent = '✅ Family ID is available';
      statusEl.className   = 'field-hint hint-success';
      fg.classList.add('success'); fg.classList.remove('error');
    }
  }, 500);
}

async function submitAddBeneficiary() {
  const name     = document.getElementById('new-ben-name')?.value?.trim();
  const aadhaar  = document.getElementById('new-ben-aadhaar')?.value?.trim();
  const family   = document.getElementById('new-ben-family')?.value?.trim();
  const village  = document.getElementById('new-ben-village')?.value?.trim();
  const category = document.getElementById('new-ben-category')?.value;

  showError('ben-modal-error', '');
  // Clear per-field error highlights
  ['mf-aadhaar','mf-family','mf-village'].forEach(id => document.getElementById(id)?.classList.remove('error'));

  if (!name) { showError('ben-modal-error', '❌ Full name is required.'); return; }
  if (!aadhaar) { showError('ben-modal-error', '❌ Aadhaar number is required.'); return; }

  const digits = normaliseAadhaar(aadhaar);
  if (digits.length !== 12 || !/^\d{12}$/.test(digits)) {
    document.getElementById('mf-aadhaar')?.classList.add('error');
    showError('ben-modal-error', '❌ Aadhaar number must be exactly 12 digits.');
    return;
  }

  // Block if Aadhaar real-time check shows duplicate
  const aadhaarStatus = document.getElementById('aadhaar-status');
  if (aadhaarStatus?.classList.contains('hint-error')) {
    document.getElementById('mf-aadhaar')?.classList.add('error');
    showError('ben-modal-error', '🚨 This Aadhaar number is already registered. Fix it before submitting.');
    return;
  }

  // Block if Family ID real-time check shows duplicate
  const familyStatus = document.getElementById('family-status');
  if (familyStatus?.classList.contains('hint-error')) {
    document.getElementById('mf-family')?.classList.add('error');
    showError('ben-modal-error', '🚨 This Family ID is already registered. Each family must have a unique ID.');
    return;
  }

  // Village must be selected from dropdown
  if (!village) {
    document.getElementById('mf-village')?.classList.add('error');
    showError('ben-modal-error', '❌ Please select a village/city from the dropdown list.');
    return;
  }

  const { ok, data } = await apiFetch('/beneficiaries', 'POST', {
    name, aadhaar_number: aadhaar, family_id: family, village, income_category: category
  });

  if (ok && (data.id || data.status)) {
    showToast('✅ Beneficiary added successfully!');
    closeAddBeneficiary();
    loadBeneficiaries();
  } else {
    let errMsg = data.error || 'Failed to add beneficiary. Please try again.';
    if (data.duplicate && data.field === 'aadhaar') {
      errMsg = '🚨 Aadhaar already registered — duplicate Aadhaar is not allowed.';
      document.getElementById('mf-aadhaar')?.classList.add('error');
    } else if (data.duplicate && data.field === 'family_id') {
      errMsg = '🚨 This Family ID is already registered. Each family can only have one entry.';
      document.getElementById('mf-family')?.classList.add('error');
    } else if (data.invalid_village) {
      errMsg = `🚨 "${village}" is not in our service area. Valid villages: ${(data.valid_villages || []).join(', ')}.`;
      document.getElementById('mf-village')?.classList.add('error');
    }
    showError('ben-modal-error', errMsg);
  }
}

// ══════════════════════════════════════════════════════════════
// RATION SHOPS
// ══════════════════════════════════════════════════════════════
let allShops = [];

async function loadShops() {
  const [s1, s2] = await Promise.all([apiFetch('/shops'), apiFetch('/risk/scores')]);
  if (!s1.ok) return;
  allShops = Array.isArray(s1.data) ? s1.data : [];
  const riskMap = {};
  if (s2.ok && s2.data?.risk_scores) s2.data.risk_scores.forEach(r => riskMap[r.shop_id] = r);
  renderShops(allShops, riskMap);
}

function renderShops(list, riskMap = {}) {
  const tbody = document.getElementById('shops-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  setEl('shops-count', `${list.length} shop${list.length !== 1 ? 's' : ''}`);

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No ration shops registered yet</td></tr>';
    return;
  }

  list.forEach(shop => {
    const r     = riskMap[shop.shop_id] || {};
    const score = r.risk_score ?? 0;
    const level = score >= 61 ? 'HIGH RISK' : score >= 31 ? 'MEDIUM' : 'LOW RISK';
    const color = score >= 61 ? '#ff3b5c'   : score >= 31 ? '#ffb800' : '#00e58a';
    const tr    = document.createElement('tr');
    tr.innerHTML = `
      <td><span style="color:var(--accent);font-weight:700;font-size:12px">SHP-${String(shop.shop_id).padStart(3,'0')}</span></td>
      <td><strong>${escHtml(shop.shop_name)}</strong></td>
      <td>${escHtml(shop.location || '—')}</td>
      <td>${escHtml(shop.dealer_name || '—')}</td>
      <td style="font-size:12px">${escHtml(shop.license_number || '—')}</td>
      <td>
        <div class="risk-bar-wrap">
          <div class="risk-bar-track"><div class="risk-bar-fill" style="background:${color};width:${Math.min(score,100)}%"></div></div>
          <span class="risk-bar-text" style="color:${color}">${score}/100</span>
        </div>
      </td>
      <td><span class="badge" style="background:${color}18;color:${color};border:1px solid ${color}40">● ${level}</span></td>`;
    tbody.appendChild(tr);
  });
}

function openAddShop()  {
  ['new-shop-name','new-shop-location','new-shop-dealer','new-shop-license'].forEach(id => { const e = document.getElementById(id); if (e) e.value = ''; });
  showError('shop-modal-error', '');
  document.getElementById('modal-add-shop').style.display = 'flex';
}
function closeAddShop() { document.getElementById('modal-add-shop').style.display = 'none'; }

async function submitAddShop() {
  const shop_name      = document.getElementById('new-shop-name')?.value?.trim();
  const location       = document.getElementById('new-shop-location')?.value?.trim();
  const dealer_name    = document.getElementById('new-shop-dealer')?.value?.trim();
  const license_number = document.getElementById('new-shop-license')?.value?.trim();

  showError('shop-modal-error', '');
  if (!shop_name) { showError('shop-modal-error', 'Shop name is required.'); return; }
  if (!location)  { showError('shop-modal-error', 'Location is required.'); return; }

  const { ok, data } = await apiFetch('/shops', 'POST', { shop_name, location, dealer_name, license_number });

  if (ok && (data.id || data.status)) {
    showToast('✅ Ration shop added!');
    closeAddShop();
    loadShops();
  } else {
    showError('shop-modal-error', data.error || 'Failed to add shop.');
  }
}

// ══════════════════════════════════════════════════════════════
// STOCK ALLOCATION
// ══════════════════════════════════════════════════════════════
async function loadAllocations() {
  await populateShopDropdown('alloc-shop-select');
  const { ok, data } = await apiFetch('/allocations');
  if (ok && Array.isArray(data)) renderAllocations(data);
}

function renderAllocations(list) {
  const tbody = document.getElementById('alloc-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No allocations recorded yet</td></tr>';
    return;
  }

  list.forEach(a => {
    const total = (+a.rice_allocated||0) + (+a.wheat_allocated||0) + (+a.sugar_allocated||0);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="color:var(--accent);font-weight:700;font-size:12px">ALC-${String(a.allocation_id).padStart(3,'0')}</td>
      <td>${escHtml(a.shop_name || '—')}</td>
      <td>${escHtml(a.month || '—')}</td>
      <td>${(+a.rice_allocated  || 0).toLocaleString()}</td>
      <td>${(+a.wheat_allocated || 0).toLocaleString()}</td>
      <td>${(+a.sugar_allocated || 0).toLocaleString()}</td>
      <td><strong>${total.toLocaleString()}</strong></td>`;
    tbody.appendChild(tr);
  });
}

async function saveAllocation() {
  const shop_id         = document.getElementById('alloc-shop-select')?.value;
  const month           = document.getElementById('alloc-month')?.value;
  const rice_allocated  = parseFloat(document.getElementById('alloc-rice')?.value)  || 0;
  const wheat_allocated = parseFloat(document.getElementById('alloc-wheat')?.value) || 0;
  const sugar_allocated = parseFloat(document.getElementById('alloc-sugar')?.value) || 0;

  if (!shop_id) { showToast('Please select a shop!', 'warning'); return; }
  if (!month)   { showToast('Please select a month!', 'warning'); return; }
  if (!rice_allocated && !wheat_allocated && !sugar_allocated) {
    showToast('Enter at least one quantity!', 'warning'); return;
  }

  const { ok, data } = await apiFetch('/allocations', 'POST', {
    shop_id: parseInt(shop_id), month, rice_allocated, wheat_allocated, sugar_allocated
  });

  if (ok && (data.id || data.status)) {
    showToast('✅ Stock allocation saved!');
    ['alloc-rice','alloc-wheat','alloc-sugar'].forEach(id => { const e = document.getElementById(id); if(e) e.value=''; });
    document.getElementById('alloc-shop-select').value = '';
    document.getElementById('alloc-month').value = '';
    loadAllocations();
  } else {
    showToast(data.error || 'Failed to save allocation.', 'error');
  }
}

// ══════════════════════════════════════════════════════════════
// DISTRIBUTION LOG
// ══════════════════════════════════════════════════════════════
async function loadDistributions() {
  await populateShopDropdown('dist-shop-select');
  const { ok, data } = await apiFetch('/distributions');
  if (ok && Array.isArray(data)) renderDistributions(data);
}

function renderDistributions(list) {
  const tbody = document.getElementById('dist-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No distributions recorded yet</td></tr>';
    return;
  }

  list.forEach(d => {
    const dateStr = d.date ? new Date(d.date).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' }) : '—';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="color:var(--accent);font-weight:700;font-size:12px">DST-${String(d.distribution_id).padStart(3,'0')}</td>
      <td>${d.ration_card_id || '—'}</td>
      <td>${escHtml(d.shop_name || '—')}</td>
      <td>${dateStr}</td>
      <td>${(+d.rice_given  || 0).toLocaleString()}</td>
      <td>${(+d.wheat_given || 0).toLocaleString()}</td>
      <td>${(+d.sugar_given || 0).toLocaleString()}</td>`;
    tbody.appendChild(tr);
  });
}

async function recordDistribution() {
  const shop_id    = document.getElementById('dist-shop-select')?.value;
  const rice_given  = parseFloat(document.getElementById('dist-rice')?.value)  || 0;
  const wheat_given = parseFloat(document.getElementById('dist-wheat')?.value) || 0;
  const sugar_given = parseFloat(document.getElementById('dist-sugar')?.value) || 0;

  if (!shop_id) { showToast('Please select a shop!', 'warning'); return; }
  if (!rice_given && !wheat_given && !sugar_given) { showToast('Enter at least one quantity!', 'warning'); return; }

  const { ok, data } = await apiFetch('/distributions', 'POST', {
    shop_id: parseInt(shop_id), rice_given, wheat_given, sugar_given
  });

  if (ok && (data.id || data.status)) {
    showToast('✅ Distribution recorded!');
    ['dist-rice','dist-wheat','dist-sugar'].forEach(id => { const e = document.getElementById(id); if(e) e.value=''; });
    document.getElementById('dist-shop-select').value = '';
    loadDistributions();
  } else {
    showToast(data.error || 'Failed to record distribution.', 'error');
  }
}

// ══════════════════════════════════════════════════════════════
// LEAKAGE DETECTION
// ══════════════════════════════════════════════════════════════
async function loadDetection() {
  // auto-run on first visit
  await runDetection();
}

async function runDetection() {
  const btn = document.getElementById('run-detection-btn');
  if (btn) { btn.textContent = '⟳ Analysing...'; btn.disabled = true; }

  showToast('🔍 Running fraud detection algorithms...', 'info', 2000);

  const [r1, r2] = await Promise.all([apiFetch('/detect/leakage'), apiFetch('/risk/scores')]);

  if (btn) { btn.innerHTML = '⚡ Run Detection Now'; btn.disabled = false; }

  if (!r1.ok) { showToast('Detection failed. Is Flask running?', 'error'); return; }

  const detect = r1.data;
  setEl('det-suspicious',  detect.suspicious_shops ?? 0);
  setEl('det-duplicates',  detect.duplicate_count  ?? 0);
  setEl('det-leakage-pct', (detect.leakage_percent ?? 0) + '%');

  if (r2.ok && r2.data?.risk_scores) {
    renderRiskTable(r2.data.risk_scores);
    renderDistrictMap(r2.data.risk_scores);
  }

  showToast('✅ Detection analysis complete!', 'success');
}

function renderRiskTable(scores) {
  const tbody = document.getElementById('risk-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  scores.sort((a, b) => b.risk_score - a.risk_score);

  scores.forEach(s => {
    const score  = s.risk_score ?? 0;
    const level  = score >= 61 ? 'HIGH RISK' : score >= 31 ? 'MEDIUM' : 'LOW RISK';
    const color  = score >= 61 ? '#ff3b5c'   : score >= 31 ? '#ffb800' : '#00e58a';
    const mis    = s.mismatch_kg ?? 0;
    const misHtml = mis > 0
      ? `<span style="color:var(--danger)">${mis.toLocaleString()} kg ⚠</span>`
      : `<span style="color:var(--success)">✅ OK</span>`;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${escHtml(s.shop_name)}</strong></td>
      <td>${s.allocated_kg   ? s.allocated_kg.toLocaleString()+' kg'   : '—'}</td>
      <td>${s.distributed_kg ? s.distributed_kg.toLocaleString()+' kg' : '—'}</td>
      <td>${misHtml}</td>
      <td>
        <div class="risk-bar-wrap">
          <div class="risk-bar-track"><div class="risk-bar-fill" style="background:${color};width:${score}%"></div></div>
          <span class="risk-bar-text" style="color:${color}">${score}/100</span>
        </div>
      </td>
      <td><span class="badge" style="background:${color}18;color:${color};border:1px solid ${color}40">● ${level}</span></td>`;
    tbody.appendChild(tr);
  });
}

function renderDistrictMap(scores) {
  const container = document.getElementById('district-map');
  if (!container) return;
  container.innerHTML = '';

  const districts = {};
  scores.forEach(s => {
    const loc = s.location || 'Unknown';
    if (!districts[loc]) districts[loc] = { shops: [], total: 0 };
    districts[loc].shops.push(s);
    districts[loc].total += s.risk_score ?? 0;
  });

  if (!Object.keys(districts).length) {
    container.innerHTML = '<p style="color:var(--text-muted);padding:20px">No district data available. Add shops first.</p>';
    return;
  }

  Object.entries(districts).forEach(([name, info]) => {
    const avg   = Math.round(info.total / info.shops.length);
    const level = avg >= 61 ? 'HIGH RISK' : avg >= 31 ? 'MEDIUM' : 'LOW RISK';
    const color = avg >= 61 ? '#ff3b5c'   : avg >= 31 ? '#ffb800' : '#00e58a';
    const card  = document.createElement('div');
    card.style.cssText = `
      background:var(--bg-card2);
      border:1px solid rgba(${avg>=61?'255,59,92':avg>=31?'255,184,0':'0,229,138'},0.25);
      border-top:3px solid ${color};
      border-radius:var(--r-lg);
      padding:20px;min-width:200px;flex:1;max-width:260px;
      transition: transform 0.2s,box-shadow 0.2s;cursor:default;`;
    card.onmouseover = () => { card.style.transform='translateY(-3px)'; card.style.boxShadow=`0 8px 24px rgba(0,0,0,0.3)`; };
    card.onmouseout  = () => { card.style.transform=''; card.style.boxShadow=''; };
    card.innerHTML = `
      <div style="font-weight:700;color:var(--text-primary);margin-bottom:4px">📍 ${escHtml(name)}</div>
      <div style="font-size:11px;color:var(--text-muted);margin-bottom:14px">${info.shops.length} shop(s)</div>
      <div class="risk-bar-track" style="margin-bottom:6px">
        <div class="risk-bar-fill" style="background:${color};width:${Math.min(avg,100)}%"></div>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="color:${color};font-size:13px;font-weight:600">Score: ${avg}/100</span>
        <span style="background:${color}18;color:${color};border:1px solid ${color}40;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:600">● ${level}</span>
      </div>`;
    container.appendChild(card);
  });
}

// ══════════════════════════════════════════════════════════════
// REPORTS
// ══════════════════════════════════════════════════════════════
async function loadReports() {
  const [r1, r2] = await Promise.all([
    apiFetch('/risk/scores'),
    apiFetch('/dashboard/stats')
  ]);
  if (r1.ok && r1.data?.risk_scores) renderReportTable(r1.data.risk_scores);
  if (r1.ok && r2.ok) renderReportCharts(r1.data.risk_scores || [], r2.data);
}

function renderReportTable(scores) {
  const tbody = document.getElementById('report-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  scores.sort((a, b) => b.risk_score - a.risk_score);

  scores.forEach(s => {
    const score = s.risk_score ?? 0;
    const level = score >= 61 ? 'HIGH RISK' : score >= 31 ? 'MEDIUM' : 'LOW RISK';
    const color = score >= 61 ? '#ff3b5c'   : score >= 31 ? '#ffb800' : '#00e58a';
    const eff   = s.allocated_kg > 0 ? Math.round(s.distributed_kg / s.allocated_kg * 100) : 100;
    const leak  = 100 - eff;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${escHtml(s.shop_name)}</strong></td>
      <td>${escHtml(s.location || '—')}</td>
      <td style="color:var(--success);font-weight:600">${eff}%</td>
      <td style="color:${leak > 10 ? 'var(--danger)' : 'var(--text-muted)'};font-weight:${leak>10?'600':'400'}">${leak}%</td>
      <td>
        <div class="risk-bar-wrap">
          <div class="risk-bar-track"><div class="risk-bar-fill" style="background:${color};width:${score}%"></div></div>
          <span class="risk-bar-text" style="color:${color}">${score}/100</span>
        </div>
      </td>
      <td><span class="badge" style="background:${color}18;color:${color};border:1px solid ${color}40">● ${level}</span></td>`;
    tbody.appendChild(tr);
  });
}

function renderReportCharts(scores = [], dashData = {}) {
  // --- Chart 1: Monthly Leakage Trend (bar chart with allocated vs distributed) ---
  const c1 = document.getElementById('chart-trend');
  if (c1) {
    if (window._ct) window._ct.destroy();

    // Build per-shop efficiency data for top 8 shops
    const topShops   = scores.slice(0, 8);
    const shopLabels = topShops.map(s => s.shop_name.replace(' FPS','').replace(' No.2',''));
    const allocData  = topShops.map(s => Math.round((s.allocated_kg  || 0) / 1000 * 10) / 10);
    const distData   = topShops.map(s => Math.round((s.distributed_kg|| 0) / 1000 * 10) / 10);
    const leakData   = topShops.map(s => Math.round((s.mismatch_kg   || 0) / 1000 * 10) / 10);

    window._ct = new Chart(c1, {
      type: 'bar',
      data: {
        labels: shopLabels.length ? shopLabels : ['No Data'],
        datasets: [
          {
            label: 'Allocated (Tons)',
            data: allocData,
            backgroundColor: 'rgba(0,194,255,0.65)',
            borderColor: '#00c2ff',
            borderWidth: 1,
            borderRadius: 5
          },
          {
            label: 'Distributed (Tons)',
            data: distData,
            backgroundColor: 'rgba(0,229,138,0.65)',
            borderColor: '#00e58a',
            borderWidth: 1,
            borderRadius: 5
          },
          {
            label: 'Leakage (Tons)',
            data: leakData,
            backgroundColor: 'rgba(255,59,92,0.65)',
            borderColor: '#ff3b5c',
            borderWidth: 1,
            borderRadius: 5
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
            labels: { color: '#a0bdd8', font: { family: 'Inter', size: 11 }, padding: 16 }
          },
          tooltip: {
            callbacks: {
              label: ctx => ` ${ctx.dataset.label}: ${ctx.parsed.y} T`
            }
          }
        },
        scales: {
          x: {
            ticks: { color: '#4d6a8a', maxRotation: 40, font: { size: 10 } },
            grid:  { display: false }
          },
          y: {
            ticks: { color: '#4d6a8a', callback: v => v + ' T', font: { size: 10 } },
            grid:  { color: 'rgba(0,194,255,0.06)' },
            title: { display: true, text: 'Quantity (Tons)', color: '#4d6a8a', font: { size: 11 } }
          }
        }
      }
    });
  }

  // --- Chart 2: Beneficiary Category Distribution (donut) ---
  const c2 = document.getElementById('chart-category');
  if (c2) {
    if (window._cc) window._cc.destroy();

    // Count from allBeneficiaries if available, else use fixed sample
    const catCount = { BPL: 0, AAY: 0, APL: 0 };
    if (allBeneficiaries.length) {
      allBeneficiaries.forEach(b => { if (catCount[b.income_category] !== undefined) catCount[b.income_category]++; });
    } else {
      catCount.BPL = 18; catCount.AAY = 12; catCount.APL = 8;
    }

    window._cc = new Chart(c2, {
      type: 'doughnut',
      data: {
        labels: [
          `BPL — Below Poverty (${catCount.BPL})`,
          `AAY — Antyodaya (${catCount.AAY})`,
          `APL — Above Poverty (${catCount.APL})`
        ],
        datasets: [{
          data: [catCount.BPL, catCount.AAY, catCount.APL],
          backgroundColor: ['rgba(0,194,255,0.75)', 'rgba(255,59,92,0.75)', 'rgba(0,229,138,0.75)'],
          borderColor:     ['#00c2ff', '#ff3b5c', '#00e58a'],
          borderWidth: 2,
          hoverOffset: 12
        }]
      },
      options: {
        responsive: true,
        cutout: '60%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#a0bdd8', padding: 14, font: { family: 'Inter', size: 11 } }
          },
          tooltip: {
            callbacks: {
              label: ctx => {
                const total = ctx.dataset.data.reduce((a,b) => a+b, 0);
                const pct   = total ? Math.round(ctx.parsed / total * 100) : 0;
                return ` ${ctx.label}: ${ctx.parsed} beneficiaries (${pct}%)`;
              }
            }
          }
        }
      }
    });
  }
}

// ══════════════════════════════════════════════════════════════
// SHOP DROPDOWN HELPER
// ══════════════════════════════════════════════════════════════
async function populateShopDropdown(selectId) {
  const select = document.getElementById(selectId);
  if (!select) return;
  const { ok, data } = await apiFetch('/shops');
  if (!ok || !Array.isArray(data)) return;
  const first = select.options[0];
  select.innerHTML = '';
  if (first) select.appendChild(first);
  data.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.shop_id;
    opt.textContent = s.shop_name;
    select.appendChild(opt);
  });
}

// ══════════════════════════════════════════════════════════════
// MODAL OVERLAY CLICK (close on backdrop)
// ══════════════════════════════════════════════════════════════
function modalOverlayClick(event, modalId) {
  if (event.target.id === modalId) {
    document.getElementById(modalId).style.display = 'none';
  }
}

// ══════════════════════════════════════════════════════════════
// SECURITY: HTML ESCAPING
// ══════════════════════════════════════════════════════════════
function escHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ══════════════════════════════════════════════════════════════
// ANIMATED PARTICLES (Auth Background)
// ══════════════════════════════════════════════════════════════
function initParticles() {
  const container = document.getElementById('auth-particles');
  if (!container) return;
  for (let i = 0; i < 20; i++) {
    const dot = document.createElement('div');
    const size = Math.random() * 3 + 1;
    dot.style.cssText = `
      position:absolute;
      width:${size}px;height:${size}px;
      background:rgba(0,194,255,${Math.random() * 0.4 + 0.1});
      border-radius:50%;
      top:${Math.random() * 100}%;
      left:${Math.random() * 100}%;
      animation:float ${4 + Math.random() * 8}s ease-in-out infinite;
      animation-delay:${Math.random() * 4}s;
    `;
    container.appendChild(dot);
  }

  const style = document.createElement('style');
  style.textContent = `
    @keyframes float {
      0%,100%{ transform: translateY(0) translateX(0) scale(1); opacity:0.4; }
      33%     { transform: translateY(-${10+Math.random()*20}px) translateX(${10+Math.random()*10}px) scale(1.1); opacity:0.8; }
      66%     { transform: translateY(${5+Math.random()*15}px) translateX(-${5+Math.random()*10}px) scale(0.9); opacity:0.3; }
    }
  `;
  document.head.appendChild(style);
}

// ══════════════════════════════════════════════════════════════
// INIT
// ══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  // Nav links
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      const page = link.dataset.page;
      if (page) showPage(page);
    });
  });

  // Login on Enter key
  document.getElementById('login-user')?.addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('login-pass')?.focus(); });
  document.getElementById('login-pass')?.addEventListener('keydown', e => { if (e.key === 'Enter') handleLogin(); });
  document.getElementById('reg-pass2')?.addEventListener('keydown', e => { if (e.key === 'Enter') handleRegister(); });

  // Password visibility toggles
  bindTogglePass();

  // Animated particles
  initParticles();

  // Ensure app is hidden on load
  document.getElementById('app').style.display         = 'none';
  document.getElementById('auth-overlay').style.display = 'flex';

  // Check if already logged in (session persistence)
  apiFetch('/auth/session').then(({ ok, data }) => {
    if (ok && data.logged_in) {
      const initials = (data.full_name || data.username || 'A').charAt(0).toUpperCase();
      setEl('sidebar-name', data.full_name || data.username);
      setEl('sidebar-role', data.role === 'admin' ? 'Administrator' : 'Officer');
      setEl('sidebar-avatar', initials);
      setEl('topbar-avatar', initials);
      setEl('topbar-name', data.username);
      document.getElementById('auth-overlay').style.display = 'none';
      document.getElementById('app').style.display = 'flex';
      showPage('dashboard');
      startClock();
    }
  });
});
