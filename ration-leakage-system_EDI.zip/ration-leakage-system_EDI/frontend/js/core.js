// ── CORE: API, Auth, Navigation ──────────────────────────────────
const API = 'http://localhost:5000/api';
let currentUser = null, currentPage = 'dashboard';

async function apiFetch(path, opts={}) {
  try {
    const res = await fetch(API + path, { credentials:'include', headers:{'Content-Type':'application/json'}, ...opts });
    const data = await res.json().catch(()=>({}));
    return { ok: res.ok, status: res.status, data };
  } catch(e) { return { ok:false, data:{ error: e.message } }; }
}

// ── AUTH ──────────────────────────────────────────────────────────
function switchAuthTab(tab) {
  document.getElementById('login-form').style.display = tab==='login'?'block':'none';
  document.getElementById('register-form').style.display = tab==='register'?'block':'none';
  document.getElementById('tab-login').className = 'auth-tab'+(tab==='login'?' active':'');
  document.getElementById('tab-register').className = 'auth-tab'+(tab==='register'?' active':'');
  hideAuthMsg();
}

function showAuthError(msg) {
  const el = document.getElementById('auth-error');
  el.textContent = '⚠ ' + msg; el.style.display = 'flex';
  document.getElementById('auth-success').style.display = 'none';
}
function showAuthSuccess(msg) {
  const el = document.getElementById('auth-success');
  el.textContent = '✓ ' + msg; el.style.display = 'flex';
  document.getElementById('auth-error').style.display = 'none';
}
function hideAuthMsg() {
  document.getElementById('auth-error').style.display = 'none';
  document.getElementById('auth-success').style.display = 'none';
}

async function doLogin() {
  const username = document.getElementById('login-user').value.trim();
  const password = document.getElementById('login-pass').value.trim();
  if (!username || !password) { showAuthError('Please enter username and password.'); return; }
  document.getElementById('login-btn-text').innerHTML = '<span class="loader"></span> Authenticating...';
  const r = await apiFetch('/auth/login', { method:'POST', body: JSON.stringify({username, password}) });
  document.getElementById('login-btn-text').textContent = '🔐 Secure Login';
  if (r.ok) {
    currentUser = r.data;
    initApp();
  } else { showAuthError(r.data.error || 'Login failed.'); }
}

async function doRegister() {
  const full_name = document.getElementById('reg-name').value.trim();
  const username  = document.getElementById('reg-user').value.trim();
  const email     = document.getElementById('reg-email').value.trim();
  const phone     = document.getElementById('reg-phone').value.trim();
  const password  = document.getElementById('reg-pass').value.trim();
  const role      = document.getElementById('reg-role').value;
  if (!full_name || !username || !password) { showAuthError('Full name, username and password are required.'); return; }
  const r = await apiFetch('/auth/register', { method:'POST', body: JSON.stringify({full_name, username, email, phone, password, role}) });
  if (r.ok) { showAuthSuccess(r.data.message || 'Account created! You can now login.'); switchAuthTab('login'); }
  else { showAuthError(r.data.error || 'Registration failed.'); }
}

async function doLogout() {
  await apiFetch('/auth/logout', {method:'POST'});
  currentUser = null;
  document.getElementById('app').className = '';
  document.getElementById('auth-screen').style.display = 'flex';
}

async function checkSession() {
  const r = await apiFetch('/auth/session');
  if (r.ok && r.data.logged_in) { currentUser = r.data; initApp(); }
  else { document.getElementById('auth-screen').style.display = 'flex'; }
}

// ── SIDEBAR NAVIGATION ────────────────────────────────────────────
const NAV_CONFIG = {
  super_admin: [
    { section:'Overview' },
    { id:'dashboard', icon:'📊', label:'Dashboard' },
    { id:'analytics', icon:'📈', label:'Analytics' },
    { section:'Investigation' },
    { id:'cases', icon:'🗂️', label:'Fraud Cases', badge:'cases' },
    { id:'alerts', icon:'🚨', label:'Fraud Alerts', badge:'alerts' },
    { id:'detection', icon:'🤖', label:'AI Detection' },
    { section:'Management' },
    { id:'shops', icon:'🏪', label:'Shops' },
    { id:'beneficiaries', icon:'👥', label:'Beneficiaries' },
    { id:'complaints', icon:'📝', label:'Complaints', badge:'complaints' },
    { id:'certificates', icon:'📜', label:'Certificates' },
    { id:'stock', icon:'📦', label:'Stock Management' },
    { section:'Admin' },
    { id:'users', icon:'👤', label:'Users' },
    { id:'face-verify', icon:'👁️', label:'Face Verify' },
    { id:'audit', icon:'📋', label:'Audit Logs' },
  ],
  investigation_officer: [
    { section:'Overview' },
    { id:'dashboard', icon:'📊', label:'Dashboard' },
    { id:'analytics', icon:'📈', label:'Analytics' },
    { section:'Investigation' },
    { id:'cases', icon:'🗂️', label:'Fraud Cases' },
    { id:'alerts', icon:'🚨', label:'Alerts' },
    { id:'detection', icon:'🤖', label:'AI Detection' },
    { section:'Data' },
    { id:'shops', icon:'🏪', label:'Shops' },
    { id:'beneficiaries', icon:'👥', label:'Beneficiaries' },
    { id:'complaints', icon:'📝', label:'Complaints' },
    { id:'certificates', icon:'📜', label:'Certificates' },
    { id:'stock', icon:'📦', label:'Stock Management' },
    { id:'face-verify', icon:'👁️', label:'Face Verify' },
  ],
  shop_owner: [
    { section:'My Portal' },
    { id:'dashboard', icon:'📊', label:'Dashboard' },
    { id:'certificates', icon:'📜', label:'My Certificate' },
    { section:'Public' },
    { id:'complaints', icon:'📝', label:'File Complaint' },
    { id:'face-verify', icon:'👁️', label:'Face Verify' },
  ],
  public_user: [
    { section:'Public Portal' },
    { id:'dashboard', icon:'📊', label:'Overview' },
    { id:'complaints', icon:'📝', label:'File Complaint' },
    { id:'certificates', icon:'📜', label:'Verify Certificate' },
    { id:'beneficiaries', icon:'👥', label:'Register' },
  ],
};

function buildSidebar() {
  const role = currentUser.role || 'public_user';
  const items = NAV_CONFIG[role] || NAV_CONFIG.public_user;
  const nav = document.getElementById('sidebar-nav');
  nav.innerHTML = items.map(it => {
    if (it.section) return `<div class="nav-section">${it.section}</div>`;
    return `<div class="nav-item" id="nav-${it.id}" onclick="showPage('${it.id}')">
      <span class="nav-icon">${it.icon}</span>${it.label}
    </div>`;
  }).join('');
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const pg = document.getElementById('page-' + pageId);
  if (pg) { pg.classList.add('active'); currentPage = pageId; }
  const nav = document.getElementById('nav-' + pageId);
  if (nav) nav.classList.add('active');
  const titles = {
    dashboard:'Dashboard', shops:'Shop Management', beneficiaries:'Beneficiaries',
    cases:'Fraud Cases', alerts:'Fraud Alerts', complaints:'Public Complaints',
    certificates:'Certificate Management', analytics:'Analytics & Reports',
    users:'User Management', audit:'Audit Logs', 'face-verify':'Face Verification',
    detection:'AI Fraud Detection', profile:'My Profile', stock:'Stock Management'
  };
  const subs = {
    dashboard:'System overview and key metrics',
    shops:'Monitor and manage registered shops',
    cases:'Investigate and manage fraud cases',
    alerts:'AI-generated fraud warning system',
    complaints:'Review public complaints',
    certificates:'Digital certificate lifecycle',
    analytics:'Charts and statistical reports',
    'face-verify':'AI-powered identity verification',
    detection:'Automated fraud detection algorithms',
    stock:'Allocate stock to shops and record distributions',
  };
  document.getElementById('topbar-title').textContent = titles[pageId] || pageId;
  document.getElementById('topbar-sub').textContent = subs[pageId] || '';
  renderPage(pageId);
}

// ── MODAL ─────────────────────────────────────────────────────────
function openModal(title, bodyHtml, footerHtml='') {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-footer').innerHTML = footerHtml;
  document.getElementById('modal-overlay').style.display = 'flex';
}
function closeModal(e) {
  if (!e || e.target === document.getElementById('modal-overlay'))
    document.getElementById('modal-overlay').style.display = 'none';
}

// ── NOTIFICATIONS ─────────────────────────────────────────────────
async function loadNotifications() {
  const r = await apiFetch('/notifications');
  if (!r.ok) return;
  const items = r.data;
  const unread = items.filter(n => !n.is_read).length;
  document.getElementById('notif-dot').style.display = unread ? 'block' : 'none';
  const list = document.getElementById('notif-list');
  if (!items.length) { list.innerHTML = '<div class="empty-state"><div class="e-icon">🔔</div><p>No notifications</p></div>'; return; }
  list.innerHTML = items.map(n => `
    <div class="notif-item ${n.is_read?'':'unread'}">
      <div class="n-title">${notifIcon(n.notif_type)} ${esc(n.title)}</div>
      <div class="n-msg">${esc(n.message)}</div>
      <div class="n-time">${timeAgo(n.created_at)}</div>
    </div>`).join('');
}

function notifIcon(t) {
  return {fraud_alert:'🚨',case_update:'🗂️',complaint:'📝',certificate:'📜',warning:'⚠️',system:'ℹ️'}[t]||'🔔';
}

function toggleNotifPanel() {
  const p = document.getElementById('notif-panel');
  p.style.display = p.style.display==='none' ? 'block' : 'none';
  if (p.style.display === 'block') loadNotifications();
}

async function markAllRead() {
  await apiFetch('/notifications/read', {method:'PUT'});
  document.getElementById('notif-dot').style.display = 'none';
  loadNotifications();
}

// ── UTILITIES ─────────────────────────────────────────────────────
function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function timeAgo(ts) {
  if (!ts) return '';
  const d = new Date(ts), now = new Date();
  const diff = Math.floor((now - d) / 1000);
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff/60) + 'm ago';
  if (diff < 86400) return Math.floor(diff/3600) + 'h ago';
  return Math.floor(diff/86400) + 'd ago';
}

function fmtDate(s) {
  if (!s) return '—';
  try { return new Date(s).toLocaleDateString('en-IN', {day:'2-digit', month:'short', year:'numeric'}); }
  catch { return s; }
}

function statusBadge(s) {
  const map = {
    active:'badge-green', verified:'badge-green', verified_fraud:'badge-red',
    blocked:'badge-red', failed:'badge-red', revoked:'badge-red',
    suspended:'badge-orange', under_review:'badge-yellow', open:'badge-blue',
    pending:'badge-yellow', suspicious:'badge-yellow', new:'badge-red',
    submitted:'badge-blue', acknowledged:'badge-yellow', resolved:'badge-green',
    valid:'badge-green', expired:'badge-orange', closed:'badge-gray',
    rejected:'badge-gray', low:'badge-green', medium:'badge-yellow',
    high:'badge-orange', critical:'badge-red', assigned:'badge-purple'
  };
  const cls = map[s] || 'badge-gray';
  return `<span class="badge ${cls}">${esc(s||'—').replace(/_/g,' ')}</span>`;
}

function riskBadge(score) {
  const label = score>=80?'Critical':score>=60?'High':score>=30?'Medium':'Low';
  const cls = score>=80?'risk-crit':score>=60?'risk-high':score>=30?'risk-med':'risk-low';
  return `<div class="${cls}" style="display:inline-flex;align-items:center;gap:6px">
    <div class="risk-bar"><div class="risk-fill" style="width:${score}%"></div></div>
    <span style="font-size:12px;font-weight:600">${score}</span>
    <span class="badge ${score>=80?'badge-red':score>=60?'badge-orange':score>=30?'badge-yellow':'badge-green'}">${label}</span>
  </div>`;
}

function updateClock() {
  document.getElementById('topbar-time').textContent =
    new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
}

// ── INIT ──────────────────────────────────────────────────────────
function initApp() {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('app').className = 'visible';
  document.getElementById('sidebar-name').textContent = currentUser.full_name || currentUser.username;
  document.getElementById('sidebar-role').textContent = (currentUser.role||'').replace(/_/g,' ');
  document.getElementById('sidebar-avatar').textContent = (currentUser.full_name||'A')[0].toUpperCase();
  buildSidebar();
  showPage('dashboard');
  loadNotifications();
  setInterval(updateClock, 1000);
  setInterval(loadNotifications, 30000);
  updateClock();
}

document.addEventListener('DOMContentLoaded', () => {
  checkSession();
  document.addEventListener('keydown', e => { if (e.key==='Escape') closeModal(); });
  document.addEventListener('click', e => {
    const panel = document.getElementById('notif-panel');
    const btn = document.getElementById('notif-btn');
    if (panel && !panel.contains(e.target) && !btn.contains(e.target))
      panel.style.display = 'none';
  });
  ['login-user','login-pass'].forEach(id => {
    document.getElementById(id)?.addEventListener('keydown', e => { if(e.key==='Enter') doLogin(); });
  });
});
