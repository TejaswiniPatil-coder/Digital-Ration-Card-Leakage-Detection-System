// ── CERTIFICATES ──────────────────────────────────────────────────
async function renderCertificates() {
  const pg = document.getElementById('page-certificates');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading...</div>';
  const r = await apiFetch('/certificates');
  const certs = r.ok ? (r.data||[]) : [];
  const isAdmin = ['super_admin','investigation_officer'].includes(currentUser.role);
  pg.innerHTML = `
  <div class="section-header">
    <div><h2>📜 Certificate Management</h2><p>${certs.length} certificates</p></div>
    <div class="d-flex gap-8">
      <button class="btn btn-sm btn-accent" onclick="showVerifyModal()">🔍 Verify Cert</button>
      ${isAdmin?`<button class="btn btn-sm btn-primary" onclick="showIssueCertModal()">➕ Issue Certificate</button>`:''}
    </div>
  </div>
  <div class="table-wrap">
    <div class="table-head"><h3>Certificates</h3></div>
    <div style="overflow-x:auto"><table>
      <thead><tr><th>Cert ID</th><th>Shop</th><th>Issued To</th><th>Type</th><th>Issue Date</th><th>Expiry</th><th>Status</th>${isAdmin?'<th>Actions</th>':''}</tr></thead>
      <tbody>${certs.map(c=>`<tr>
        <td><code style="color:var(--accent2);font-size:11px">${esc(c.cert_unique_id)}</code></td>
        <td>${esc(c.shop_name||'—')}</td>
        <td>${esc(c.issued_to||'—')}</td>
        <td><span class="badge badge-blue">${esc(c.cert_type||'—')}</span></td>
        <td>${fmtDate(c.issue_date)}</td>
        <td style="color:${c.expiry_date&&new Date(c.expiry_date)<new Date()?'var(--red)':'inherit'}">${fmtDate(c.expiry_date)}</td>
        <td>${statusBadge(c.status)}</td>
        ${isAdmin?`<td><div class="d-flex gap-8">
          <button class="btn btn-sm btn-secondary" onclick="viewCertQR('${esc(c.cert_unique_id)}')">🔲 QR</button>
          ${c.status==='valid'?`<button class="btn btn-sm btn-danger" onclick="revokeCert(${c.cert_id})">🚫 Revoke</button>`:''}
        </div></td>`:''}
      </tr>`).join('')}</tbody>
    </table></div>
  </div>`;
  window._certsData = certs;
}

function showVerifyModal() {
  openModal('🔍 Verify Certificate', `
    <div class="form-group"><label>Enter Certificate ID</label><input id="verify-cert-id" placeholder="CERT-2024-XXXXXXXX"/></div>
    <div id="verify-result" style="margin-top:12px"></div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Close</button>
     <button class="btn btn-primary btn-sm" onclick="verifyCert()">Verify</button>`);
}
async function verifyCert() {
  const id = document.getElementById('verify-cert-id').value.trim();
  if (!id) return;
  const r = await apiFetch(`/certificates/verify/${encodeURIComponent(id)}`);
  const res = document.getElementById('verify-result');
  if (!r.ok) { res.innerHTML = '<div class="alert-box error">Certificate not found.</div>'; return; }
  const d = r.data;
  const c = d.certificate || {};
  res.innerHTML = `<div class="cert-card">
    <div class="cert-header">
      <div class="cert-seal">${d.valid?'✅':'❌'}</div>
      <div>
        <div class="cert-id">${esc(c.cert_unique_id||id)}</div>
        <div class="${d.valid?'cert-status-valid':'cert-status-invalid'}">${d.valid?'✓ VALID CERTIFICATE':'✗ INVALID CERTIFICATE'}</div>
      </div>
    </div>
    <div class="grid-2">
      <div><span class="text-muted" style="font-size:12px">Shop</span><p style="color:#fff">${esc(c.shop_name||'—')}</p></div>
      <div><span class="text-muted" style="font-size:12px">Issued To</span><p style="color:#fff">${esc(c.issued_to||'—')}</p></div>
      <div><span class="text-muted" style="font-size:12px">Issue Date</span><p style="color:var(--text)">${fmtDate(c.issue_date)}</p></div>
      <div><span class="text-muted" style="font-size:12px">Expiry</span><p style="color:var(--text)">${fmtDate(c.expiry_date)}</p></div>
    </div>
    <div style="margin-top:12px">${statusBadge(c.status)} ${d.expired?'<span class="badge badge-red">EXPIRED</span>':''}</div>
  </div>`;
}

function showIssueCertModal() {
  openModal('➕ Issue Certificate', `
    <div class="grid-2">
      <div class="form-group"><label>Issued To *</label><input id="ic-to" placeholder="Dealer/owner name"/></div>
      <div class="form-group"><label>Shop ID</label><input id="ic-shop" type="number" placeholder="Shop ID"/></div>
      <div class="form-group"><label>Issue Date</label><input id="ic-issue" type="date" value="${new Date().toISOString().split('T')[0]}"/></div>
      <div class="form-group"><label>Expiry Date *</label><input id="ic-expiry" type="date"/></div>
    </div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Cancel</button>
     <button class="btn btn-primary btn-sm" onclick="submitIssueCert()">Issue</button>`);
}
async function submitIssueCert() {
  const data = { issued_to: document.getElementById('ic-to').value.trim(), shop_id: document.getElementById('ic-shop').value||null,
    issue_date: document.getElementById('ic-issue').value, expiry_date: document.getElementById('ic-expiry').value };
  if (!data.issued_to || !data.expiry_date) { showToast('Required fields missing','error'); return; }
  const r = await apiFetch('/certificates', { method:'POST', body: JSON.stringify(data) });
  if (r.ok) { closeModal(); showToast(`Certificate ${r.data.cert_unique_id} issued!`,'success'); renderCertificates(); }
  else showToast(r.data.error||'Failed','error');
}

async function revokeCert(certId) {
  const reason = prompt('Reason for revoking certificate:');
  if (!reason) return;
  const r = await apiFetch(`/certificates/${certId}/revoke`, { method:'PUT', body: JSON.stringify({reason}) });
  if (r.ok) { showToast('Certificate revoked','success'); renderCertificates(); }
}

function viewCertQR(certId) {
  openModal('🔲 Certificate QR Code', `
    <div style="text-align:center">
      <div id="qr-container" style="display:inline-block;padding:16px;background:#fff;border-radius:12px;margin:12px auto"></div>
      <p style="color:var(--text2);font-size:13px;margin-top:12px">${esc(certId)}</p>
      <p style="color:var(--text3);font-size:12px;margin-top:4px">Scan to verify authenticity</p>
    </div>`,
    `<button class="btn btn-secondary btn-sm" onclick="closeModal()">Close</button>`);
  setTimeout(()=>{ try { new QRCode(document.getElementById('qr-container'),{text:certId,width:180,height:180}); } catch(e){} }, 100);
}

// ── ANALYTICS ─────────────────────────────────────────────────────
async function renderAnalytics() {
  const pg = document.getElementById('page-analytics');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading analytics...</div>';
  const [statsR, monthlyR, stateR] = await Promise.all([apiFetch('/dashboard/stats'), apiFetch('/analytics/monthly'), apiFetch('/analytics/state')]);
  const s = statsR.ok ? statsR.data : {};
  const monthly = monthlyR.ok ? (monthlyR.data||[]) : [];
  const states = stateR.ok ? (stateR.data||[]) : [];
  pg.innerHTML = `
  <div class="section-header"><div><h2>📈 Analytics & Reports</h2><p>System-wide statistics and trends</p></div></div>
  <div class="stat-grid" style="margin-bottom:24px">
    <div class="stat-card blue"><div class="s-label">Total Allocated (kg)</div><div class="s-val">${(s.allocated_kg||0).toFixed(0)}</div></div>
    <div class="stat-card green"><div class="s-label">Total Distributed (kg)</div><div class="s-val">${(s.distributed_kg||0).toFixed(0)}</div></div>
    <div class="stat-card red"><div class="s-label">Total Leakage (kg)</div><div class="s-val">${(s.leakage_kg||0).toFixed(0)}</div></div>
    <div class="stat-card yellow"><div class="s-label">Avg Risk Score</div><div class="s-val">${s.avg_risk_score||0}</div></div>
  </div>
  <div class="grid-2" style="gap:20px;margin-bottom:20px">
    <div class="chart-wrap"><div class="card-title">📊 Monthly Distribution</div><canvas id="chart-monthly"></canvas></div>
    <div class="chart-wrap"><div class="card-title">🗂️ Case Status Breakdown</div><canvas id="chart-cases"></canvas></div>
  </div>
  <div class="grid-2" style="gap:20px">
    <div class="chart-wrap"><div class="card-title">👁️ Face Verification Rates</div><canvas id="chart-face"></canvas></div>
    <div class="card">
      <div class="card-title">🗺️ State-wise Analysis</div>
      <table style="width:100%"><thead><tr><th>State</th><th>Shops</th><th>Avg Risk</th><th>Flagged</th></tr></thead>
      <tbody>${states.map(s=>`<tr>
        <td style="color:#fff">${esc(s.state)}</td><td>${s.shops}</td>
        <td>${riskBadge(Math.round(s.avg_risk||0))}</td>
        <td>${s.flagged>0?`<span class="badge badge-red">${s.flagged}</span>`:`<span class="badge badge-green">0</span>`}</td>
      </tr>`).join('')}</tbody></table>
    </div>
  </div>`;
  const months = monthly.map(m=>m.month), vals = monthly.map(m=>parseFloat(m.total_distributed)||0);
  const mCtx = document.getElementById('chart-monthly');
  if (mCtx) new Chart(mCtx, { type:'line', data:{ labels: months.length ? months : ['Jan','Feb','Mar'],
    datasets:[{label:'Distributed (kg)', data: vals.length ? vals : [3800,3900,3700], borderColor:'#3b82f6', backgroundColor:'rgba(59,130,246,.1)', fill:true, tension:.4}]},
    options:{plugins:{legend:{labels:{color:'#94a3b8'}}}, scales:{x:{ticks:{color:'#64748b'},grid:{color:'rgba(255,255,255,.04)'}}, y:{ticks:{color:'#64748b'},grid:{color:'rgba(255,255,255,.04)'}}}}});
  const cCtx = document.getElementById('chart-cases');
  if (cCtx) new Chart(cCtx, { type:'pie', data:{ labels:['Open','Under Review','Fraud Verified','Closed'],
    datasets:[{data:[s.open_cases||2, 2, 2, 1], backgroundColor:['#3b82f6','#f59e0b','#ef4444','#10b981'], borderWidth:0}]},
    options:{plugins:{legend:{labels:{color:'#94a3b8',font:{family:'Inter'}}}}}});
  const fCtx = document.getElementById('chart-face');
  if (fCtx) new Chart(fCtx, { type:'doughnut', data:{ labels:['Verified','Suspicious','Failed'],
    datasets:[{data:[s.face_verified||4, 2, s.face_failed||3], backgroundColor:['#10b981','#f59e0b','#ef4444'], borderWidth:0}]},
    options:{plugins:{legend:{labels:{color:'#94a3b8'}}}, cutout:'60%'}});
}

// ── FACE VERIFICATION ─────────────────────────────────────────────
async function renderFaceVerify() {
  const pg = document.getElementById('page-face-verify');
  pg.innerHTML = `
  <div class="section-header"><div><h2>👁️ AI Face Verification</h2><p>Real-time biometric identity verification</p></div></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
    <div class="face-verify-box">
      <h3 style="color:#fff;margin-bottom:16px">📷 Live Camera Capture</h3>
      <div class="camera-frame" id="camera-frame">
        <video id="cam-video" autoplay playsinline style="width:100%;height:100%;object-fit:cover"></video>
        <div class="face-overlay"></div>
      </div>
      <p class="liveness-hint">👤 Position your face within the circle. Ensure good lighting.</p>
      <div class="d-flex gap-8" style="justify-content:center;margin-top:12px">
        <button class="btn btn-sm btn-accent" onclick="startCamera()" id="btn-start-cam">📷 Start Camera</button>
        <button class="btn btn-sm btn-primary" onclick="captureAndVerify()" id="btn-capture" style="display:none">⚡ Capture & Verify</button>
        <button class="btn btn-sm btn-secondary" onclick="stopCamera()" id="btn-stop-cam" style="display:none">⏹ Stop</button>
      </div>
    </div>
    <div class="face-verify-box">
      <h3 style="color:#fff;margin-bottom:16px">📊 Verification Result</h3>
      <div id="face-result" style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:200px">
        <div style="font-size:48px;margin-bottom:12px;opacity:.3">👤</div>
        <p style="color:var(--text3);font-size:14px">Complete face capture to see result</p>
      </div>
    </div>
  </div>
  <div class="table-wrap" style="margin-top:20px">
    <div class="table-head"><h3>Recent Verifications</h3></div>
    <div id="verify-log-placeholder" class="empty-state"><div class="e-icon">📋</div><p>Verification logs will appear here</p></div>
  </div>`;
}

let _camStream = null;
async function startCamera() {
  try {
    _camStream = await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'}});
    document.getElementById('cam-video').srcObject = _camStream;
    document.getElementById('btn-start-cam').style.display = 'none';
    document.getElementById('btn-capture').style.display = 'inline-flex';
    document.getElementById('btn-stop-cam').style.display = 'inline-flex';
    showToast('Camera started - position your face','success');
  } catch(e) { showToast('Camera access denied: '+e.message,'error'); }
}

async function captureAndVerify() {
  const btn = document.getElementById('btn-capture');
  btn.textContent = '⚡ Analyzing...'; btn.disabled = true;
  const r = await apiFetch('/detect/face-verify', { method:'POST', body: JSON.stringify({}) });
  btn.textContent = '⚡ Capture & Verify'; btn.disabled = false;
  if (!r.ok) { showToast('Verification failed','error'); return; }
  const d = r.data;
  const scoreClass = d.status==='verified'?'score-verified':d.status==='suspicious'?'score-suspicious':'score-failed';
  const icon = d.status==='verified'?'✅':d.status==='suspicious'?'⚠️':'❌';
  document.getElementById('face-result').innerHTML = `
    <div style="text-align:center">
      <div style="font-size:56px;margin-bottom:8px">${icon}</div>
      <div class="score-display ${scoreClass}">${d.confidence_score}%</div>
      <div style="font-size:16px;font-weight:700;color:#fff;margin:8px 0">${(d.status||'').toUpperCase()}</div>
      ${statusBadge(d.status)}
      <p style="color:var(--text3);font-size:13px;margin-top:12px">${esc(d.message||'')}</p>
      <div style="margin-top:12px;padding:10px;background:var(--bg);border-radius:8px;font-size:12px;color:var(--text2)">
        Liveness Check: <strong style="color:${d.liveness_passed?'var(--green)':'var(--red)'}">${d.liveness_passed?'PASSED':'FAILED'}</strong>
      </div>
    </div>`;
  showToast(d.message, d.status==='verified'?'success':'error');
}

function stopCamera() {
  if (_camStream) { _camStream.getTracks().forEach(t=>t.stop()); _camStream = null; }
  document.getElementById('btn-start-cam').style.display = 'inline-flex';
  document.getElementById('btn-capture').style.display = 'none';
  document.getElementById('btn-stop-cam').style.display = 'none';
}

// ── AI DETECTION ──────────────────────────────────────────────────
async function renderDetection() {
  const pg = document.getElementById('page-detection');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Running AI detection...</div>';
  const [detectR, riskR] = await Promise.all([apiFetch('/detect/leakage'), apiFetch('/risk/scores')]);
  const d = detectR.ok ? detectR.data : {};
  const risk = riskR.ok ? (riskR.data||{}) : {};
  const rscores = (risk.risk_scores||[]).sort((a,b)=>b.risk_score-a.risk_score);
  pg.innerHTML = `
  <div class="section-header">
    <div><h2>🤖 AI Fraud Detection</h2><p>Automated detection algorithms running</p></div>
    <button class="btn btn-sm btn-primary" onclick="renderDetection()">🔄 Refresh</button>
  </div>
  <div class="stat-grid" style="margin-bottom:20px">
    <div class="stat-card red"><div class="s-icon">🏪</div><div class="s-label">Suspicious Shops</div><div class="s-val">${d.suspicious_shops||0}</div></div>
    <div class="stat-card orange"><div class="s-icon">👥</div><div class="s-label">Duplicate Aadhaar</div><div class="s-val">${d.duplicate_count||0}</div></div>
    <div class="stat-card red"><div class="s-icon">📦</div><div class="s-label">Leakage %</div><div class="s-val">${d.leakage_percent||0}%</div></div>
    <div class="stat-card purple"><div class="s-icon">⚠️</div><div class="s-label">Multi-Registration</div><div class="s-val">${(d.multi_registration||{}).flagged_count||0}</div></div>
  </div>
  <div class="grid-2" style="gap:20px">
    <div>
      <div class="card-title" style="color:#fff;margin-bottom:12px">📊 Shop Risk Scores</div>
      <div class="table-wrap">
        <table><thead><tr><th>Shop</th><th>Risk Score</th><th>Reasons</th></tr></thead>
        <tbody>${rscores.map(s=>`<tr>
          <td><strong style="color:#fff">${esc(s.shop_name)}</strong></td>
          <td>${riskBadge(s.risk_score)}</td>
          <td style="font-size:11px;color:var(--text3)">${(s.reasons||[]).join('; ')||'—'}</td>
        </tr>`).join('')}</tbody></table>
      </div>
    </div>
    <div>
      <div class="card-title" style="color:#fff;margin-bottom:12px">📦 Stock Mismatch</div>
      ${(d.stock_mismatch||{suspicious_shops:[]}).suspicious_shops.map(s=>`
        <div class="alert-item high" style="margin-bottom:8px">
          <div class="a-icon">📦</div>
          <div style="flex:1">
            <div class="a-title">${esc(s.shop_name)}</div>
            <div class="a-desc">Allocated: ${s.allocated_kg}kg · Distributed: ${s.distributed_kg}kg · <strong style="color:var(--red)">Mismatch: ${s.mismatch_pct}%</strong></div>
          </div>
        </div>`).join('')||'<div class="empty-state"><div class="e-icon">✅</div><p>No mismatches</p></div>'}
    </div>
  </div>`;
}

// ── USERS ─────────────────────────────────────────────────────────
async function renderUsers() {
  const pg = document.getElementById('page-users');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading...</div>';
  const r = await apiFetch('/users');
  if (!r.ok) { pg.innerHTML = `<div class="alert-box error">${r.data.error}</div>`; return; }
  const users = r.data || [];
  pg.innerHTML = `
  <div class="section-header"><div><h2>👤 User Management</h2><p>${users.length} users</p></div></div>
  <div class="table-wrap">
    <div class="table-head"><h3>All Users</h3></div>
    <table><thead><tr><th>#</th><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Last Login</th><th>Actions</th></tr></thead>
    <tbody>${users.map((u,i)=>`<tr>
      <td style="color:var(--text3)">${i+1}</td>
      <td><strong style="color:#fff">${esc(u.full_name)}</strong></td>
      <td><code style="color:var(--accent2)">${esc(u.username)}</code></td>
      <td>${esc(u.email||'—')}</td>
      <td>${statusBadge(u.role)}</td>
      <td>${statusBadge(u.status)}</td>
      <td>${timeAgo(u.last_login)||'Never'}</td>
      <td><div class="d-flex gap-8">
        ${u.status==='active'?`<button class="btn btn-sm btn-warning" onclick="setUserStatus(${u.user_id},'suspended')">⏸</button>`:''}
        ${u.status!=='blocked'?`<button class="btn btn-sm btn-danger" onclick="setUserStatus(${u.user_id},'blocked')">🚫</button>`:''}
        ${u.status!=='active'?`<button class="btn btn-sm btn-success" onclick="setUserStatus(${u.user_id},'active')">✅</button>`:''}
      </div></td>
    </tr>`).join('')}</tbody></table>
  </div>`;
}
async function setUserStatus(userId, status) {
  const r = await apiFetch(`/users/${userId}/status`, { method:'PUT', body: JSON.stringify({status}) });
  if (r.ok) { showToast(`User ${status}`,'success'); renderUsers(); }
}

// ── AUDIT LOGS ────────────────────────────────────────────────────
async function renderAudit() {
  const pg = document.getElementById('page-audit');
  pg.innerHTML = '<div class="page-loader"><div class="loader"></div>Loading audit logs...</div>';
  const r = await apiFetch('/audit/logs');
  const logs = r.ok ? (r.data||[]) : [];
  pg.innerHTML = `
  <div class="section-header"><div><h2>📋 Audit Logs</h2><p>${logs.length} entries</p></div></div>
  <div class="table-wrap">
    <div class="table-head"><h3>Activity Audit Trail</h3></div>
    <table><thead><tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>Description</th><th>IP</th></tr></thead>
    <tbody>${logs.map(l=>`<tr>
      <td style="font-size:11px;color:var(--text3)">${fmtDate(l.created_at)}</td>
      <td><strong style="color:#fff">${esc(l.user_name||'System')}</strong></td>
      <td><span class="badge badge-blue">${esc(l.action)}</span></td>
      <td><code style="font-size:11px">${esc(l.entity_type||'—')} #${l.entity_id||'—'}</code></td>
      <td style="font-size:12px;color:var(--text2)">${esc(l.description||'—')}</td>
      <td style="font-size:11px;color:var(--text3)">${esc(l.ip_address||'—')}</td>
    </tr>`).join('')}</tbody></table>
  </div>`;
}
