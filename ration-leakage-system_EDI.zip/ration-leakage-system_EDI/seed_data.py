import pymysql, hashlib, random
from datetime import date, timedelta

def h(p): return hashlib.sha256(p.encode()).hexdigest()
def rd(a, b): return random.randint(a, b)
def rdate(y1, m1, y2, m2):
    d1 = date(y1, m1, 1); d2 = date(y2, m2, 28)
    return (d1 + timedelta(days=random.randint(0, (d2 - d1).days))).isoformat()

db = pymysql.connect(host='localhost', user='root', password='Patejaswini@101',
                     database='ration_system', charset='utf8mb4')
c = db.cursor()

# ── USERS (10) ──────────────────────────────────────────────────────
ud = [
    ('admin',    'Admin Officer',      'admin123',   'super_admin'),
    ('officer1', 'Ramesh Verma',       'officer123', 'investigation_officer'),
    ('officer2', 'Sunita Sharma',      'officer123', 'investigation_officer'),
    ('officer3', 'Kavita Joshi',       'officer123', 'investigation_officer'),
    ('shop1',    'Dinesh Yadav',       'shop123',    'shop_owner'),
    ('shop2',    'Geeta Singh',        'shop123',    'shop_owner'),
    ('shop3',    'Mohan Lal',          'shop123',    'shop_owner'),
    ('pub1',     'Priya Mishra',       'user123',    'public_user'),
    ('pub2',     'Arun Kumar',         'user123',    'public_user'),
    ('pub3',     'Neha Gupta',         'user123',    'public_user'),
]
for un, fn, pw, role in ud:
    c.execute(
        'INSERT INTO users(username,password_hash,full_name,email,phone,role,status)'
        'VALUES(%s,%s,%s,%s,%s,%s,%s)',
        (un, h(pw), fn, f'{un}@ration.gov.in', f'98{rd(10000000,99999999)}', role, 'active')
    )

# ── SHOPS (15) ──────────────────────────────────────────────────────
shops_raw = [
    ('Rampur FPS',          'Rampur',     'Rampur',     'Dinesh Yadav',   72, 'active',       'LIC-001'),
    ('Shivpur FPS',         'Shivpur',    'Shivpur',    'Geeta Singh',    15, 'active',       'LIC-002'),
    ('Azamnagar FPS',       'Azamnagar',  'Azamnagar',  'Ravi Patel',     85, 'active',       'LIC-003'),
    ('Lucknow Central FPS', 'Lucknow',    'Lucknow',    'Arun Mishra',    91, 'suspended',    'LIC-004'),
    ('Kasimpur FPS',        'Kasimpur',   'Kasimpur',   'Sunita Devi',    42, 'active',       'LIC-005'),
    ('Varanasi West FPS',   'Varanasi',   'Varanasi',   'Mohan Lal',      25, 'active',       'LIC-006'),
    ('Nagpur Central FPS',  'Nagpur',     'Nagpur',     'Pradeep Wagh',   55, 'active',       'LIC-007'),
    ('Kanpur FPS No.2',     'Kanpur',     'Kanpur',     'Reena Sharma',   38, 'active',       'LIC-008'),
    ('Agra North FPS',      'Agra',       'Agra',       'Suresh Dubey',   95, 'blocked',      'LIC-009'),
    ('Jhansi Road FPS',     'Jhansi',     'Jhansi',     'Asha Rani',      18, 'active',       'LIC-010'),
    ('Allahabad FPS',       'Allahabad',  'Allahabad',  'Vijay Singh',    60, 'active',       'LIC-011'),
    ('Meerut FPS',          'Meerut',     'Meerut',     'Pooja Sharma',   78, 'under_review', 'LIC-012'),
    ('Bareilly FPS',        'Bareilly',   'Bareilly',   'Rakesh Gupta',   30, 'active',       'LIC-013'),
    ('Mathura FPS',         'Mathura',    'Mathura',    'Sita Devi',      48, 'active',       'LIC-014'),
    ('Aligarh FPS',         'Aligarh',    'Aligarh',    'Hemant Rao',     82, 'suspended',    'LIC-015'),
]
sids = []
for nm, loc, dist, dealer, risk, st, lic in shops_raw:
    c.execute(
        'INSERT INTO ration_shops(shop_name,location,state,district,dealer_name,'
        'fraud_risk_score,status,license_number,certificate_status,certificate_expiry)'
        'VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',
        (nm, loc, 'Uttar Pradesh', dist, dealer, risk, st, lic, 'valid', '2026-12-31')
    )
    sids.append(c.lastrowid)

# ── BENEFICIARIES (53 + 3 intentional duplicates) ───────────────────
names = [
    'Ramesh Kumar','Sita Devi','Mohammed Irfan','Priya Sharma','Vijay Singh',
    'Lakshmi Bai','Suresh Gupta','Anita Mishra','Raj Kapoor','Sunita Yadav',
    'Meena Kumari','Bharat Singh','Santosh Kumar','Usha Singh','Govind Ram',
    'Champa Devi','Rekha Wagh','Anil Deshmukh','Kavita Patil','Dinesh Borde',
    'Reena Sharma','Mohan Das','Parvati Devi','Nasreen Begum','Salim Khan',
    'Deepak Tiwari','Poonam Yadav','Heera Lal','Geeta Kumari','Reshma Patel',
    'Imran Siddiqui','Vikram Gupta','Radha Devi','Nisha Verma','Arun Patel',
    'Kamlesh Yadav','Rajan Mishra','Fatima Begum','Sunil Sharma','Ganesh Ram',
    'Archana Singh','Bablu Gupta','Chandra Devi','Dheeraj Kumar','Eshwar Prasad',
    'Falguni Shah','Gita Patel','Hema Lata','Ishaan Verma','Jyoti Rani',
    'Kiran Devi','Lalita Bai','Manju Singh',
]
vils = ['Rampur','Shivpur','Azamnagar','Lucknow','Kasimpur','Varanasi','Nagpur',
        'Kanpur','Agra','Jhansi','Allahabad','Meerut','Bareilly','Mathura','Aligarh']
cats = ['BPL','AAY','APL']
used_aadhaar = []
bids = []

for i, nm in enumerate(names):
    while True:
        a = f'{rd(1000,9999)} {rd(1000,9999)} {rd(1000,9999)}'
        if a not in used_aadhaar:
            used_aadhaar.append(a); break
    vs = ['pending','verified','verified','suspicious','failed'][i % 5]
    fs = round(random.uniform(65, 99), 1) if vs == 'verified' else round(random.uniform(10, 54), 1)
    c.execute(
        'INSERT INTO beneficiaries(name,aadhaar_number,family_id,village,income_category,'
        'phone,face_verified,face_score,verification_status)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)',
        (nm, a, f'FAM-{str(i+1).zfill(3)}', vils[i % 15], cats[i % 3],
         f'9{rd(100000000,999999999)}', vs == 'verified', fs, vs)
    )
    bids.append(c.lastrowid)

# 3 duplicate Aadhaar records (fraud demo)
for i in range(3):
    c.execute(
        'INSERT INTO beneficiaries(name,aadhaar_number,family_id,village,income_category,'
        'phone,face_verified,face_score,verification_status)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)',
        (f'Fraud Person {i+1}', used_aadhaar[i], f'FAM-DUP-{i+1}', vils[i], 'BPL',
         f'7{rd(100000000,999999999)}', False, round(random.uniform(10, 40), 1), 'suspicious')
    )
    bids.append(c.lastrowid)

# ── RATION CARDS (40) ───────────────────────────────────────────────
cids = []
for i in range(40):
    c.execute(
        'INSERT INTO ration_cards(family_id,card_type,issue_date,expiry_date,status)'
        'VALUES(%s,%s,%s,%s,%s)',
        (f'FAM-{str(i+1).zfill(3)}', cats[i % 3],
         rdate(2021, 1, 2023, 6), rdate(2025, 1, 2027, 12), 'Active')
    )
    cids.append(c.lastrowid)

# ── STOCK ALLOCATIONS (60) ─────────────────────────────────────────
months = ['Oct 2024','Nov 2024','Dec 2024','Jan 2025','Feb 2025','Mar 2025']
for sid in sids:
    for m in months[:4]:
        c.execute(
            'INSERT INTO stock_allocations(shop_id,month,rice_allocated,wheat_allocated,sugar_allocated)'
            'VALUES(%s,%s,%s,%s,%s)',
            (sid, m, rd(4000, 9000), rd(2500, 5500), rd(400, 900))
        )

# ── DISTRIBUTION LOGS (75+) ────────────────────────────────────────
factors = [0.62,0.97,0.38,0.28,0.75,0.90,0.55,0.70,0.20,0.85,0.60,0.45,0.80,0.65,0.35]
for si, sid in enumerate(sids):
    f = factors[si]
    for _ in range(rd(4, 6)):
        cid = random.choice(cids)
        c.execute(
            'INSERT INTO distribution_logs(ration_card_id,shop_id,date,rice_given,wheat_given,sugar_given)'
            'VALUES(%s,%s,%s,%s,%s,%s)',
            (cid, sid, rdate(2024, 10, 2025, 3),
             int(rd(3000, 8000) * f), int(rd(2000, 5000) * f), int(rd(300, 800) * f))
        )

# ── CERTIFICATES (15) ──────────────────────────────────────────────
for i, sid in enumerate(sids):
    uid_c = f'CERT-2024-{str(i+1).zfill(4)}'
    st = 'valid' if i % 5 != 0 else ('revoked' if i % 10 == 0 else 'expired')
    qr = '{' + f'"id":"{uid_c}","shop":"{shops_raw[i][3]}","valid":true' + '}'
    c.execute(
        'INSERT INTO certificates(cert_unique_id,shop_id,issued_to,issued_by,cert_type,'
        'issue_date,expiry_date,status,qr_code_data)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)',
        (uid_c, sid, shops_raw[i][3], 1, 'Shop License',
         rdate(2022, 1, 2023, 12), rdate(2025, 1, 2027, 6), st, qr)
    )

# ── FRAUD CASES (20) ───────────────────────────────────────────────
titles = [
    'Duplicate Aadhaar detected at Rampur FPS',
    'Ghost beneficiary scheme in Lucknow',
    'Stock diversion at Azamnagar FPS',
    'Fake documents submitted by Agra dealer',
    'Abnormal withdrawal pattern at Kasimpur FPS',
    'Multiple complaints against Meerut FPS',
    'Ration card fraud in Aligarh district',
    'Repeated face verification failures at Nagpur FPS',
    'Overcharging complaint at Varanasi West FPS',
    'Wholesale diversion suspected at Kanpur FPS',
    'Dead beneficiary receiving rations in Bareilly',
    'Duplicate distribution logs at Shivpur FPS',
    'License number mismatch at Bareilly FPS',
    'Dealer arrested for bribery at Mathura FPS',
    'Ghost shop operating in Jhansi area',
    'Stock quantity mismatch at Allahabad FPS',
    'Beneficiary reselling rations at market price',
    'Systematic overreporting at Rampur FPS',
    'Forged certificates at Agra North FPS',
    'Cross-district fraud network detected',
]
ctypes = ['duplicate_aadhaar','stock_mismatch','fake_documents','ghost_shop',
          'abnormal_transaction','complaint_based']
csts   = ['open','under_review','verified_fraud','rejected','closed']
pris   = ['low','medium','high','critical']
case_ids = []
for i, title in enumerate(titles):
    c.execute(
        'INSERT INTO fraud_cases(case_number,title,description,shop_id,beneficiary_id,'
        'case_type,status,priority,risk_score,assigned_officer,created_by,deadline)'
        'VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',
        (f'CASE-2025-{str(i+1).zfill(3)}', title, f'Investigation required: {title}',
         sids[i % 15], bids[i % 56], ctypes[i % 6], csts[i % 5], pris[i % 4],
         rd(45, 98), 2, 1, rdate(2025, 4, 2025, 12))
    )
    case_ids.append(c.lastrowid)

# ── FRAUD ALERTS (30) ──────────────────────────────────────────────
ats = [
    'Duplicate Aadhaar Detected','Stock Mismatch Alert',
    'Abnormal Transaction Pattern','Face Verification Failed',
    'Complaint Threshold Exceeded','Ghost Beneficiary Detected',
    'License Expiry Warning','Suspicious Withdrawal Pattern',
]
for i in range(30):
    st = 'new' if i % 3 == 0 else ('acknowledged' if i % 3 == 1 else 'resolved')
    c.execute(
        'INSERT INTO fraud_alerts(shop_id,beneficiary_id,alert_type,severity,'
        'description,risk_score,status)VALUES(%s,%s,%s,%s,%s,%s,%s)',
        (sids[i % 15], bids[i % 56], ats[i % 8],
         ['low','medium','high','critical'][i % 4],
         f'System detected: {ats[i%8]} — immediate review required.',
         rd(30, 99), st)
    )

# ── COMPLAINTS (20) ────────────────────────────────────────────────
cnames = ['Rajesh Tiwari','Meena Patel','Arjun Singh','Kaveri Devi','Suresh Lal',
          'Priti Sharma','Anand Kumar','Nita Gupta','Ramesh Yadav','Leela Devi',
          'Mahesh Verma','Shanti Bai','Gopal Das','Kamla Singh','Harish Mishra',
          'Prabha Devi','Vinod Kumar','Savita Rao','Deepak Nair','Rekha Joshi']
cdescs = [
    'Dealer demands extra money for rations every month',
    'Received substandard quality rice with stones mixed in',
    'Only half the allotted quantity was given to our family',
    'Bribe demanded for ration card renewal process',
    'Unknown person is claiming our family rations each month',
    'Our ration card details were found being sold on black market',
    'Shop remains closed on all distribution days',
    'Dealer openly sold rations at double price in open market',
    'Wrong family ID entered causing ration denial',
    'Wheat supplied was damaged and unfit for consumption',
]
comp_types = ['overcharging','fake_ration','short_supply','bribery',
              'ghost_beneficiary','document_fraud']
comp_sts   = ['submitted','under_review','assigned','resolved','rejected']
for i in range(20):
    c.execute(
        'INSERT INTO public_complaints(complaint_number,complainant_name,complainant_phone,'
        'complaint_type,shop_id,description,status)VALUES(%s,%s,%s,%s,%s,%s,%s)',
        (f'COMP-2025-{str(i+1).zfill(3)}', cnames[i % 20],
         f'9{rd(100000000,999999999)}', comp_types[i % 6],
         sids[i % 15], cdescs[i % 10], comp_sts[i % 5])
    )

# ── FACE VERIFICATION LOGS (25) ────────────────────────────────────
for i in range(25):
    sc = round(random.uniform(30, 99), 1)
    st = 'verified' if sc >= 80 else ('suspicious' if sc >= 55 else 'failed')
    c.execute(
        'INSERT INTO face_verification_logs(beneficiary_id,shop_id,verifier_id,'
        'confidence_score,status,liveness_passed,ip_address)VALUES(%s,%s,%s,%s,%s,%s,%s)',
        (bids[i % 56], sids[i % 15], 2, sc, st, sc >= 70, f'192.168.1.{rd(1,254)}')
    )

# ── NOTIFICATIONS (7) ──────────────────────────────────────────────
notifs = [
    (1, 'Critical Fraud Alert',    'Agra North FPS triggered 5 consecutive fraud alerts', 'fraud_alert'),
    (1, 'New Complaint Filed',     'COMP-2025-001 filed against Rampur FPS dealer',       'complaint'),
    (1, 'Certificate Expiring',    '3 shop certificates expire within 30 days',            'certificate'),
    (1, 'Duplicate Aadhaar Found', '3 duplicate Aadhaar records detected in database',    'fraud_alert'),
    (1, 'Case Update',             'CASE-2025-001 changed to verified_fraud status',       'case_update'),
    (2, 'Case Assigned to You',    'CASE-2025-005 has been assigned for investigation',    'case_update'),
    (2, 'Alert Acknowledged',      'Fraud alert for Kasimpur FPS has been acknowledged',  'fraud_alert'),
]
for uid, title, msg, ntype in notifs:
    c.execute(
        'INSERT INTO notifications(user_id,title,message,notif_type)VALUES(%s,%s,%s,%s)',
        (uid, title, msg, ntype)
    )

db.commit()
db.close()

print('=' * 55)
print('  ALL SAMPLE DATA LOADED SUCCESSFULLY!')
print('=' * 55)
print('  Users:              10')
print('  Shops:              15')
print('  Beneficiaries:      56  (3 intentional duplicates)')
print('  Ration Cards:       40')
print('  Stock Allocations:  60')
print('  Distribution Logs:  75+')
print('  Certificates:       15')
print('  Fraud Cases:        20')
print('  Fraud Alerts:       30')
print('  Complaints:         20')
print('  Face Verify Logs:   25')
print('  Notifications:       7')
print('=' * 55)
print('  Login: admin / admin123')
print('         officer1 / officer123')
print('=' * 55)
