-- sample_data.sql — Fraud Portal Sample Data
USE ration_system;
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE admin_actions; TRUNCATE TABLE face_verification_logs; TRUNCATE TABLE notifications;
TRUNCATE TABLE certificates; TRUNCATE TABLE public_complaints; TRUNCATE TABLE fraud_alerts;
TRUNCATE TABLE evidence_files; TRUNCATE TABLE case_notes; TRUNCATE TABLE fraud_cases;
TRUNCATE TABLE distribution_logs; TRUNCATE TABLE stock_allocations; TRUNCATE TABLE ration_cards;
TRUNCATE TABLE beneficiaries; TRUNCATE TABLE ration_shops; TRUNCATE TABLE audit_logs; TRUNCATE TABLE users;
SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO users (username,password_hash,full_name,email,phone,role,status) VALUES
('admin',SHA2('admin123',256),'Super Admin','admin@rationguard.gov.in','9800000001','super_admin','active'),
('officer1',SHA2('officer123',256),'Rajesh Kumar Sharma','rajesh.sharma@rationguard.gov.in','9800000002','investigation_officer','active'),
('officer2',SHA2('officer123',256),'Priya Nair','priya.nair@rationguard.gov.in','9800000003','investigation_officer','active'),
('shopowner1',SHA2('shop123',256),'Ramesh Gupta','ramesh.gupta@email.com','9800000004','shop_owner','active'),
('shopowner2',SHA2('shop123',256),'Sunita Devi','sunita.devi@email.com','9800000005','shop_owner','active'),
('shopowner3',SHA2('shop123',256),'Mohammad Iqbal','iqbal@email.com','9800000006','shop_owner','suspended'),
('publicuser1',SHA2('user123',256),'Arun Mishra','arun.mishra@gmail.com','9800000007','public_user','active'),
('publicuser2',SHA2('user123',256),'Kavita Singh','kavita.singh@gmail.com','9800000008','public_user','active');

INSERT INTO ration_shops (shop_name,location,state,district,dealer_name,dealer_phone,license_number,status,fraud_risk_score,certificate_id,certificate_status,certificate_expiry,owner_user_id) VALUES
('Ram Lal FPS','Rampur Village','Uttar Pradesh','Rampur','Ramesh Gupta','9800000004','UP-RPR-001','active',15,'CERT-2024-001','valid','2026-12-31',4),
('Shiv Kripa Store','Shivpur','Uttar Pradesh','Shivpur','Sunita Devi','9800000005','UP-SHV-002','active',22,'CERT-2024-002','valid','2026-06-30',5),
('Al-Noor Provision','Azamnagar','Uttar Pradesh','Azamgarh','Mohammad Iqbal','9800000006','UP-AZM-003','suspended',78,'CERT-2024-003','blocked','2025-12-31',6),
('Durga Ration Depot','Lucknow Market','Uttar Pradesh','Lucknow','Vijay Verma','9811100001','UP-LKO-004','under_review',55,'CERT-2024-004','valid','2026-09-30',NULL),
('Kasim Provision','Kasimpur','Uttar Pradesh','Faizabad','Kasim Ali','9811100002','UP-FZB-005','active',8,'CERT-2024-005','valid','2026-12-31',NULL),
('Ganga Fair Price','Varanasi Old City','Uttar Pradesh','Varanasi','Santosh Tiwari','9811100003','UP-VNS-006','active',30,'CERT-2024-006','valid','2026-08-15',NULL),
('Kashi Ration Shop','Kanpur Central','Uttar Pradesh','Kanpur','Meera Yadav','9811100004','UP-KNP-007','blocked',91,'CERT-2024-007','revoked','2025-06-30',NULL),
('Agra Depot No.1','Agra City','Uttar Pradesh','Agra','Suresh Bansal','9811100005','UP-AGR-008','active',12,'CERT-2024-008','valid','2026-11-30',NULL),
('Bundelkhand FPS','Jhansi Road','Uttar Pradesh','Jhansi','Rakesh Patel','9811100006','UP-JHS-009','active',18,'CERT-2024-009','valid','2026-10-31',NULL),
('Nagpur Central FPS','Nagpur East','Maharashtra','Nagpur','Dinesh Chavan','9811100007','MH-NGP-010','active',5,'CERT-2024-010','valid','2026-12-31',NULL);

INSERT INTO beneficiaries (name,aadhaar_number,family_id,village,income_category,phone,face_verified,face_score,verification_status) VALUES
('Suresh Kumar','1234 5678 9012','FAM-001','Rampur','BPL','9900000001',TRUE,94.5,'verified'),
('Meera Devi','2345 6789 0123','FAM-002','Shivpur','BPL','9900000002',TRUE,88.2,'verified'),
('Rajan Prasad','3456 7890 1234','FAM-003','Azamnagar','APL','9900000003',FALSE,0.0,'pending'),
('Fatima Begum','4567 8901 2345','FAM-004','Lucknow','BPL','9900000004',TRUE,91.0,'verified'),
('Amit Sharma','5678 9012 3456','FAM-005','Kasimpur','AAY','9900000005',TRUE,45.0,'suspicious'),
('Pooja Yadav','6789 0123 4567','FAM-006','Varanasi','BPL','9900000006',FALSE,0.0,'pending'),
('Rajendra Singh','7890 1234 5678','FAM-007','Nagpur','BPL','9900000007',TRUE,97.3,'verified'),
('Kiran Bala','8901 2345 6789','FAM-008','Kanpur','APL','9900000008',TRUE,72.1,'suspicious'),
('Mohammad Yasin','9012 3456 7890','FAM-009','Agra','BPL','9900000009',FALSE,0.0,'failed'),
('Savita Kumari','0123 4567 8901','FAM-010','Jhansi','BPL','9900000010',TRUE,99.1,'verified'),
('Duplicate Person','1234 5678 9012','FAM-011','Rampur','BPL','9900000011',FALSE,0.0,'failed'),
('Ghost Member','1111 2222 3333','FAM-012','Kanpur','BPL','9900000012',FALSE,0.0,'pending');

INSERT INTO ration_cards (family_id,card_type,issue_date,expiry_date,status) VALUES
('FAM-001','BPL','2022-01-01','2027-01-01','Active'),('FAM-002','BPL','2022-03-01','2027-03-01','Active'),
('FAM-003','APL','2022-06-01','2027-06-01','Active'),('FAM-004','BPL','2021-07-01','2026-07-01','Active'),
('FAM-005','AAY','2021-09-01','2026-09-01','Active'),('FAM-006','BPL','2022-11-01','2027-11-01','Active'),
('FAM-007','BPL','2023-01-01','2028-01-01','Active'),('FAM-008','APL','2020-05-01','2025-05-01','Inactive'),
('FAM-009','BPL','2019-03-01','2024-03-01','Cancelled'),('FAM-010','BPL','2023-08-01','2028-08-01','Active');

INSERT INTO stock_allocations (shop_id,month,rice_allocated,wheat_allocated,sugar_allocated) VALUES
(1,'2024-01',500,300,100),(1,'2024-02',500,300,100),(1,'2024-03',520,310,105),
(2,'2024-01',400,250,80),(2,'2024-02',400,250,80),(2,'2024-03',410,255,82),
(3,'2024-01',600,400,120),(3,'2024-02',600,400,120),(3,'2024-03',600,400,120),
(4,'2024-01',700,450,150),(4,'2024-02',700,450,150),(4,'2024-03',720,460,155),
(5,'2024-01',350,200,70),(5,'2024-02',350,200,70),(5,'2024-03',360,205,72),
(6,'2024-01',550,350,110),(6,'2024-02',550,350,110),(6,'2024-03',560,355,112),
(7,'2024-01',800,500,160),(7,'2024-02',800,500,160),(7,'2024-03',800,500,160),
(8,'2024-01',450,280,90),(8,'2024-02',450,280,90),(8,'2024-03',460,285,92),
(9,'2024-01',480,300,96),(9,'2024-02',480,300,96),(9,'2024-03',490,305,98),
(10,'2024-01',600,380,120),(10,'2024-02',600,380,120),(10,'2024-03',610,385,122);

INSERT INTO distribution_logs (ration_card_id,shop_id,date,rice_given,wheat_given,sugar_given) VALUES
(1,1,'2024-01-10',48,30,10),(1,1,'2024-02-12',48,30,10),(1,1,'2024-03-15',50,31,10),
(2,2,'2024-01-11',40,25,8),(2,2,'2024-02-13',40,25,8),(2,2,'2024-03-16',42,26,8),
(3,3,'2024-01-14',55,35,11),(3,3,'2024-02-14',55,35,11),(3,3,'2024-03-17',55,35,11),
(4,4,'2024-01-09',60,40,13),(4,4,'2024-02-10',60,40,13),(4,4,'2024-03-18',62,41,14),
(5,5,'2024-01-15',35,20,7),(5,5,'2024-02-15',35,20,7),(5,5,'2024-03-19',36,21,7),
(6,6,'2024-01-16',50,33,10),(6,6,'2024-02-16',50,33,10),(6,6,'2024-03-20',52,34,11),
(7,7,'2024-01-17',20,15,5),(7,7,'2024-02-17',20,15,5),(7,7,'2024-03-21',20,15,5),
(8,8,'2024-01-18',44,28,9),(8,8,'2024-02-18',44,28,9),(8,8,'2024-03-22',45,29,9),
(9,9,'2024-01-19',47,30,9),(9,9,'2024-02-19',47,30,9),(9,9,'2024-03-23',48,31,10),
(10,10,'2024-01-20',58,37,12),(10,10,'2024-02-20',58,37,12),(10,10,'2024-03-24',59,38,12);

INSERT INTO fraud_cases (case_number,title,description,shop_id,case_type,status,priority,risk_score,assigned_officer,created_by,deadline) VALUES
('CASE-2024-001','Duplicate Aadhaar - Rampur','Multiple beneficiaries registered with Aadhaar 1234 5678 9012.',1,'duplicate_aadhaar','under_review','high',82,2,1,'2024-06-30'),
('CASE-2024-002','Stock Mismatch - Al-Noor','1200kg allocated, only 165kg distributed. 85% diversion suspected.',3,'stock_mismatch','verified_fraud','critical',91,2,1,'2024-05-15'),
('CASE-2024-003','Ghost Shop - Kashi Ration','Zero legitimate distributions. Shop operating as ghost entity.',7,'ghost_shop','verified_fraud','critical',95,3,1,'2024-04-30'),
('CASE-2024-004','Abnormal Transactions - Durga','High transaction frequency detected by AI system.',4,'abnormal_transaction','open','medium',55,3,1,'2024-07-15'),
('CASE-2024-005','Fake Documents - Ganga FPS','Certificate QR code fails verification. Document possibly tampered.',6,'fake_documents','under_review','high',68,2,1,'2024-06-20');

INSERT INTO case_notes (case_id,author_id,note_text,is_internal) VALUES
(1,2,'Initial investigation started. Cross-verifying with UIDAI database.',TRUE),
(1,1,'Duplicate confirmed. Physical inspection ordered.',TRUE),
(2,2,'Shop visited. Storage empty despite 1200kg allocation. Owner absconding.',TRUE),
(2,1,'FIR filed. Certificate BLOCKED. Account frozen.',TRUE),
(3,3,'Field visits confirm no actual operations.',TRUE),
(4,3,'Flagged by AI. Risk score 55/100. Monitoring for 30 days.',TRUE),
(5,2,'Certificate QR failed 3 times. Contacted issuing authority.',TRUE);

INSERT INTO fraud_alerts (shop_id,beneficiary_id,alert_type,severity,description,risk_score,status) VALUES
(3,NULL,'Extreme Stock Diversion','critical','AI detected >85% mismatch over 3 months.',91,'acknowledged'),
(7,NULL,'Ghost Shop - Zero Distributions','critical','No distributions despite full allocation for 3 months.',95,'acknowledged'),
(4,NULL,'Abnormal Transaction Frequency','high','2.3x above system average. Possible record inflation.',72,'new'),
(NULL,5,'Suspicious Face Verification','medium','Face match 45% - below threshold. Possible spoofing.',60,'new'),
(NULL,8,'Low Face Confidence Score','medium','Repeated failures at 72%. Requires physical verification.',55,'new'),
(NULL,11,'Duplicate Aadhaar','critical','Aadhaar 1234 5678 9012 registered for 2 beneficiaries.',88,'acknowledged'),
(6,NULL,'Possible Document Tampering','high','Certificate QR returns error. Authenticity in question.',68,'new'),
(1,NULL,'Multiple Dealer Phone Match','low','Dealer phone matches another district record.',25,'new');

INSERT INTO public_complaints (complaint_number,complainant_name,complainant_phone,shop_id,shop_name_text,complaint_type,description,status,assigned_to,case_id) VALUES
('COMP-2024-001','Arun Mishra','9900000001',3,'Al-Noor Provision','short_supply','Charged extra and gave half ration. Was threatened when questioned.','assigned',2,2),
('COMP-2024-002','Kavita Singh','9900000002',7,'Kashi Ration Shop','fake_ration','Shop closed for months but cards show distribution. Never received anything.','resolved',3,3),
('COMP-2024-003','Anonymous Citizen',NULL,4,'Durga Ration Depot','overcharging','Dealer charges Rs.50 extra per family over government rates.','under_review',3,NULL),
('COMP-2024-004','Ramesh Mishra','9811200001',6,'Ganga Fair Price','document_fraud','Certificate displayed looks like a photocopy. Seal appears fake.','under_review',2,5),
('COMP-2024-005','Local NGO Rep','9811200002',NULL,'Unknown Shop','ghost_beneficiary','Families registered for rations but never received anything.','submitted',NULL,NULL);

INSERT INTO certificates (cert_unique_id,shop_id,issued_to,issued_by,cert_type,issue_date,expiry_date,status,qr_code_data) VALUES
('CERT-2024-001',1,'Ramesh Gupta',1,'Shop License','2024-01-01','2026-12-31','valid','{"id":"CERT-2024-001","shop":"Ram Lal FPS","valid":true}'),
('CERT-2024-002',2,'Sunita Devi',1,'Shop License','2024-01-01','2026-06-30','valid','{"id":"CERT-2024-002","shop":"Shiv Kripa Store","valid":true}'),
('CERT-2024-003',3,'Mohammad Iqbal',1,'Shop License','2024-01-01','2025-12-31','blocked','{"id":"CERT-2024-003","shop":"Al-Noor Provision","valid":false,"blocked":true}'),
('CERT-2024-004',4,'Vijay Verma',1,'Shop License','2024-01-01','2026-09-30','valid','{"id":"CERT-2024-004","shop":"Durga Ration Depot","valid":true}'),
('CERT-2024-005',5,'Kasim Ali',1,'Shop License','2024-01-01','2026-12-31','valid','{"id":"CERT-2024-005","shop":"Kasim Provision","valid":true}'),
('CERT-2024-006',6,'Santosh Tiwari',1,'Shop License','2024-01-01','2026-08-15','valid','{"id":"CERT-2024-006","shop":"Ganga Fair Price","valid":true}'),
('CERT-2024-007',7,'Meera Yadav',1,'Shop License','2023-01-01','2025-06-30','revoked','{"id":"CERT-2024-007","shop":"Kashi Ration Shop","valid":false,"revoked":true}'),
('CERT-2024-008',8,'Suresh Bansal',1,'Shop License','2024-01-01','2026-11-30','valid','{"id":"CERT-2024-008","shop":"Agra Depot No.1","valid":true}'),
('CERT-2024-009',9,'Rakesh Patel',1,'Shop License','2024-01-01','2026-10-31','valid','{"id":"CERT-2024-009","shop":"Bundelkhand FPS","valid":true}'),
('CERT-2024-010',10,'Dinesh Chavan',1,'Shop License','2024-01-01','2026-12-31','valid','{"id":"CERT-2024-010","shop":"Nagpur Central FPS","valid":true}');

INSERT INTO notifications (user_id,title,message,notif_type,is_read,related_id,related_type) VALUES
(1,'Critical: Ghost Shop Detected','Shop Kashi Ration Shop identified as ghost. Immediate action required.','fraud_alert',FALSE,3,'case'),
(1,'Certificate Blocked','CERT-2024-003 for Al-Noor Provision blocked due to verified fraud.','certificate',TRUE,3,'certificate'),
(2,'Case Assigned to You','CASE-2024-001: Duplicate Aadhaar Registration assigned.','case_update',FALSE,1,'case'),
(2,'New Complaint Received','COMP-2024-001 from Arun Mishra requires investigation.','complaint',FALSE,1,'complaint'),
(3,'AI Fraud Alert: High Risk','Shop Durga Ration Depot flagged. Risk score 55. Review recommended.','fraud_alert',FALSE,4,'case'),
(6,'Account Suspended','Your account suspended pending fraud investigation. Contact admin.','warning',FALSE,NULL,NULL);

INSERT INTO admin_actions (admin_id,target_type,target_id,action_type,reason) VALUES
(1,'shop',3,'suspend','Fraud investigation initiated. Extreme stock diversion detected.'),
(1,'certificate',3,'revoke_cert','Revoked due to verified fraud case CASE-2024-002.'),
(1,'shop',7,'block','Permanently blocked. Ghost shop confirmed.'),
(1,'certificate',7,'revoke_cert','Revoked. Shop confirmed ghost entity.'),
(1,'user',6,'suspend','Account suspended pending investigation.'),
(2,'case',2,'close','Investigation complete. FIR filed. Handed to law enforcement.');

INSERT INTO face_verification_logs (beneficiary_id,shop_id,verifier_id,confidence_score,status,liveness_passed,ip_address) VALUES
(1,1,2,94.5,'verified',TRUE,'192.168.1.10'),(2,2,2,88.2,'verified',TRUE,'192.168.1.11'),
(5,3,3,45.0,'suspicious',FALSE,'10.0.0.5'),(8,4,3,72.1,'suspicious',TRUE,'10.0.0.6'),
(9,NULL,1,22.3,'failed',FALSE,'192.168.2.1'),(11,1,2,15.2,'failed',FALSE,'10.0.0.99');

INSERT INTO audit_logs (user_id,action,entity_type,entity_id,description,ip_address) VALUES
(1,'LOGIN','user',1,'Admin logged in','192.168.1.1'),
(1,'BLOCK_SHOP','shop',7,'Blocked Kashi Ration Shop','192.168.1.1'),
(1,'REVOKE_CERT','certificate',7,'Revoked CERT-2024-007','192.168.1.1'),
(2,'LOGIN','user',2,'Officer Rajesh Kumar Sharma logged in','192.168.1.2'),
(2,'UPDATE_CASE','fraud_case',2,'Updated case to verified_fraud','192.168.1.2'),
(3,'ADD_NOTE','case_note',5,'Added note to CASE-2024-003','192.168.1.3');

SELECT 'Sample data inserted successfully!' AS status;
