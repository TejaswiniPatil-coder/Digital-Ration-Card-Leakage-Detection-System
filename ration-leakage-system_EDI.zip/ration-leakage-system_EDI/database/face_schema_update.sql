-- face_schema_update.sql — Add Real AI Face Verification Schema Changes
-- Run this AFTER the main schema.sql has been applied.
USE ration_system;

-- ── Add face embedding column to beneficiaries ──────────────────
ALTER TABLE beneficiaries
  ADD COLUMN IF NOT EXISTS face_embedding JSON DEFAULT NULL
  AFTER face_score;

ALTER TABLE beneficiaries
  ADD COLUMN IF NOT EXISTS face_enrolled BOOLEAN DEFAULT FALSE
  AFTER face_embedding;

ALTER TABLE beneficiaries
  ADD COLUMN IF NOT EXISTS face_enrolled_at TIMESTAMP NULL
  AFTER face_enrolled;

ALTER TABLE beneficiaries
  ADD COLUMN IF NOT EXISTS face_model VARCHAR(50) DEFAULT NULL
  AFTER face_enrolled_at;

-- ── Enhance face_verification_logs with real AI fields ──────────
ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS cosine_distance DECIMAL(8,4) DEFAULT NULL
  AFTER confidence_score;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS anti_spoof_passed BOOLEAN DEFAULT FALSE
  AFTER liveness_passed;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS anti_spoof_confidence DECIMAL(5,2) DEFAULT 0
  AFTER anti_spoof_passed;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS blink_detected BOOLEAN DEFAULT FALSE
  AFTER anti_spoof_confidence;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS blink_count INT DEFAULT 0
  AFTER blink_detected;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS frames_used INT DEFAULT 0
  AFTER blink_count;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS frames_successful INT DEFAULT 0
  AFTER frames_used;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS embedding_consistency DECIMAL(5,2) DEFAULT 0
  AFTER frames_successful;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS model_used VARCHAR(50) DEFAULT 'Facenet'
  AFTER embedding_consistency;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS processing_time DECIMAL(6,2) DEFAULT 0
  AFTER model_used;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS verification_type ENUM('enroll','verify','quick_check') DEFAULT 'verify'
  AFTER processing_time;

ALTER TABLE face_verification_logs
  ADD COLUMN IF NOT EXISTS error_message TEXT DEFAULT NULL
  AFTER verification_type;

SELECT 'Face verification schema update complete!' AS status;
