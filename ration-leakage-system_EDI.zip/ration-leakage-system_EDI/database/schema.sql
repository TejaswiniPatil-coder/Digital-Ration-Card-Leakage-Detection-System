-- schema.sql — Ration Guard: AI Fraud Monitoring & Certification Portal
CREATE DATABASE IF NOT EXISTS ration_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ration_system;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE,
    phone VARCHAR(15),
    role ENUM('super_admin','investigation_officer','shop_owner','public_user') DEFAULT 'public_user',
    status ENUM('active','suspended','blocked') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id INT,
    description TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS beneficiaries (
    beneficiary_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    aadhaar_number VARCHAR(20) NOT NULL,
    family_id VARCHAR(20),
    village VARCHAR(100),
    income_category ENUM('BPL','APL','AAY') DEFAULT 'BPL',
    phone VARCHAR(15),
    face_verified BOOLEAN DEFAULT FALSE,
    face_score DECIMAL(5,2) DEFAULT 0,
    verification_status ENUM('pending','verified','suspicious','failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ration_cards (
    ration_card_id INT AUTO_INCREMENT PRIMARY KEY,
    family_id VARCHAR(20),
    card_type ENUM('BPL','APL','AAY') DEFAULT 'BPL',
    issue_date DATE,
    expiry_date DATE,
    status ENUM('Active','Inactive','Cancelled','Revoked') DEFAULT 'Active'
);

CREATE TABLE IF NOT EXISTS ration_shops (
    shop_id INT AUTO_INCREMENT PRIMARY KEY,
    shop_name VARCHAR(100) NOT NULL,
    location VARCHAR(100),
    state VARCHAR(50) DEFAULT 'Uttar Pradesh',
    district VARCHAR(50),
    dealer_name VARCHAR(100),
    dealer_phone VARCHAR(15),
    dealer_email VARCHAR(150),
    license_number VARCHAR(50),
    status ENUM('active','under_review','suspended','blocked') DEFAULT 'active',
    fraud_risk_score INT DEFAULT 0,
    certificate_id VARCHAR(50),
    certificate_status ENUM('valid','expired','revoked','blocked') DEFAULT 'valid',
    certificate_expiry DATE,
    owner_user_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS stock_allocations (
    allocation_id INT AUTO_INCREMENT PRIMARY KEY,
    shop_id INT NOT NULL,
    month VARCHAR(30),
    rice_allocated DECIMAL(10,2) DEFAULT 0,
    wheat_allocated DECIMAL(10,2) DEFAULT 0,
    sugar_allocated DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (shop_id) REFERENCES ration_shops(shop_id)
);

CREATE TABLE IF NOT EXISTS distribution_logs (
    distribution_id INT AUTO_INCREMENT PRIMARY KEY,
    ration_card_id INT NOT NULL,
    shop_id INT NOT NULL,
    date DATE,
    rice_given DECIMAL(10,2) DEFAULT 0,
    wheat_given DECIMAL(10,2) DEFAULT 0,
    sugar_given DECIMAL(10,2) DEFAULT 0,
    FOREIGN KEY (ration_card_id) REFERENCES ration_cards(ration_card_id),
    FOREIGN KEY (shop_id) REFERENCES ration_shops(shop_id)
);

CREATE TABLE IF NOT EXISTS fraud_cases (
    case_id INT AUTO_INCREMENT PRIMARY KEY,
    case_number VARCHAR(30) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    shop_id INT,
    beneficiary_id INT,
    case_type ENUM('duplicate_aadhaar','stock_mismatch','fake_documents','ghost_shop','abnormal_transaction','complaint_based','other') DEFAULT 'other',
    status ENUM('open','under_review','verified_fraud','rejected','suspended','blocked','closed') DEFAULT 'open',
    priority ENUM('low','medium','high','critical') DEFAULT 'medium',
    risk_score INT DEFAULT 0,
    assigned_officer INT,
    created_by INT,
    deadline DATE,
    closed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS case_notes (
    note_id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL,
    author_id INT,
    note_text TEXT NOT NULL,
    is_internal BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES fraud_cases(case_id)
);

CREATE TABLE IF NOT EXISTS evidence_files (
    evidence_id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT,
    complaint_id INT,
    uploaded_by INT,
    file_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(50),
    file_size BIGINT,
    file_path VARCHAR(500),
    description TEXT,
    upload_type ENUM('document','image','video','transaction_proof','complaint_record','other') DEFAULT 'document',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS fraud_alerts (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    shop_id INT,
    beneficiary_id INT,
    alert_type VARCHAR(100) NOT NULL,
    severity ENUM('low','medium','high','critical') DEFAULT 'medium',
    description TEXT,
    risk_score INT DEFAULT 0,
    status ENUM('new','acknowledged','resolved','false_positive') DEFAULT 'new',
    acknowledged_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public_complaints (
    complaint_id INT AUTO_INCREMENT PRIMARY KEY,
    complaint_number VARCHAR(30) UNIQUE NOT NULL,
    complainant_name VARCHAR(100) NOT NULL,
    complainant_phone VARCHAR(15),
    complainant_email VARCHAR(150),
    shop_id INT,
    shop_name_text VARCHAR(100),
    complaint_type ENUM('overcharging','fake_ration','short_supply','bribery','ghost_beneficiary','document_fraud','other') DEFAULT 'other',
    description TEXT NOT NULL,
    status ENUM('submitted','under_review','assigned','resolved','rejected') DEFAULT 'submitted',
    assigned_to INT,
    case_id INT,
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS certificates (
    cert_id INT AUTO_INCREMENT PRIMARY KEY,
    cert_unique_id VARCHAR(50) UNIQUE NOT NULL,
    shop_id INT,
    issued_to VARCHAR(100),
    issued_by INT,
    cert_type VARCHAR(50) DEFAULT 'Shop License',
    issue_date DATE,
    expiry_date DATE,
    status ENUM('valid','expired','revoked','blocked','suspended') DEFAULT 'valid',
    revoked_by INT,
    revoke_reason TEXT,
    revoked_at TIMESTAMP NULL,
    qr_code_data TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notifications (
    notif_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    notif_type ENUM('fraud_alert','case_update','complaint','certificate','system','warning') DEFAULT 'system',
    is_read BOOLEAN DEFAULT FALSE,
    related_id INT,
    related_type VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS face_verification_logs (
    verify_id INT AUTO_INCREMENT PRIMARY KEY,
    beneficiary_id INT,
    shop_id INT,
    verifier_id INT,
    confidence_score DECIMAL(5,2),
    status ENUM('verified','suspicious','failed') DEFAULT 'failed',
    liveness_passed BOOLEAN DEFAULT FALSE,
    ip_address VARCHAR(45),
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admin_actions (
    action_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    target_type ENUM('shop','certificate','case','complaint','user') NOT NULL,
    target_id INT NOT NULL,
    action_type ENUM('suspend','block','unblock','revoke_cert','freeze','send_notice','assign','close','reopen','approve','reject') NOT NULL,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SET FOREIGN_KEY_CHECKS = 1;
SELECT 'Schema created successfully!' AS status;
